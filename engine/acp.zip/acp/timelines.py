"""Riot match timelines: minute-by-minute gold/XP/CS, every kill, objective and
building, item purchases and skill order.

Every game played on Riot's tournament servers (LCK and all international
events) is mirrored on Leaguepedia as 'V5 data:<id>' and '.../Timeline' pages
(V4 for 2017-2020). LPL games run on Tencent's servers and have none.

Each game is compacted from ~1.3 MB of raw JSON to a few KB and cached per
tournament in data/timelines/<event>.json. load() checks every record against
the database (winner, map side, champions) before anything uses it.
"""
import datetime as dt
import json
import os
import re
from collections import defaultdict

from . import DATA
from .leaguepedia import esc

TL_DIR = DATA / "timelines"
TL_REGIONS_DIR = DATA / "timelines_regions"  # other regions' games (LEC, LCS, ...): see the regions test
SKIP_LEAGUES = ("Tencent LoL Pro League",)   # no Riot data for LPL
BATCH_GAMES = 3                              # games per page request (~4 MB)


def slug(page):
    return re.sub(r"[^A-Za-z0-9]+", "_", page).strip("_")


def _parse_date(s):
    try:
        return dt.date.fromisoformat(str(s)[:10])
    except (TypeError, ValueError):
        return None


def champ_maps(champions):
    """Riot ids ('MonkeyKing') and numeric keys ('62') -> Data Dragon display names."""
    by_id, by_key = {}, {}
    for name, c in champions.items():
        if c.get("id"):
            by_id[str(c["id"]).lower()] = name
        if c.get("key"):
            by_key[str(c["key"])] = name
    return by_id, by_key


def team_of(pid):
    return 100 if 1 <= pid <= 5 else (200 if 6 <= pid <= 10 else 0)


def _first(js):
    if isinstance(js, list):
        js = js[0] if js else None
    if isinstance(js, dict) and "info" in js and "participants" not in js and "frames" not in js:
        js = js["info"]
    return js if isinstance(js, dict) else None


def compact(data, tl, maps):
    """Raw Riot match + timeline JSON (v4 or v5) -> small dict, or None if unusable."""
    by_id, by_key = maps
    data, tl = _first(data), _first(tl)
    if not data or not data.get("participants"):
        return None
    idents = {pi.get("participantId"): (pi.get("player") or {}).get("summonerName")
              for pi in data.get("participantIdentities", [])}
    parts = {}
    for p in data["participants"]:
        pid = p.get("participantId")
        name = p.get("championName")
        champ = by_id.get(str(name).lower()) if name else None
        if not champ and p.get("championId") is not None:
            champ = by_key.get(str(p["championId"]))
        who = p.get("riotIdGameName") or p.get("summonerName") or idents.get(pid) or ""
        parts[str(pid)] = [p.get("teamId") or team_of(pid or 0), champ or name, who]
    win_team = None
    for t in data.get("teams", []):
        if t.get("win") is True or t.get("win") == "Win":
            win_team = t.get("teamId")
    dur = data.get("gameDuration") or 0
    if dur > 20000:  # milliseconds (match-v5 before patch 11.20)
        dur /= 1000.0
    out = {"v": 5 if "championName" in data["participants"][0] else 4,
           "dur": round(dur), "win": win_team, "p": parts}
    obj = {}
    for t in data.get("teams", []):
        tid = str(t.get("teamId"))
        if "objectives" in t:
            obj[tid] = {k: [1 if v.get("first") else 0, v.get("kills", 0)] for k, v in t["objectives"].items()}
        else:  # v4 team block
            obj[tid] = {
                "champion": [1 if t.get("firstBlood") else 0, None],
                "tower": [1 if t.get("firstTower") else 0, t.get("towerKills")],
                "inhibitor": [1 if t.get("firstInhibitor") else 0, t.get("inhibitorKills")],
                "baron": [1 if t.get("firstBaron") else 0, t.get("baronKills")],
                "dragon": [1 if t.get("firstDragon") else 0, t.get("dragonKills")],
                "riftHerald": [1 if t.get("firstRiftHerald") else 0, t.get("riftHeraldKills")],
            }
    out["obj"] = obj
    extras = {}
    for p in data["participants"]:
        st = p.get("stats") or p
        ch = p.get("challenges") or {}
        e = {"vision": st.get("visionScore"), "wards": st.get("wardsPlaced"), "wk": st.get("wardsKilled"),
             "cw": st.get("detectorWardsPlaced", st.get("visionWardsBoughtInGame")),
             "taken": st.get("totalDamageTaken"), "mitig": st.get("damageSelfMitigated"),
             "turret_dmg": st.get("damageDealtToTurrets"), "obj_dmg": st.get("damageDealtToObjectives"),
             "cc": st.get("timeCCingOthers"), "heal_ally": st.get("totalHealsOnTeammates"),
             "shield_ally": st.get("totalDamageShieldedOnTeammates"),
             "plates": ch.get("turretPlatesTaken"), "solo": ch.get("soloKills"),
             "lane_adv": ch.get("laningPhaseGoldExpAdvantage"),
             "early_adv": ch.get("earlyLaningPhaseGoldExpAdvantage"),
             "max_cs_adv": ch.get("maxCsAdvantageOnLaneOpponent")}
        extras[str(p.get("participantId"))] = {k: (round(v, 3) if isinstance(v, float) else v)
                                               for k, v in e.items() if v is not None}
    out["x"] = extras
    if not tl or not tl.get("frames"):
        return out
    gold, xp, cs, lvl = [], [], [], []
    for fr in tl["frames"]:
        pf = fr.get("participantFrames") or {}
        g, x, c, lv = [], [], [], []
        for pid in range(1, 11):
            f = pf.get(str(pid)) or {}
            g.append(f.get("totalGold", 0))
            x.append(f.get("xp", 0))
            c.append((f.get("minionsKilled") or 0) + (f.get("jungleMinionsKilled") or 0))
            lv.append(f.get("level", 0))
        gold.append(g)
        xp.append(x)
        cs.append(c)
        lvl.append(lv)
    out.update(gold=gold, xp=xp, cs=cs, lvl=lvl)
    ev = []
    items = {str(i): [] for i in range(1, 11)}
    skills = {str(i): [] for i in range(1, 11)}
    for fr in tl["frames"]:
        for e in fr.get("events") or []:
            typ = e.get("type")
            t = round((e.get("timestamp") or 0) / 1000.0, 1)
            if typ == "CHAMPION_KILL":
                k, v = e.get("killerId") or 0, e.get("victimId") or 0
                team = team_of(k) or (300 - team_of(v) if team_of(v) else 0)
                pos = e.get("position") or {}
                ev.append([t, "K", team, k, v, e.get("assistingParticipantIds") or [],
                           round((pos.get("x") or 0) / 100), round((pos.get("y") or 0) / 100)])
            elif typ == "ELITE_MONSTER_KILL":
                team = e.get("killerTeamId") or team_of(e.get("killerId") or 0)
                ev.append([t, "M", team, e.get("monsterType"), e.get("monsterSubType")])
            elif typ == "BUILDING_KILL":  # teamId = the team that LOST the building
                ev.append([t, "B", e.get("teamId"), e.get("buildingType"), e.get("towerType"), e.get("laneType")])
            elif typ == "TURRET_PLATE_DESTROYED":
                ev.append([t, "P", e.get("teamId"), e.get("laneType")])
            elif typ == "DRAGON_SOUL_GIVEN":
                ev.append([t, "S", e.get("teamId"), e.get("name")])
            elif typ == "CHAMPION_SPECIAL_KILL" and e.get("killType") == "KILL_FIRST_BLOOD":
                ev.append([t, "FB", team_of(e.get("killerId") or 0), e.get("killerId")])
            elif typ == "GAME_END":
                ev.append([t, "E", e.get("winningTeam")])
            elif typ == "ITEM_PURCHASED":
                lst = items.get(str(e.get("participantId")))
                if lst is not None:
                    lst.append([t, e.get("itemId")])
            elif typ == "ITEM_UNDO":
                lst = items.get(str(e.get("participantId")))
                before, after = e.get("beforeId"), e.get("afterId")
                if lst and before and not after:  # undid a purchase
                    for i in range(len(lst) - 1, -1, -1):
                        if lst[i][1] == before:
                            del lst[i]
                            break
            elif typ == "SKILL_LEVEL_UP":
                lst = skills.get(str(e.get("participantId")))
                if lst is not None and e.get("levelUpType", "NORMAL") == "NORMAL" and e.get("skillSlot"):
                    lst.append(str(e["skillSlot"]))
    if not out["win"]:
        end = [x for x in ev if x[1] == "E"]
        out["win"] = end[-1][2] if end else None
    if not out["dur"] and tl["frames"]:
        out["dur"] = round((tl["frames"][-1].get("timestamp") or 0) / 1000)
    out.update(ev=ev, items=items, skills={k: "".join(v) for k, v in skills.items()})
    return out


def _meta(cargo, overview_page):
    return cargo.query_all(
        "PostgameJsonMetadata=P",
        "P.GameId=GameId,P.RiotPlatformGameId=Rpgid,P.StatsPage=StatsPage,P.TimelinePage=TimelinePage,P.RiotVersion=Version",
        where=f"P.OverviewPage='{esc(overview_page)}'", order_by="P.GameId")


def _pages(cargo, titles):
    d = cargo._get({"action": "query", "format": "json", "prop": "revisions", "rvprop": "content",
                    "rvslots": "main", "titles": "|".join(titles)})
    q = d.get("query") or {}
    norm = {n["to"]: n["from"] for n in q.get("normalized", [])}
    out = {}
    for p in (q.get("pages") or {}).values():
        revs = p.get("revisions")
        if not revs:
            continue
        r = revs[0]
        content = ((r.get("slots") or {}).get("main") or {}).get("*") or r.get("*")
        if not content:
            continue
        try:
            out[norm.get(p["title"], p["title"])] = json.loads(content)
        except ValueError:
            continue
    return out


def _save(path, cache):
    tmp = str(path) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)


def update(cargo, champions, verbose=True, force=False, only=None, skip_before=None, regions=False):
    """Fetch timelines for every LCK / international game in the database that isn't cached yet
    (regions=True: the other regions' games in data/regions.db, cached in data/timelines_regions)."""
    from . import db
    from . import regions as _regions
    log = print if verbose else (lambda *a, **k: None)
    con = _regions.connect() if regions else db.connect()
    tl_dir = TL_REGIONS_DIR if regions else TL_DIR
    tours = [dict(r) for r in con.execute("SELECT overview_page, name, league, date_end FROM tournaments")]
    by_tour = defaultdict(set)
    for r in con.execute("SELECT game_id, overview_page, date_utc FROM games"):
        if skip_before and str(r["date_utc"]) < skip_before:
            continue
        by_tour[r["overview_page"]].add(r["game_id"])
    con.close()
    os.makedirs(tl_dir, exist_ok=True)
    maps = champ_maps(champions)
    today = dt.date.today()
    added = 0
    tours.sort(key=lambda t: str(t.get("date_end") or "9999"), reverse=True)  # newest events first
    for t in tours:
        want_all = by_tour.get(t["overview_page"])
        if t["league"] in SKIP_LEAGUES or not want_all:
            continue
        if only and only.lower() not in (t["name"] or "").lower():
            continue
        path = tl_dir / f"{slug(t['overview_page'])}.json"
        cache = {"overview_page": t["overview_page"], "games": {}, "missing": []}
        if path.exists() and not force:
            with open(path, encoding="utf-8") as f:
                cache = json.load(f)
        end = _parse_date(t.get("date_end"))
        final = bool(end and end + dt.timedelta(days=5) < today)
        skip = set(cache["games"]) | (set(cache.get("missing", [])) if final else set())
        want = sorted(want_all - skip)
        if not want:
            continue
        meta = defaultdict(list)
        for m in _meta(cargo, t["overview_page"]):
            meta[m.get("GameId")].append(m)
        todo = [(gid, meta[gid]) for gid in want if meta.get(gid)]
        missing = [gid for gid in want if not meta.get(gid)]
        log(f"      timelines {t['name']}: {len(todo)} to fetch, {len(missing)} without Riot data", flush=True)
        cache["missing"] = sorted(set(cache.get("missing", [])) | set(missing))
        for i in range(0, len(todo), BATCH_GAMES):
            batch = todo[i:i + BATCH_GAMES]
            titles = [m[k] for _, ms in batch for m in ms for k in ("StatsPage", "TimelinePage") if m.get(k)]
            try:
                pages = _pages(cargo, titles)
            except RuntimeError as exc:
                log(f"        ! {exc}; will retry next update")
                continue
            for gid, ms in batch:
                best = None
                for m in ms:  # a remade game has several entries: keep the one that was played out
                    rec = compact(pages.get(m.get("StatsPage")), pages.get(m.get("TimelinePage")), maps)
                    if rec and rec.get("win") and (best is None or rec["dur"] > best["dur"]):
                        rec["rpgid"] = m.get("Rpgid")
                        best = rec
                if best:
                    cache["games"][gid] = best
                    added += 1
                    if gid in cache["missing"]:
                        cache["missing"].remove(gid)
                elif gid not in cache["missing"]:
                    cache["missing"].append(gid)
            if (i // BATCH_GAMES) % 10 == 9:
                _save(path, cache)
        cache["fetched_at"] = dt.datetime.now().isoformat(timespec="seconds")
        _save(path, cache)
    return added


def load(con=None, champions=None, tl_dir=None):
    """game_id -> compact record with 'side' {participantId: (map side, role)}; only records that
    agree with the database (same winner, same champions on the same map side).
    tl_dir=TL_REGIONS_DIR with con=regions.connect() loads the other regions' timelines."""
    from . import db
    tl_dir = tl_dir or TL_DIR
    own = con is None
    con = con or db.connect()
    picks = defaultdict(dict)
    for r in con.execute("SELECT game_id, map_side, role, champion FROM players"):
        picks[r["game_id"]][(r["map_side"], r["champion"])] = r["role"]
    winners, dates = {}, {}
    for r in con.execute("SELECT game_id, winner_side, date_utc FROM games"):
        winners[r["game_id"]] = r["winner_side"]
        dates[r["game_id"]] = str(r["date_utc"] or "")[:10]
    if own:
        con.close()
    out = {}
    if not tl_dir.exists():
        return out
    for fn in sorted(os.listdir(tl_dir)):
        if not fn.endswith(".json"):
            continue
        with open(tl_dir / fn, encoding="utf-8") as f:
            cache = json.load(f)
        for gid, rec in cache.get("games", {}).items():
            if gid not in winners or not rec.get("win"):
                continue
            pk = picks.get(gid, {})
            roles = {}
            for pid, (team, champ, _who) in rec["p"].items():
                side = "blue" if team == 100 else "red"
                role = pk.get((side, champ))
                if role is None:
                    break
                roles[pid] = (side, role)
            if len(roles) != 10:
                continue
            if ("blue" if rec["win"] == 100 else "red") != winners[gid]:
                continue
            rec["side"] = roles
            rec["date"] = dates[gid]
            rec["year"] = int(dates[gid][:4]) if dates[gid][:4].isdigit() else 0
            out[gid] = rec
    return out
