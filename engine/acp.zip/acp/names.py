"""Champion-name resolution: 'ksante', 'j4', 'mf', 'nunu', typos -> canonical names."""
import difflib
import re

ALIASES = {
    "mf": "Miss Fortune", "tf": "Twisted Fate", "j4": "Jarvan IV", "jarvan": "Jarvan IV",
    "asol": "Aurelion Sol", "aurelion": "Aurelion Sol", "sol": "Aurelion Sol",
    "nunu": "Nunu & Willump", "renata": "Renata Glasc", "wu": "Wukong", "monkeyking": "Wukong",
    "mundo": "Dr. Mundo", "gp": "Gangplank", "kha": "Kha'Zix", "k6": "Kha'Zix", "cho": "Cho'Gath",
    "rek": "Rek'Sai", "vel": "Vel'Koz", "kog": "Kog'Maw", "tk": "Tahm Kench", "tahm": "Tahm Kench",
    "heimer": "Heimerdinger", "donger": "Heimerdinger", "fiddle": "Fiddlesticks", "fid": "Fiddlesticks",
    "malz": "Malzahar", "morde": "Mordekaiser", "naut": "Nautilus", "blitz": "Blitzcrank",
    "ez": "Ezreal", "cait": "Caitlyn", "trist": "Tristana", "xin": "Xin Zhao", "lee": "Lee Sin",
    "yi": "Master Yi", "lb": "LeBlanc", "kass": "Kassadin", "kata": "Katarina", "liss": "Lissandra",
    "ori": "Orianna", "voli": "Volibear", "ww": "Warwick", "sej": "Sejuani", "seju": "Sejuani",
    "nida": "Nidalee", "noc": "Nocturne", "panth": "Pantheon", "rene": "Renekton", "renek": "Renekton",
    "raka": "Soraka", "sera": "Seraphine", "shyv": "Shyvana", "trynd": "Tryndamere", "tryn": "Tryndamere",
    "vlad": "Vladimir", "yas": "Yasuo", "zil": "Zilean", "hec": "Hecarim", "ali": "Alistar",
    "mumu": "Amumu", "aph": "Aphelios", "aphe": "Aphelios", "cass": "Cassiopeia", "cassio": "Cassiopeia",
    "eve": "Evelynn", "ire": "Irelia", "malph": "Malphite", "mao": "Maokai", "morg": "Morgana",
    "tali": "Taliyah", "qiy": "Qiyana", "bel": "Bel'Veth", "kalis": "Kalista", "naafi": "Naafiri",
    "smol": "Smolder", "yuna": "Yunara", "amb": "Ambessa", "rat": "Twitch", "sona": "Sona",
}


def key(text):
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


class ChampNames:
    def __init__(self, champions):
        """champions: dict name -> ddragon record (needs 'id')."""
        self.names = sorted(champions)
        self.by_key = {}
        for name, rec in champions.items():
            self.by_key[key(name)] = name
            if rec.get("id"):
                self.by_key.setdefault(key(rec["id"]), name)
        for alias, name in ALIASES.items():
            if name in champions:
                self.by_key.setdefault(key(alias), name)

    def canon(self, text):
        """Best-effort canonical name, or None. Used for data cleaning."""
        if not text:
            return None
        return self.by_key.get(key(text))

    def resolve(self, text):
        """Strict resolution for user input; raises ValueError with suggestions."""
        k = key(text)
        if not k:
            raise ValueError("empty champion name")
        if k in self.by_key:
            return self.by_key[k]
        starts = sorted({n for kk, n in self.by_key.items() if kk.startswith(k)})
        if len(starts) == 1:
            return starts[0]
        if len(starts) > 1:
            raise ValueError(f"'{text}' is ambiguous: {', '.join(starts[:8])}")
        close = difflib.get_close_matches(k, list(self.by_key), n=3, cutoff=0.72)
        if close:
            return self.by_key[close[0]]
        raise ValueError(f"unknown champion '{text}'")
