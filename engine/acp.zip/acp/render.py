"""Render advisor results as compact, organised Markdown (reads fine in a terminal too)."""
from . import ROLE_NAMES, ROLES
from .engine import SIDE_NAME

LEAGUE_SHORT = {
    "LoL Champions Korea": "LCK", "Tencent LoL Pro League": "LPL", "First Stand": "First Stand",
    "Mid-Season Invitational": "MSI", "Esports World Cup": "EWC", "World Championship": "Worlds",
}

STANDARD_START = {"TOP": "Doran's Blade", "JNG": "jungle pet", "MID": "Doran's Ring",
                  "BOT": "Doran's Blade", "SUP": "World Atlas"}


RECENT_DAYS = [90]  # set from the data summary at render time


def _pct(x):
    return "-" if x is None else f"{x:.0%}"


def _role(r):
    return ROLE_NAMES.get(r, r)


def header(summary):
    leagues = ", ".join(LEAGUE_SHORT.get(k, k) for k in summary["leagues"])
    first = summary["first"].strftime("%Y-%m-%d") if summary["first"] else "?"
    last = summary["last"].strftime("%Y-%m-%d") if summary["last"] else "?"
    extra = ""
    if summary.get("region_games"):
        w = summary.get("region_weight") or 0.0
        extra = (f" Plus {summary['region_games']:,} games from other regions (LEC, LCS, CBLOL, LCP, VCS, LJL) for team "
                 f"ratings and player pools" + (f", counted {w:g}x in champion stats" if w else "") + ".")
    return (f"*Pro data: {summary['games']:,} games ({leagues}), {first} to {last}. "
            f"Newest: {summary['latest_event']}, patch {summary['latest_patch']}. "
            f"Weighted toward recent games.{extra}*")


def draft_block(res):
    st = res["draft"]
    lines = ["## Draft"]
    for side in "BR":
        s = st[side]
        picks = " · ".join(f"{p['champ']} ({_role(p['role'])})" for p in s["picks"]) or "-"
        bans = ", ".join(s["bans"]) or "-"
        team = f" [{s['team']}]" if s.get("team") else ""
        tag = " (first pick)" if side == "B" else ""
        lines.append(f"- **{SIDE_NAME[side]}{tag}{team}:** {picks}. Bans: {bans}")
    if st.get("fearless"):
        lines.append(f"- **Fearless (locked):** {', '.join(st['fearless'])}")
    if st.get("fp_side"):
        lines.append(f"- **Map side:** first-pick team on {st['fp_side']} side")
    nxt = res.get("next")
    if nxt:
        act = f"{SIDE_NAME[nxt['side']]} {nxt['action']} {nxt['n']}"
        if nxt["action"] == "pick":
            act += f" ({nxt['side']}{nxt['n']})"
        extra = " (double pick)" if nxt.get("double") else ""
        lines.append(f"- **Next: {act}{extra}**")
    return "\n".join(lines)


DRIVER_LABEL = {"vs_their_picks": "vs their picks", "vs_their_likely_picks": "vs what they'll likely pick",
                "with_your_picks": "with your picks", "champion": "champion strength",
                "player_comfort": "player comfort"}


def reasons(rec):
    ev, k = rec["evidence"], rec["components"]
    out = []
    if ev.get("win_after") is not None:
        drv = sorted(((v, n) for n, v in (ev.get("drivers") or {}).items() if abs(v) >= 0.1), reverse=True)
        why = ", ".join(f"{DRIVER_LABEL[n]} {v:+.1f}" for v, n in drv[:3])
        out.append(f"**Win model:** {ev['win_before']:.1%} → **{ev['win_after']:.1%}** win chance "
                   f"({k['win']:+.1f} pts){': ' + why if why else ''}")
    if ev.get("recent_n"):
        recent = f"{ev['recent_record']} ({_pct(ev['recent_wr'])}) in the last {RECENT_DAYS[0]} days"
    else:
        recent = f"no games in the last {RECENT_DAYS[0]} days"
    out.append(f"**Meta:** {_pct(ev['presence'])} presence ({_pct(ev['pick'])} pick, {_pct(ev['ban'])} ban) · "
               f"{recent} · {ev['record']} overall as {_role(rec['role'])}")
    if ev.get("lane"):
        ln = ev["lane"]
        w_, l_ = (int(x) for x in ln["record"].split("-"))
        verdict = " (wins the lane)" if w_ - l_ >= 3 else (" (risky lane)" if l_ - w_ >= 3 else "")
        out.append(f"**Lane:** {ln['record']} head-to-head vs {ln['opp']}{verdict}")
    if ev.get("duo") and ev["duo"]["n"] >= 3:
        d = ev["duo"]
        out.append(f"**2v2:** {d['record']} vs {d['opp']}")
    syn = [s for s in rec["synergy"] if s[0] >= 0.015 and s[3] >= 3
           and int(s[2].split("-")[0]) > int(s[2].split("-")[1])]
    if syn:
        out.append("**Synergy:** " + ", ".join(f"{s[2]} with {s[1]}" for s in syn[:2]))
    # show a counter only when it beats expectation AND the raw record is actually winning
    cnt = [c for c in rec["counters"] if c[0] >= 0.02 and c[3] >= 3
           and int(c[2].split("-")[0]) > int(c[2].split("-")[1])]
    if cnt:
        out.append("**Counters:** " + ", ".join(f"{c[2]} vs {c[1]}" for c in cnt[:2]))
    if rec["fit_notes"]:
        out.append("**Comp:** " + "; ".join(rec["fit_notes"]))
    bs = ev.get("blind_share")
    if bs is not None:
        if bs >= 0.6:
            out.append(f"**Draft:** safe blind pick (pros lock it in before seeing the enemy laner {_pct(bs)} of the time)")
        elif bs <= 0.35:
            out.append(f"**Draft:** usually a counter-pick ({_pct(bs)} blind); risky this early")
    if k.get("flex", 0) > 0:
        out.append(f"**Flex:** {'/'.join(_role(r) for r in rec['flex_roles'])}, which hides your role assignment")
    if k.get("denial", 0) >= 0.8:
        out.append("**Denial:** also one of the enemy's best remaining picks")
    if ev.get("comfort"):
        c = ev["comfort"]
        if c["games"] >= 0.05:
            out.append(f"**Comfort:** {c['player']} has played it in pro ({c['record']})")
        else:
            out.append(f"**Comfort:** not in {c['player']}'s recent pro pool")
    return out


def breakdown(rec):
    k = rec["components"]
    order = ["win", "meta", "comp", "blind", "flex", "denial", "role"]
    return " · ".join(f"{n} {k[n]:+.1f}" for n in order if abs(k.get(n, 0)) >= 0.05)


def pick_block(res):
    recs = res["recs"]
    best = recs[0]
    who = SIDE_NAME[res["acting"]]
    title = "Pick" if res.get("perspective") == "us" else f"{who}'s most likely pick"
    lines = [f"## {title}: {best['champ']} ({_role(best['role'])}), rating {best['rating']}"]
    lines += [f"- {r}" for r in reasons(best)]
    lines.append(f"- *Score: {breakdown(best)}*")
    if len(recs) > 1:
        alts = " · ".join(f"{r['champ']} ({_role(r['role'])}) {r['rating']}" for r in recs[1:])
        lines.append(f"\n**Alternatives:** {alts}")
    pair = res.get("pair")
    if pair:
        f, s = pair["first"], pair["second"]
        lines.append(f"**Double pick:** {f['champ']} ({_role(f['role'])}) + {s['champ']} ({_role(s['role'])})")
    then = res.get("then") or {}
    if then:
        parts = [f"{_role(r)}: {', '.join(x['champ'] for x in xs)}" for r, xs in then.items() if xs]
        needs = (res.get("plan") or {}).get("needs") or []
        need_txt = f" (still needs {', '.join(needs)})" if needs else ""
        if parts:
            lines.append(f"**To finish the comp{need_txt}:** {' · '.join(parts)}")
    if res.get("threats"):
        lines.append("**Enemy's likely next pick:** " + ", ".join(
            f"{c} ({_role(r)}) {p:.0%}" for c, r, p in res["threats"]))
    return "\n".join(lines)


def ban_block(res):
    side = SIDE_NAME[res["acting"]]
    bans = res["bans"]
    lines = [f"## {side} ban: {bans[0]['champ']}"]
    for i, b in enumerate(bans, 1):
        ev = b["evidence"]
        why = []
        if b.get("likely") is not None:
            why.append(f"{_pct(b['likely'])} likely to be picked by them")
        if b["components"]["win"] > 0.05:
            why.append(f"+{b['components']['win']:.1f} pts for them")
        why.append(f"{_pct(ev['presence'])} presence")
        if ev.get("recent_n"):
            why.append(f"{ev['recent_record']} recently")
        why.append(f"{ev['record']} overall")
        if ev.get("lane"):
            why.append(f"{ev['lane']['record']} vs your {ev['lane']['opp']}")
        why += b["fit_notes"][:1]
        lines.append(f"{i}. **{b['champ']}** ({_role(b['role'])}): {', '.join(why)}")
    own = res.get("own_targets") or []
    ban_names = {b["champ"] for b in bans}
    keep = [o for o in own if o["champ"] not in ban_names]
    if keep:
        lines.append(f"\n**Your priority picks (don't ban):** {', '.join(o['champ'] + ' (' + _role(o['role']) + ')' for o in keep)}")
    if own and own[0]["champ"] in ban_names and res["acting"] == "B" and res["next"]["seq"] <= 6:
        lines.append(f"*{own[0]['champ']} is also your best pick. You have first pick, so you can take it at B1 instead of banning it.*")
    return "\n".join(lines)


def plan_block(plan, title_prefix="Win con"):
    partial = " Draft still in progress, so this firms up as picks lock in." if plan.get("partial") else ""
    lines = [f'## {title_prefix}: "{plan["name"]}"',
             f"*{plan['label']} (also {plan['secondary'].lower()}). Tempo: {plan['tempo']}.{partial}*",
             "", plan["story"] + (" " + plan["tempo_line"] if plan.get("tempo_line") else ""), "",
             f"- **Early (0-14 min):** {plan['early']}",
             f"- **Mid (14-25 min):** {plan['mid']}",
             f"- **Late (25+ min):** {plan['late']}", "",
             "### ✅ Win conditions"]
    lines += [f"{i}. {w}" for i, w in enumerate(plan["win"], 1)]
    lines += ["", "### ❌ Lose conditions"]
    lines += [f"{i}. {l}" for i, l in enumerate(plan["lose"], 1)] or ["- (enemy comp not known yet)"]
    if plan.get("tested"):
        lines += ["", "### 📊 Tested in pro games"] + [f"- {t}" for t in plan["tested"]]
    likely = plan.get("their_likely") or {}
    if likely:
        lines.append("\n*Their comp above includes the predicted picks " + ", ".join(
            f"{c} ({_role(r)}, {p:.0%})" for r, (c, p) in likely.items()) + ".*")
    return "\n".join(lines)


def build_block(bd, heading=True):
    if not bd:
        return "## Runes & items\n- No pro games recorded for this champion in this role."
    role = bd["role"]
    lines = []
    if heading:
        lines.append(f"## Runes: {bd['champion']} ({_role(role)}), from {bd['n']} pro games")
    pg = bd.get("page")
    if pg:
        lines.append(f"- **{pg['primary']}:** **{pg['keystone']}**, {', '.join(pg['primary_runes'])}")
        lines.append(f"- **{pg['secondary']}:** {', '.join(pg['secondary_runes'])}")
        if pg.get("shards"):
            lines.append(f"- **Shards:** {', '.join(pg['shards'])}")
    ks = [(k, v) for k, v in bd.get("keystones") or [] if v >= 0.03]
    if ks:
        lines.append("- Keystones used: " + " · ".join(f"{k} {_pct(v)}" for k, v in ks))
    kr = bd.get("keystone_by_range") or {}
    if len(kr) == 2 and kr["M"][0] != kr["R"][0]:
        lines.append(f"- Lane-dependent: **{kr['M'][0]}** vs melee, **{kr['R'][0]}** vs ranged")
    vs = bd.get("vs_runes")
    if vs:
        lines.append(f"- vs {vs['opp']} ({vs['n']} games): " + " · ".join(f"{k} {_pct(v)}" for k, v in vs["keystones"]))
    spells = [(s, v) for i, (s, v) in enumerate(bd.get("spells") or []) if i == 0 or v >= 0.05]
    if spells:
        lines.append("- **Spells:** " + " · ".join(f"{s} ({_pct(v)})" for s, v in spells))
    tl = bd.get("timeline") if bd.get("order_source") == "timeline" else None
    if heading:
        src = (f" (real purchase order from {tl['games']} LCK/international games with Riot timelines)"
               if tl else "")
        lines.append(f"\n## Items: {bd['champion']}{src}")
    else:
        lines.append("")
    if tl:
        lines += _timeline_items(bd, tl)
    else:
        lines += _inferred_items(bd, role)
    if bd.get("items_for"):
        lines.append(f"- *Items and skills above are from games with {bd['items_for']}, the page shown.*")
    ab = bd.get("alt_build")
    if ab:
        lines.append(f"- **With {ab['keystone']} instead ({_pct(ab['share'])} of games):** " + " → ".join(ab["items"]))
    if bd.get("support_item"):
        si = bd["support_item"]
        lines.append(f"- **Support item:** {si['item']} ({_pct(si['share'])})")
    sit = [s for s in bd.get("situational", []) if s["share"] >= 0.08]
    if sit:
        lines.append("- **Situational:** " + " · ".join(
            f"{s['item']} ({_pct(s['share'])}{', ' + s['note'] if s['note'] else ''})" for s in sit))
    sk = skills_line(bd.get("skills"))
    if sk:
        lines.append(f"- **Skills:** {sk}")
    return "\n".join(l for l in lines if l is not None)


def _mmss(t):
    return f"{int(t) // 60}:{int(t) % 60:02d}" if t is not None else "?"


def _mins(t):
    return f"~{max(1, round(t / 60))} min" if t is not None else ""


def combo_text(combo):
    """((item, count), ...) -> 'Doran's Blade + Health Potion x2'."""
    return " + ".join(f"{n} x{c}" if c > 1 else n for n, c in combo)


def skills_line(sk):
    """'Q E W, then max Q > E > W · R at 6/11/16 (Q maxed first in 88% of 87 games)'."""
    if not sk or not sk.get("max"):
        return None
    out = f"{' '.join(sk['start'])} ({_pct(sk['start_share'])}), then max {' > '.join(sk['max'])}"
    if sk.get("r_levels"):
        out += f" · R at {'/'.join(map(str, sk['r_levels']))}"
    if sk.get("max_share") is not None:
        out += f" ({sk['max'][0]} maxed first in {_pct(sk['max_share'])} of {sk['games']} games)"
    return out


def _timeline_items(bd, tl):
    lines = []
    st = tl.get("start") or []
    if st:
        txt = f"{combo_text(st[0]['items'])} ({_pct(st[0]['share'])})"
        if len(st) > 1:
            txt += f" · or {combo_text(st[1]['items'])} ({_pct(st[1]['share'])})"
        lines.append(f"- **Start:** {txt}")
    now = tl.get("start_now")
    if now and st and now["items"] != st[0]["items"]:
        lines.append(f"- **Start vs {now['opp']}:** {combo_text(now['items'])} "
                     f"({_pct(now['share'])} of {now['games']} games vs {'ranged' if now['range'] == 'R' else 'melee'} lanes)")
    fb = tl.get("first_back")
    if fb:
        what = (f"{combo_text(fb['combo'])} ({_pct(fb['combo_share'])})" if fb.get("combo")
                else " · ".join(f"{n} {_pct(x)}" for n, x in fb["items"]))
        if what:
            lines.append(f"- **First back (~{_mmss(fb['t'])}):** {what}")
    steps = []
    for s in tl.get("order") or []:
        alt = f" / {s['alt'][0][0]}" if s.get("alt") else ""
        if s["kind"] == "boots":
            up = (bd.get("boots") or {}).get("upgrade")
            steps.append(f"{s['item']} ({_mins(s['t'])}{', later ' + up if up else ''})")
        else:
            steps.append(f"{s['item']}{alt} ({_mins(s['t'])}, {_pct(s['share'])})")
    if steps:
        lines.append("- **Build order:** " + " → ".join(steps))
    tr = tl.get("trinket")
    if tr:
        lines.append(f"- **Trinket:** {tr['item']} at ~{_mmss(tr['t'])} ({_pct(tr['share'])} of games)")
    return lines


def _inferred_items(bd, role):
    lines = []
    start = " or ".join(bd["start"]) if bd.get("start") else STANDARD_START.get(role, "-")
    tag = "" if bd.get("start") else " (standard start)"
    lines.append(f"- **Start:** {start}{tag}")
    path = bd.get("path") or []
    boots = bd.get("boots")
    steps, placed = [], False
    boots_txt = None
    if boots:
        up = f", later {boots['upgrade']}" if boots.get("upgrade") else ""
        boots_txt = f"{boots['item']} ({_pct(boots['type_share'])} of boots{up})"
    for p in path:
        alt = f" / {p['alt'][0][0]}" if p.get("alt") else ""
        steps.append(f"{p['item']}{alt} ({_pct(p['share'])})")
        if boots_txt and not placed and p["slot"] >= boots["after_slot"]:
            steps.append(boots_txt)
            placed = True
    if boots_txt and not placed:
        steps.append(boots_txt)
    if steps:
        lines.append("- **Build order:** " + " → ".join(steps) + " *(order inferred from final items)*")
    return lines


def ingame_block(res):
    """What-if table: how a gold lead at 10-25 min changes this draft's win chance (lab in-game models)."""
    ig = res.get("ingame") or {}
    out = []
    live = res.get("live")
    if live:
        out += ["", f"## Live at {live['minute']:g} min: Blue {live['p']:.0%} · Red {1 - live['p']:.0%}",
                f"*Score given (Blue minus Red): {live['text']}. Pre-game it was Blue {res['verdict']['p_blue']:.0%}.*"]
    wi = ig.get("whatif")
    if wi:
        out += ["", "### If the game goes like this (Blue's win chance, from LCK + international timelines)",
                "| Gold at | Blue 3k down | 1.5k down | Even | 1.5k up | 3k up |", "|---|---|---|---|---|---|"]
        for m, row in wi.items():
            out.append(f"| {m} min | " + " | ".join(f"{row[g]:.0%}" for g in ("-3", "-1.5", "0", "1.5", "3")) + " |")
    return out


def markdown(res):
    RECENT_DAYS[0] = res["summary"].get("recent_days", 90)
    out = [header(res["summary"]), "", draft_block(res), ""]
    if res.get("error"):
        out.append(f"**{res['error']}**")
        return "\n".join(out)
    if res.get("complete"):
        v = res["verdict"]
        pb = v["p_blue"]
        fav, p = ("Blue", pb) if pb >= 0.5 else ("Red", 1 - pb)
        size = "clear" if p >= 0.6 else ("slight" if p >= 0.53 else "coin-flip")
        ci = v.get("ci")
        rng = f" (90% range {ci[0]:.0%}-{ci[1]:.0%})" if ci else ""
        out.append(f"## Verdict: Blue {pb:.0%} · Red {1 - pb:.0%}{rng}, {size} edge to {fav}")
        if v.get("team_only") is not None:
            out.append(f"*Teams{' + map side' if v.get('map_side') else ''} alone: Blue {v['team_only']:.0%}. "
                       f"With this draft: {pb:.0%}.*")
        info = v.get("info") or {}
        acc = (info.get("oos_accuracy") or {}).get(v.get("model", "draft"))
        if acc:
            out.append(f"*Win model learned from {info.get('games', '?'):,} pro games, each predicted before its result. "
                       f"It called {acc:.1%} of them correctly. Draft is only part of a pro game.*")
        cal = v.get("calibration")
        if cal:
            out.append(f"*When the model said {cal['bucket']}, the favored side won {cal['won']}/{cal['games']} "
                       f"({cal['won'] / cal['games']:.0%}) in backtests.*")
        for side in "BR":
            top = [f"{c} {d:+.1f}" for _, c, d in v["drivers"][side][:2] if d > 0]
            if top:
                out.append(f"- {SIDE_NAME[side]} edge comes from: {', '.join(top)}")
        out += ingame_block(res)
        for side, plan in res["plans"].items():
            out.append("")
            out.append(plan_block(plan, title_prefix=f"{SIDE_NAME[side]} win con"))
            tb = res["team_builds"].get(side, {})
            out.append(f"\n### {SIDE_NAME[side]} builds")
            for r in ROLES:
                bd = tb.get(r)
                if bd and bd.get("page"):
                    pg = bd["page"]
                    items = " → ".join(p["item"] for p in bd.get("path", [])[:3])
                    sk = bd.get("skills") or {}
                    mx = f" · max {'>'.join(sk['max'])}" if sk.get("max") else ""
                    out.append(f"- **{bd['champion']}** ({_role(r)}): {pg['keystone']} + {pg['secondary']} · {items}{mx}")
        return "\n".join(out)
    if res.get("bans"):
        out.append(ban_block(res))
        return "\n".join(out)
    out.append(pick_block(res))
    out.append("")
    plan_title = "Win con" if res.get("perspective") == "us" else f"{SIDE_NAME[res['plan_side']]} win con"
    if res.get("plan"):
        out.append(plan_block(res["plan"], plan_title))
        out.append("")
    out.append(build_block(res.get("build")))
    return "\n".join(out)


def champion_markdown(rep):
    if rep.get("error"):
        return f"**{rep['champ']}:** {rep['error']}"
    RECENT_DAYS[0] = rep["summary"].get("recent_days", 90)
    recent = (f"{rep['recent_record']} in the last {RECENT_DAYS[0]} days" if rep.get("recent_n")
              else f"no games in the last {RECENT_DAYS[0]} days")
    out = [header(rep["summary"]), "",
           f"## {rep['champ']} ({_role(rep['role'])})",
           f"- **Meta:** {_pct(rep['presence'])} presence ({_pct(rep['pick'])} pick, {_pct(rep['ban'])} ban) · "
           f"{recent} · {rep['record']} overall as {_role(rep['role'])}",
           "- **Roles:** " + " · ".join(f"{_role(r)} {_pct(s)}" for r, s in rep["roles"] if s >= 0.03),
           f"- **Blind-pick rate:** {_pct(rep['blind_share'])}"]
    if rep["best_lanes"]:
        out.append("- **Best matchups:** " + ", ".join(f"{o} {rec}" for _, o, rec, _ in rep["best_lanes"]))
        out.append("- **Worst matchups:** " + ", ".join(f"{o} {rec}" for _, o, rec, _ in rep["worst_lanes"]))
    if rep["best_synergy"]:
        out.append("- **Best partners:** " + ", ".join(f"{o} {rec}" for _, o, rec, _ in rep["best_synergy"]))
    ln = rep["length"]
    out.append("- **By game length:** " + " · ".join(
        f"{k} {v[0]}" for k, v in (("<28 min", ln["short"]), ("28-35", ln["mid"]), (">35 min", ln["long"]))))
    out.append("")
    out.append(build_block(rep["build"]))
    return "\n".join(out)
