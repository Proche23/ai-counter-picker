"""Solo queue by rank: the draft board's engine, run on one rank's solo queue games instead of pro games.

The solo queue database (acp/soloq.py, data/soloq.db) holds this season's ranked games of every rank,
Iron to Challenger, each counted for the rank of the ladder player it was found through. For a rank:

* Statistics: the same statistics class as the pro data (acp.stats.ProStats: recency-weighted champion
  win rates per role, lane matchups, bot lane 2v2s, synergies, pick and ban rates, comp archetypes),
  fed with that rank's games. The ranks next to it add evidence at a lower weight (NEIGHBOUR_W), so a
  champion few people play in Iron still gets an estimate, while the records shown stay the rank's own.
* The engine (SoloEngine): the pro engine with one change. Solo lanes snowball, so the lane matchups
  (same role, and the bot lane 2v2) get a weight of their own, apart from the rest of the matchups.
  All weights, and how sure the verdict is, are fitted per rank by the solo queue lab (soloq_lab.py ->
  data/soloq_model.json), on games the statistics never saw.
* Builds, runes, spells and skill order come from the rank's own games (purchase order from the games
  with a timeline), the live win chance from the rank's own minute-by-minute models.

Nothing here reads or changes the pro data: a SoloAdvisor is a separate object the page asks only in
solo queue mode.
"""
import datetime as dt
import json
import math
import os
import pickle
import threading
import time
from collections import Counter, defaultdict

from . import DATA, ROLES, soloq
from .advisor import Advisor
from .builds import Builds, ItemBook
from .comp import Planner
from .engine import Engine, clamp, sigmoid
from .predictor import EnemyPredictor
from .stats import ProStats

SOLO_MODEL = DATA / "soloq_model.json"
CACHE_DIR = DATA / "soloq_cache"
CACHE_VERSION = 3
NEIGHBOUR_W = {1: 0.35, 2: 0.12}   # evidence weight of a game one / two ranks away (the lab tests others)
KEEP_GAMES = 6000                  # the rank's newest games kept whole (builds); older ones only as statistics
SOLO_CFG = {
    # champion strength follows balance patches (every two weeks): a 3-week half-life; matchups move slower
    "half_life_days": {"meta": 21, "matchup": 75, "builds": 21, "pools": 30},
    "stats_max_age_days": 400,
    "regions": {"presence_weight": 1.0},   # (the neighbouring ranks' picks and bans count at their weight)
}
K = {"k_vs": 30.0, "k_syn": 12.0, "k_long": 20.0, "k_lane": 25.0}   # shrinkage (pseudo-games), solo's own
FEATURES = ["strength", "counter", "lane", "synergy"]
DEFAULT_MODEL = {   # until the lab has fitted a rank (roughly what solo queue research finds: lanes matter)
    "draft": {"bias": 0.03, "strength": 0.25, "counter": 0.6, "lane": 1.2, "synergy": 0.4, "comfort": 0.0},
    "calibration": {"draft": [1.0, 0.0]},
    "info": {"fitted": None, "note": "default weights: the solo queue lab hasn't fitted this rank yet"},
}
SHARDS = {5001: "Health Scaling", 5002: "Armor", 5003: "Magic Resist", 5005: "Attack Speed", 5007: "Ability Haste",
          5008: "Adaptive Force", 5010: "Move Speed", 5011: "Health", 5013: "Tenacity and Slow Resist"}
LANE_PAIRS = {(r, r) for r in ROLES} | {("BOT", "SUP"), ("SUP", "BOT")}


patch_name = soloq.patch_name   # ("16.23" -> "26.23")


def rank_distance(a, b):
    return abs(soloq.RANKS.index(a) - soloq.RANKS.index(b))


# ------------------------------------------------------------------ the database -> the statistics' rows
class Names:
    """Riot ids -> the names the pro data uses (items, runes, rune trees, summoner spells)."""

    def __init__(self, dd):
        self.items = ItemBook(dd.get("items"), dd.get("item_ids"))
        self.rune, self.tree = {}, {}
        for tree in dd.get("runes") or []:
            self.tree[tree.get("id")] = tree.get("name")
            for slot in tree.get("slots") or []:
                for ru in slot.get("runes") or []:
                    self.rune[ru.get("id")] = ru.get("name")
        self.rune.update(SHARDS)

    def item_list(self, text):
        try:
            ids = json.loads(text or "[]")
        except ValueError:
            return ""
        return ";".join(n for n in (self.items.name(i) for i in ids if i) if n)

    def spells(self, text):
        try:
            ids = json.loads(text or "[]")
        except ValueError:
            return ""
        return ",".join(soloq.SPELL_NAMES.get(i, str(i)) for i in ids if i)

    def page(self, text, keystone):
        """(keystone, primary tree, secondary tree, "keystone,3 primary,2 secondary,3 shards")"""
        try:
            pk = json.loads(text) if text else None
        except ValueError:
            pk = None
        if not pk or len(pk) < 11:
            ks = self.rune.get(keystone)
            return ks, None, None, ""
        runes = [self.rune.get(x) for x in pk[2:6] + pk[6:8] + pk[8:11]]
        if not all(runes[:6]):
            return self.rune.get(pk[2]), self.tree.get(pk[0]), self.tree.get(pk[1]), ""
        return runes[0], self.tree.get(pk[0]), self.tree.get(pk[1]), ",".join(r or "" for r in runes)


def load_rows(con, ranks, before_ms=None, after_ms=None):
    """The games of these ranks (optionally only those started in [after_ms, before_ms)):
    (matches {id: row}, players {id: [rows]}, bans {id: [rows]})."""
    tiers = [t for r in ranks for t in soloq.RANK_TIERS[r]]
    conds = [f"m.tier IN ({','.join('?' * len(tiers))})"]
    args = list(tiers)
    if before_ms is not None:
        conds.append("m.start_ms < ?")
        args.append(int(before_ms))
    if after_ms is not None:
        conds.append("m.start_ms >= ?")
        args.append(int(after_ms))
    where = " AND ".join(conds)
    matches = {r["match_id"]: dict(r) for r in con.execute(f"SELECT m.* FROM matches m WHERE {where}", args)}
    players, bans = defaultdict(list), defaultdict(list)
    for r in con.execute(f"SELECT p.* FROM players p JOIN matches m USING (match_id) WHERE {where}", args):
        players[r["match_id"]].append(dict(r))
    for r in con.execute(f"SELECT b.* FROM bans b JOIN matches m USING (match_id) WHERE {where}", args):
        bans[r["match_id"]].append(dict(r))
    return matches, players, bans


def to_raw(rows, rank, names, neighbour_w=None):
    """Solo games -> rows in the pro statistics' format (acp.stats.load_raw). The rank's own games are
    "core"; games of the ranks around it are "other region" games with their own weight (xw)."""
    nw = NEIGHBOUR_W if neighbour_w is None else neighbour_w
    matches, players, bans = rows
    out = {"games": [], "players": [], "actions": []}
    for mid, m in matches.items():
        r = soloq.rank_of(m["tier"])
        if not r:
            continue
        dist = rank_distance(r, rank)
        xw = 1.0 if dist == 0 else float(nw.get(dist, 0.0))
        if xw <= 0:
            continue
        ps = players.get(mid) or []
        if len(ps) != 10:
            continue
        when = dt.datetime.fromtimestamp((m["start_ms"] or 0) / 1000.0, dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        out["games"].append({
            "game_id": mid, "match_id": mid, "overview_page": "Solo queue", "league": "Solo queue",
            "tournament": f"Solo queue {soloq.RANK_LABEL[r]}", "date_utc": when, "patch": patch_name(m["patch"]),
            "game_in_match": 1, "length_min": (m["duration_s"] or 0) / 60.0, "core": 1 if dist == 0 else 0, "xw": xw,
            "winner_side": "blue" if m["blue_win"] else "red", "blue_team": None, "red_team": None,
            "fp_team": None, "sp_team": None, "has_draft": 0, "rank": r})
        for p in ps:
            ks, prim, sec, runes = names.page(p.get("perks"), p.get("keystone"))
            out["players"].append({
                "game_id": mid, "draft_side": "B" if p["team"] == 100 else "R", "map_side": "blue" if p["team"] == 100 else "red",
                "role": p["role"], "champion": p["champ"], "win": p["win"], "team": None, "player": None, "player_link": None,
                "kills": p["k"], "deaths": p["d"], "assists": p["a"], "gold": p["gold"], "cs": p["cs"], "damage": p["dmg"],
                "items": names.item_list(p["items"]), "spells": names.spells(p["spells"]), "keystone": ks,
                "primary_tree": prim, "secondary_tree": sec, "runes": runes, "trinket": None})
        for i, b in enumerate(sorted(bans.get(mid) or [], key=lambda b: (b["team"], b["turn"] or 0)), start=1):
            out["actions"].append({"game_id": mid, "seq": i, "side": "B" if b["team"] == 100 else "R", "action": "ban",
                                   "n": i, "champion": b["champ"], "role": None})
    return out


class SoloStats(ProStats):
    """ProStats over one rank's solo queue games (see the module text). summary() describes the rank."""

    rank = None

    def solo_summary(self, rank, timelines=0):
        core = [g for g in self.games.values() if g["core"]]
        patches = Counter(g["patch"] for g in core)
        latest = max(core, key=lambda g: g["dt"])["patch"] if core else None
        return {
            "games": len(core), "region_games": self.region_games, "region_weight": self.region_weight,
            "first": min((g["dt"] for g in core), default=None), "last": self.ref_date,
            "leagues": {f"Solo queue {soloq.RANK_LABEL[rank]}": len(core)},
            "latest_patch": latest, "latest_event": f"Solo queue {soloq.RANK_LABEL[rank]}",
            "fearless_series": 0, "recent_days": int(self.recent_days), "recent_games": self.recent_games,
            "solo": {"rank": rank, "label": soloq.RANK_LABEL[rank], "timelines": timelines,
                     "patches": dict(sorted(patches.items(), key=lambda kv: [int(x) for x in kv[0].split(".")] if kv[0] else [0],
                                            reverse=True)[:6]),
                     "neighbours": {str(k): v for k, v in NEIGHBOUR_W.items()}},
        }

    def trim(self, keep=KEEP_GAMES):
        """Drop the per-game rows of all but the rank's newest `keep` games (the builds use those)."""
        core = sorted((g for g in self.games.values() if g["core"]), key=lambda g: g["dt"], reverse=True)[:keep]
        ids = {g["game_id"] for g in core}
        self.games = {gid: g for gid, g in self.games.items() if gid in ids}
        self.players = {gid: p for gid, p in self.players.items() if gid in ids}
        self.actions = defaultdict(list, {gid: a for gid, a in self.actions.items() if gid in ids})
        self.unavailable = {gid: s for gid, s in self.unavailable.items() if gid in ids}


def make_stats(rank, rows, dd, cfg=None, neighbour_w=None, names=None):
    """SoloStats for `rank` from load_rows() output (which should include the neighbouring ranks)."""
    c = dict(SOLO_CFG)
    over = ((cfg or {}).get("soloq") or {}).get("stats") or {}
    c.update({k: v for k, v in over.items() if k in ("half_life_days", "stats_max_age_days")})
    raw = to_raw(rows, rank, names or Names(dd), neighbour_w)
    if not any(g["core"] for g in raw["games"]):
        return None
    st = SoloStats(None, c, dd["champions"], raw=raw, regions=(True, 1.0))
    st.rank = rank
    return st


# ------------------------------------------------------------------ the engine
class SoloEngine(Engine):
    """The pro engine with solo queue's own weights, and the lane matchups apart from the rest.

    logit(blue wins) = bias + strength * sum(champion edges) + lane * sum(7 lane matchups, as their
    lane record says beyond what the two champions' strength already predicts) + counter * sum(the other
    18 champion pairs) + synergy * sum(ally pairs). Blue side is the first-pick side in solo queue."""

    def __init__(self, stats, builds, dd_champs, model=None, predictor=None):
        model = model or DEFAULT_MODEL
        super().__init__(stats, builds, dd_champs, model=model, predictor=predictor)   # (no "params": the pro PARAMS stay)
        self.k = dict(K)
        self.k.update({k: float(v) for k, v in (model.get("k") or {}).items() if k in K})

    # -- the parts of the win model
    def strength(self, c, r):
        key = ("st", c, r)
        if key not in self._cache:
            self._cache[key] = (0.5 * (self.s.strength_rate(c, r) - 0.5)
                                + 0.5 * (self.s.wr_long(c, r).rate(k=self.k["k_long"]) - 0.5))
        return self._cache[key]

    def vs_rate(self, c, e):
        return self.s.vs_wl(c, e).rate(k=self.k["k_vs"])

    def syn_rate(self, a, b):
        return self.s.syn_wl(a, b).rate(k=self.k["k_syn"])

    def lane_expect(self, c, e):
        return clamp(0.5 + self.s.champ_long_rate(c) - self.s.champ_long_rate(e), 0.35, 0.65)

    def lane_edge(self, c, r, e, er=None):
        """How the matchup goes beyond the two champions' strength: the lane (or 2v2) record, shrunk
        toward what their strength predicts, minus that prediction."""
        key = ("ln", c, r, e, er)
        if key not in self._cache:
            exp = self.lane_expect(c, e)
            x = self.s.lane_wl(c, r, e) if er is None else self.s.duo_wl(c, r, e, er)
            self._cache[key] = x.rate(prior=exp, k=self.k["k_lane"]) - exp
        return self._cache[key]

    def pair(self, rb, cb, rr, cr):
        """("lane", edge) or ("counter", edge) for blue's (rb, cb) against red's (rr, cr)."""
        if rb == rr:
            return "lane", self.lane_edge(cb, rb, cr)
        if (rb, rr) in LANE_PAIRS:
            return "lane", self.lane_edge(cb, rb, cr, rr)
        return "counter", self.vs_rate(cb, cr) - 0.5

    def expected_pairs(self, c, r, opp_open, expect):
        """(lane, counter) edges of c in role r against the opponent's unpicked roles, using their
        predicted picks (an unknown opponent counts as an even matchup)."""
        lane = cross = 0.0
        for role in opp_open:
            dist = (expect or {}).get(role)
            if not dist:
                continue
            for e, p in dist:
                if e == c:
                    continue
                kind, v = self.pair(r, c, role, e)
                if kind == "lane":
                    lane += p * v
                else:
                    cross += p * v
        return lane, cross

    def feature_vector(self, blue, red, team_b=None, team_r=None, side=0.0):
        f = {"strength": 0.0, "counter": 0.0, "lane": 0.0, "synergy": 0.0, "comfort": 0.0, "elo": 0.0, "side": side}
        for mine, sign in ((blue, 1.0), (red, -1.0)):
            items = list(mine.items())
            for r, c in items:
                f["strength"] += sign * self.strength(c, r)
            for i in range(len(items)):
                for j in range(i + 1, len(items)):
                    f["synergy"] += sign * (self.syn_rate(items[i][1], items[j][1]) - 0.5) / 2.0
        for rb, cb in blue.items():
            for rr, cr in red.items():
                kind, v = self.pair(rb, cb, rr, cr)
                f[kind] += 2.0 * v / 5.0
        return f

    def logit_blue(self, blue, red, team_b=None, team_r=None, expect=None, side=0.0):
        w = self.weights(None, None)
        f = self.feature_vector(blue, red)
        z = w["bias"] + sum(w.get(k, 0.0) * f[k] for k in FEATURES)
        for mine, theirs, sign, opp_side in ((blue, red, 1.0, "R"), (red, blue, -1.0, "B")):
            opp_open = [r for r in ROLES if r not in theirs]
            if not opp_open or not expect or not expect.get(opp_side):
                continue
            for r, c in mine.items():
                lane, cross = self.expected_pairs(c, r, opp_open, expect.get(opp_side))
                z += sign * 2.0 * (w.get("lane", 0.0) * lane + w["counter"] * cross) / 5.0
        a, c0 = self.calibration("draft")
        return c0 + a * z

    def model_key(self, team_b, team_r):
        return "draft"

    def weights(self, team_b, team_r):
        return self.model["draft"]

    def side_feature(self, fp_side):
        return 0.0

    def score(self, c, r, ctx, with_denial=True, phase_bonus=True):
        x = super().score(c, r, ctx, with_denial=with_denial, phase_bonus=phase_bonus)
        w, side = ctx["w"], ctx["side"]
        lane = cross = 0.0
        for er, e in ctx["enemies"].items():
            kind, v = self.pair(r, c, er, e)
            if kind == "lane":
                lane += v
            else:
                cross += v
        el, ec = self.expected_pairs(c, r, ctx["enemy_open"], (ctx["expect"] or {}).get("R" if side == "B" else "B"))
        d = x["evidence"]["drivers"]
        d["vs_their_picks"] = 25 * w["counter"] * 2 * cross / 5
        d["vs_lane"] = 25 * w.get("lane", 0.0) * 2 * lane / 5
        d["vs_their_likely_picks"] = 25 * 2 * (w.get("lane", 0.0) * el + w["counter"] * ec) / 5
        x["counters"] = sorted(((self.pair(r, c, er, e)[1], e, self.s.vs_wl(c, e).record, self.s.vs_wl(c, e).rg)
                                for er, e in ctx["enemies"].items()), key=lambda t: -t[0])
        return x

    def evaluate(self, draft):
        blue = self.assign(draft.picks["B"])
        red = self.assign(draft.picks["R"])
        w = self.weights(None, None)
        z = self.logit_blue(blue, red)
        a, c0 = self.calibration("draft")
        ci = None
        cov = (self.model.get("cov") or {}).get("draft")
        if cov:
            fv = self.feature_vector(blue, red)
            xt = [1.0] + [fv.get(f, 0.0) for f in cov["features"]]
            m = cov["matrix"]
            sd = math.sqrt(max(0.0, sum(xt[i] * m[i][j] * xt[j] for i in range(len(xt)) for j in range(len(xt)))))
            ci = [sigmoid(z - 1.645 * a * sd), sigmoid(z + 1.645 * a * sd)]
        drivers = {}
        for side, mine, theirs in (("B", blue, red), ("R", red, blue)):
            parts = []
            for r, c in mine.items():
                lane = cross = 0.0
                for er, e in theirs.items():
                    kind, v = self.pair(r, c, er, e)
                    if kind == "lane":
                        lane += v
                    else:
                        cross += v
                v = (w["strength"] * self.strength(c, r) + 2 * (w.get("lane", 0.0) * lane + w["counter"] * cross) / 5
                     + w["synergy"] * sum(self.syn_rate(c, a2) - 0.5 for a2 in mine.values() if a2 != c) / 2)
                parts.append((r, c, round(25 * v, 2)))
            drivers[side] = sorted(parts, key=lambda t: -t[2])
        lanes = {}
        for r in ROLES:
            if r in blue and r in red:
                lanes[r] = round(self.lane_edge(blue[r], r, red[r]), 4)
        return {"p_blue": sigmoid(z), "ci": ci, "drivers": drivers, "model": "draft", "team_only": None,
                "map_side": None, "side_weight": 0.0, "elo": None, "raw_logit": (z - c0) / (a or 1.0),
                "lanes": lanes, "solo": True}


# ------------------------------------------------------------------ builds from the rank's own games
def build_log(con, game_ids):
    """The purchases and level-ups of the timeline games among game_ids, in acp.builds' build-log format."""
    from .builds import START_S, SWAP_TRINKETS, ItemBook  # noqa: F401 (same filtering as the pro log)
    games = {}
    ids = list(game_ids)
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        for mid, blob in con.execute(f"SELECT match_id, rec FROM timelines WHERE match_id IN ({','.join('?' * len(chunk))})", chunk):
            try:
                rec = soloq.load_timeline(blob)
            except Exception:  # noqa: BLE001 - a damaged record is skipped
                continue
            ps = []
            for pid in map(str, range(1, 11)):
                side, role = (rec.get("side") or {}).get(pid, [None, None])
                if not side:
                    break
                buys = " ".join(f"{int(round(t))}:{iid}" for t, iid in (rec.get("items") or {}).get(pid, []))
                ps.append([side, role, rec["p"][pid][1], buys, (rec.get("skills") or {}).get(pid, "")])
            if len(ps) == 10:
                games[mid] = {"d": rec.get("date") or "", "p": ps}
    return games


class _Log:
    """A build log that drops the purchases the pro log drops (wards, later potions; one trinket swap)."""

    @staticmethod
    def clean(games, dd):
        from .builds import START_S, SWAP_TRINKETS
        book = ItemBook(dd.get("items"), dd.get("item_ids"))
        for g in games.values():
            for p in g["p"]:
                out, swapped = [], False
                for tok in (p[3] or "").split():
                    t, _, iid = tok.partition(":")
                    name = book.name(iid)
                    if name == "Stealth Ward":
                        continue
                    if name in SWAP_TRINKETS:
                        if swapped:
                            continue
                        swapped = True
                    elif name and float(t) > START_S and book.kind(name) == "consumable":
                        continue
                    out.append(tok)
                p[3] = " ".join(out)
        return games


# ------------------------------------------------------------------ the advisor for one rank
class SoloAdvisor(Advisor):
    """Advisor (acp/advisor.py) over one rank's solo queue games: same answers, same format."""

    def __init__(self, rank, stats, model, dd, names, builds, pro_ingame=None):   # noqa: D107 (no Advisor.__init__: no pro data)
        self.cfg = {}
        self.rank = rank
        self.dd = dd
        self.names = names
        self.stats = stats
        self.model = dict(model)
        if not (self.model.get("ingame") or {}).get("models") and pro_ingame:
            # no minute-by-minute models for this rank yet: the pro ones, labelled as such
            self.model["ingame"] = dict(pro_ingame, source="pro")
        self.builds = builds
        self.engine = SoloEngine(stats, builds, dd["champions"], model=self.model)
        self.predictor = EnemyPredictor(stats, weights=self.model.get("predictor"), engine=self.engine)
        self.engine.predictor = self.predictor
        self.planner = Planner(stats, builds, dd["champions"], conditions=self.model.get("conditions"))

    def _calibration(self, p_blue, model_key="draft"):
        cal = self.model.get("calibration_table") or {}
        fav = max(p_blue, 1 - p_blue)
        label = next(l for lim, l in ((0.55, "50-55%"), (0.60, "55-60%"), (0.65, "60-65%"), (0.70, "65-70%"), (1.01, "70%+"))
                     if fav < lim)
        b = cal.get(label)
        return {"bucket": label, "won": b["won"], "games": b["games"]} if b and b.get("games") else None

    def ingame_context(self, ev, plans):
        out = super().ingame_context(ev, plans)
        if out is not None:
            out["source"] = (self.model.get("ingame") or {}).get("source", "solo")
            out["rank"] = self.rank
        return out


def load_models():
    try:
        with open(SOLO_MODEL, encoding="utf-8") as f:
            m = json.load(f)
        return m if isinstance(m, dict) else {}
    except (OSError, ValueError):
        return {}


def model_for(rank, models=None):
    models = load_models() if models is None else models
    m = ((models.get("ranks") or {}).get(rank)) or {}
    if not m.get("draft"):
        out = json.loads(json.dumps(DEFAULT_MODEL))
        out.update({k: v for k, v in m.items() if k not in out})   # (in-game models even without a draft fit)
        return out
    return m


def make_advisor(rank, dd, names, cfg=None, con=None, models=None, pro_ingame=None):
    """A SoloAdvisor for `rank`, built from data/soloq.db; None when the rank has no games."""
    own = con is None
    con = con or soloq.connect()
    try:
        near = [r for r in soloq.RANKS if rank_distance(r, rank) <= max(NEIGHBOUR_W)]
        rows = load_rows(con, near)
        st = make_stats(rank, rows, dd, cfg)
        if st is None:
            return None
        n_tl = con.execute(f"SELECT COUNT(*) FROM timelines t JOIN matches m USING (match_id) WHERE m.tier IN "
                           f"({','.join('?' * len(soloq.RANK_TIERS[rank]))})", soloq.RANK_TIERS[rank]).fetchone()[0]
        st._summary = st.solo_summary(rank, n_tl)
        st.trim()
        log = _Log.clean(build_log(con, st.games.keys()), dd)
    finally:
        if own:
            con.close()
    builds = Builds(st, dd, log=log)
    builds.item_era = ""   # (this season's games only: every item id is current)
    return SoloAdvisor(rank, st, model_for(rank, models), dd, names, builds, pro_ingame=pro_ingame)


# ------------------------------------------------------------------ cached per rank (the website)
_LOCK = threading.Lock()
_ADV = {}    # rank -> (stamp, SoloAdvisor)


def db_stamp():
    path = soloq.SOLO_DB
    st = os.path.getmtime(path) if os.path.exists(path) else 0.0
    wal = path.with_name(path.name + "-wal")
    st = max(st, os.path.getmtime(wal) if wal.exists() else 0.0)
    return (round(st, 1), round(os.path.getmtime(SOLO_MODEL), 1) if SOLO_MODEL.exists() else 0.0, CACHE_VERSION)


def advisor(rank, dd, names, cfg=None, pro_ingame=None, max_age_s=600):
    """The SoloAdvisor for a rank, kept in memory (at most 3 ranks) and on disk (data/soloq_cache/), and
    rebuilt when the solo queue database or the solo model changed (while a download is adding games:
    at most every max_age_s seconds)."""
    if rank not in soloq.RANKS:
        raise ValueError(f"unknown rank '{rank}'")
    stamp = db_stamp()
    with _LOCK:
        have = _ADV.get(rank)
        if have and (have[0] == stamp or (have[0][1:] == stamp[1:] and time.monotonic() - have[2] < max_age_s)):
            return have[1]
        path = CACHE_DIR / f"{rank}.pkl"
        adv = None
        if path.exists():
            try:
                with open(path, "rb") as f:
                    saved = pickle.load(f)
                if saved.get("stamp") == stamp:
                    adv = saved["adv"]
                    adv.dd, adv.names = dd, names
            except Exception:  # noqa: BLE001 - a stale or damaged cache is rebuilt
                adv = None
        if adv is None:
            adv = make_advisor(rank, dd, names, cfg, pro_ingame=pro_ingame)
            if adv is not None:
                try:
                    CACHE_DIR.mkdir(parents=True, exist_ok=True)
                    keep_dd, keep_names = adv.dd, adv.names
                    adv.dd = adv.names = None
                    try:
                        with open(str(path) + ".tmp", "wb") as f:
                            pickle.dump({"stamp": stamp, "adv": adv}, f, protocol=5)
                        os.replace(str(path) + ".tmp", path)
                    finally:
                        adv.dd, adv.names = keep_dd, keep_names
                except Exception:  # noqa: BLE001 - the cache is only a speed-up
                    pass
        if adv is None:
            return None
        if len(_ADV) >= 3 and rank not in _ADV:
            _ADV.pop(min(_ADV, key=lambda k: _ADV[k][2]))
        _ADV[rank] = (stamp, adv, time.monotonic())
        return adv


def ranks_status(models=None):
    """For the rank picker: every rank's games, timelines, newest game and whether the lab fitted it."""
    counts = soloq.rank_counts()
    models = load_models() if models is None else models
    out = {}
    for r in soloq.RANKS:
        c = counts.get(r) or {"games": 0, "timelines": 0, "newest": None, "patches": {}}
        m = (models.get("ranks") or {}).get(r) or {}
        patches = sorted(c["patches"].items(), key=lambda kv: [int(x) for x in kv[0].split(".")] if kv[0] else [0], reverse=True)
        out[r] = {"label": soloq.RANK_LABEL[r], "games": c["games"], "timelines": c["timelines"], "newest": c["newest"],
                  "patch": patch_name(patches[0][0]) if patches else None, "patch_games": patches[0][1] if patches else 0,
                  "fitted": (m.get("info") or {}).get("fitted"), "accuracy": (m.get("info") or {}).get("oos_accuracy"),
                  "ingame": bool((m.get("ingame") or {}).get("models"))}
    return out
