"""The draft board's answers, shared by the local website (serve.py) and the in-browser version
(acp/webapi.py running in Pyodide): the same code builds the draft and answers /api/analyze in both."""
import traceback

from . import ROLES
from .engine import Draft


def build_draft(adv, body):
    names = adv.names

    def champ(x):
        return names.resolve(x)

    def picks(lst):
        out = []
        for p in lst or []:
            if isinstance(p, str):
                out.append((champ(p), None))
            else:
                role = p.get("role")
                out.append((champ(p["champ"]), role if role in ROLES else None))
        return out

    st = adv.stats
    draft = Draft(
        blue=picks(body.get("blue")), red=picks(body.get("red")),
        blue_bans=[champ(x) for x in body.get("blueBans") or []],
        red_bans=[champ(x) for x in body.get("redBans") or []],
        fearless=[champ(x) for x in body.get("fearless") or []],
        blue_team=st.resolve_team(body["blueTeam"]) if body.get("blueTeam") else None,
        red_team=st.resolve_team(body["redTeam"]) if body.get("redTeam") else None,
        skip_bans=bool(body.get("skipBans")),
        fp_side=body.get("fpSide") if body.get("fpSide") in ("blue", "red") else None,
    )
    seen = [c for c, _ in draft.picks["B"] + draft.picks["R"]] + draft.bans["B"] + draft.bans["R"]
    dupes = sorted({c for c in seen if seen.count(c) > 1})
    if dupes:
        raise ValueError(f"{', '.join(dupes)} is already used in this draft")
    locked = [c for c in seen if c in set(draft.fearless)]
    if locked:
        raise ValueError(f"{', '.join(sorted(set(locked)))} is locked by Fearless")
    return draft


def analyze(adv, body, solo_engine=None):
    """POST /api/analyze: the board's whole answer for one draft state.
    solo_engine: a callable returning the solo queue engine (acp.soloq.SoloBlend) or None."""
    draft = build_draft(adv, body)
    us = body.get("us") if body.get("us") in ("B", "R") else None
    role = body.get("role") if body.get("role") in ROLES else None
    solo = None
    if body.get("solo") and us and role:   # solo queue: your side, your role, your pick slot
        slot = body.get("slot")
        pool = []
        for x in (body.get("pool") or [])[:60]:
            try:
                pool.append(adv.names.resolve(str(x)))
            except ValueError:
                pass
        solo = {"slot": slot if isinstance(slot, int) and 1 <= slot <= 5 else None,
                "pool": pool, "ban_stage": bool(body.get("banStage")),
                # from the League client: is your own pick in progress right now?
                "now": body.get("now") if isinstance(body.get("now"), bool) else None,
                "keep": []}   # and the champions your teammates plan to play (not to be banned)
        for x in (body.get("keep") or [])[:5]:
            try:
                solo["keep"].append(adv.names.resolve(str(x)))
            except ValueError:
                pass
        if body.get("hover"):   # the champion you're hovering in the client
            try:
                solo["hover"] = adv.names.resolve(str(body["hover"]))
            except ValueError:
                pass
        draft.skip_bans = True   # solo queue bans all happen at once, before the picks
        if not any(r == role for _, r in draft.picks[us]):
            draft.reserve = {us: role}
    if solo and solo_engine and not body.get("asOf"):   # champions with few pro games: solo queue evidence too
        try:
            solo["engine"] = solo_engine(adv)
        except Exception:  # noqa: BLE001 - never let the solo queue extra break the board
            traceback.print_exc()
    res = adv.analyze(draft, us=us, role=role, top=6, solo=solo)
    res["solo"] = bool(solo)
    res["solo_db"] = bool(solo and solo.get("engine"))   # solo queue evidence in use for thin-pro champions
    hv = []
    if solo and isinstance(body.get("hovers"), list):   # teammates' hovers, rated for their roles
        for h in body["hovers"][:5]:
            if isinstance(h, dict) and h.get("champ") and h.get("role") in ROLES:
                try:
                    hv.append({"champ": adv.names.resolve(str(h["champ"])), "role": h["role"],
                               "slot": h.get("slot") if isinstance(h.get("slot"), int) else None})
                except ValueError:
                    pass
        res["team_hovers"] = adv.rate_hovers(draft, us, hv, eng=solo.get("engine")) if hv else []
    # every counter matchup between the two teams (your team's hovers count, marked as such)
    res["matchups"] = adv.matchups(draft, hovers={us: {h["role"]: h["champ"] for h in hv}} if us and hv else None)
    eng = adv.engine
    res["model_key"] = eng.model_key(draft.teams["B"], draft.teams["R"])
    res["elo"] = {"B": eng.elo_rating(draft.teams["B"]), "R": eng.elo_rating(draft.teams["R"])}
    try:
        from . import render
        res["markdown"] = render.markdown(res)
    except Exception:  # the copy-summary text is a nice-to-have
        res["markdown"] = ""
    return res
