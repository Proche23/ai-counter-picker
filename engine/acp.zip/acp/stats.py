"""Recency-weighted pro statistics built from data/pro.db.

Every game gets weights 0.5 ** (age / half_life), measured back from the newest
game in the data, so the current patch's pro meta dominates while older games
still inform sparse things like matchups. Fearless draft is detected per series
so presence is measured over games where a champion was actually available.
"""
import datetime as dt
import math
import re
from collections import defaultdict

from . import ROLES
from .kb import ARCHETYPES, archetype_scores

LENGTH_BUCKETS = ((0, 28, "short"), (28, 35, "mid"), (35, 999, "long"))

TEAM_ALIASES = {
    "blg": "Bilibili Gaming", "tes": "Top Esports", "jdg": "JD Gaming", "wbg": "Weibo Gaming",
    "lng": "LNG Esports", "ig": "Invictus Gaming", "nip": "Ninjas in Pyjamas", "al": "Anyone's Legend",
    "edg": "EDward Gaming", "fpx": "FunPlus Phoenix", "omg": "Oh My God", "rng": "Royal Never Give Up",
    "lgd": "LGD Gaming", "up": "Ultra Prime", "tt": "ThunderTalk Gaming", "we": "Team WE",
    "hle": "Hanwha Life Esports", "hanwha": "Hanwha Life Esports", "gen": "Gen.G", "geng": "Gen.G",
    "dk": "Dplus KIA", "dplus": "Dplus KIA", "kt": "KT Rolster", "ns": "Nongshim RedForce",
    "bfx": "BNK FEARX", "fearx": "BNK FEARX", "bro": "OKSavingsBank BRION", "brion": "OKSavingsBank BRION",
    "drx": "DRX", "dnf": "DN Freecs", "g2": "G2 Esports", "fnc": "Fnatic", "koi": "Movistar KOI",
    "fly": "FlyQuest", "tl": "Team Liquid", "c9": "Cloud9", "100t": "100 Thieves",
    "cfo": "CTBC Flying Oyster", "gam": "GAM Esports", "psg": "PSG Talon", "vks": "Vivo Keyd Stars",
}


class WL:
    """Weighted win/loss counter (also keeps the raw, unweighted record)."""
    __slots__ = ("w", "g", "rw", "rg")

    def __init__(self):
        self.w = 0.0
        self.g = 0.0
        self.rw = 0
        self.rg = 0

    def add(self, win, weight):
        self.g += weight
        self.w += weight * win
        self.rg += 1
        self.rw += win

    def add_adj(self, win, value, weight):
        """Record a raw win/loss for display but accumulate a (team-adjusted) value for rates."""
        self.g += weight
        self.w += weight * value
        self.rg += 1
        self.rw += win

    def add_w(self, value, weight):
        """Evidence for the rate only (another region's game): not part of the record shown."""
        self.g += weight
        self.w += weight * value

    def rate(self, prior=0.5, k=10.0):
        return (self.w + prior * k) / (self.g + k)

    @property
    def record(self):
        return f"{self.rw}-{self.rg - self.rw}"


EMPTY = WL()


# (named factories instead of lambdas, so the statistics can be pickled for the in-browser version)
def _pair():
    return [0.0, 0.0]


def _float_dd():
    return defaultdict(float)


def _wl_dd():
    return defaultdict(WL)


def _parse_dt(s):
    try:
        return dt.datetime.fromisoformat(str(s)[:19])
    except (TypeError, ValueError):
        return None


def _decay(age_days, half_life):
    return 0.5 ** (max(age_days, 0.0) / float(half_life))


def _key(s):
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


def _bucket(length):
    for lo, hi, name in LENGTH_BUCKETS:
        if length is not None and lo <= length < hi:
            return name
    return None


def load_raw(con):
    """Every row ProStats reads, loaded once. The lab rebuilds stats hundreds of times, so it passes
    these in instead of re-reading the whole database on every rebuild."""
    return {"games": [dict(r) for r in con.execute("SELECT * FROM games")],
            "players": [dict(r) for r in con.execute("SELECT * FROM players")],
            "actions": [dict(r) for r in con.execute("SELECT * FROM draft_actions ORDER BY game_id, seq")]}


class ProStats:
    def __init__(self, con, cfg, dd_champs=None, exclude_pages=(), before=None, raw=None):
        hl = cfg.get("half_life_days", {})
        defaults = {"meta": 45, "matchup": 120, "builds": 35, "pools": 120}
        self.hl = {k: float(hl.get(k, v)) for k, v in defaults.items()}
        self.dd_champs = dd_champs or {}
        exclude_pages = set(exclude_pages or ())
        # other regions (LEC, LCS, ...; config "regions"): their games add evidence to champion win
        # rates, matchups and synergies at region_weight, and fill in their teams' rosters and pools.
        # Presence (pick/ban rates), candidate pools and the records shown stay LCK/LPL/international.
        # Player comfort (a player's record on a champion) only counts their games when "comfort" is on:
        # the regions test showed domestic records flatter a smaller region's players at internationals.
        from . import regions as _regions
        self.use_regions, self.region_weight = _regions.settings(cfg)
        self.region_comfort = bool((cfg.get("regions") or {}).get("comfort", False))
        # their picks and bans in presence (how likely a champion is to be picked or banned) only at
        # "presence_weight" (default 0: presence stays LCK / LPL / international)
        self.presence_weight = float((cfg.get("regions") or {}).get("presence_weight", 0.0) or 0.0) if self.use_regions else 0.0
        if raw is None and self.use_regions:
            raw = _regions.load_raw(load_raw(con), cfg)
        self.region_games = 0

        games = {}
        for r in (raw["games"] if raw else con.execute("SELECT * FROM games")):
            r = dict(r)
            r["core"] = r.get("core", 1)
            if not r["core"] and not self.use_regions:
                continue
            if r["overview_page"] in exclude_pages:
                continue
            d = _parse_dt(r["date_utc"])
            if d is None or (before and d >= before):
                continue
            r["dt"] = d
            games[r["game_id"]] = r
        # only the current era: archive games (e.g. old Worlds) stay in the database for replays,
        # but stats use games within max_age_days of the newest game considered
        max_age = float(cfg.get("stats_max_age_days", 900))
        if games:
            newest = max(g["dt"] for g in games.values())
            games = {gid: g for gid, g in games.items() if (newest - g["dt"]).days <= max_age}
        players = {}
        for r in (raw["players"] if raw else con.execute("SELECT * FROM players")):
            gid = r["game_id"]
            if gid in games:
                players.setdefault(gid, {"B": {}, "R": {}})[r["draft_side"]][r["role"]] = dict(r)
        self.games = {gid: g for gid, g in games.items() if gid in players}
        self.players = players
        self.actions = defaultdict(list)
        for r in (raw["actions"] if raw else con.execute("SELECT * FROM draft_actions ORDER BY game_id, seq")):
            if r["game_id"] in self.games:
                self.actions[r["game_id"]].append(dict(r))

        self.region_games = sum(1 for g in self.games.values() if not g["core"])
        self.ref_date = max((g["dt"] for g in self.games.values() if g["core"]),
                            default=max((g["dt"] for g in self.games.values()), default=dt.datetime.now()))
        # team-adjusted records: credit each game as win - P(win by team rating) + 0.5, so a champion
        # isn't flattered (or punished) by which teams happened to play it
        self.adjusted = bool(cfg.get("team_adjusted_records", False))
        self.p_fp = {}
        if self.adjusted:
            from .rating import expectations
            self.p_fp = expectations(sorted(self.games.values(), key=lambda g: g["dt"]))
        for g in self.games.values():
            age = (self.ref_date - g["dt"]).total_seconds() / 86400.0
            g["w"] = {k: _decay(age, h) for k, h in self.hl.items()}
        self._detect_fearless()
        self._aggregate()

    # ------------------------------------------------------------------ build
    def picks_of(self, gid):
        sides = self.players.get(gid, {"B": {}, "R": {}})
        return {p["champion"] for s in "BR" for p in sides[s].values()}

    def _detect_fearless(self):
        by_match = defaultdict(list)
        for g in self.games.values():
            by_match[g["match_id"] or g["game_id"]].append(g)
        self.unavailable = {}
        self.fearless_series = 0
        for gl in by_match.values():
            gl.sort(key=lambda g: (g["game_in_match"] or 0, g["dt"]))
            picks = [self.picks_of(g["game_id"]) for g in gl]
            fearless = len(gl) >= 2 and all(
                not (picks[i] & picks[j]) for i in range(len(gl)) for j in range(i))
            self.fearless_series += 1 if fearless else 0
            used = set()
            for g, p in zip(gl, picks):
                g["fearless"] = fearless
                self.unavailable[g["game_id"]] = set(used) if fearless else set()
                used |= p

    def _aggregate(self):
        self.total_w = 0.0
        self.pick_w = defaultdict(float)
        self.ban_w = defaultdict(float)
        self.ban1_w = defaultdict(float)
        self.unavail_w = defaultdict(float)
        self.first_pick_w = defaultdict(float)
        self.role_wl = defaultdict(WL)
        self.role_long = defaultdict(float)
        self.role_wl_long = defaultdict(WL)
        self.role_recent = defaultdict(WL)
        self.recent_days = 2 * self.hl["meta"]
        self.recent_games = 0
        self.champ_long = defaultdict(WL)
        self.raw_games = defaultdict(int)
        self.lane = defaultdict(WL)
        self.duo_vs = defaultdict(WL)
        self.syn = defaultdict(WL)
        self.vs = defaultdict(WL)
        # how many other-region games add to a lane matchup / a champion pair (their records stay out
        # of the ones shown, which are LCK / LPL / international only)
        self.lane_other = defaultdict(int)
        self.vs_other = defaultdict(int)
        self.syn_meta = defaultdict(float)  # co-pick counts on the 120-day 'pools' weighting, for pick prediction
        self.pick_wp = defaultdict(float)
        self.total_wp = 0.0
        self.vs_meta = defaultdict(float)
        self.blind = defaultdict(_pair)
        self.length = defaultdict(WL)
        self.patch_wl = defaultdict(WL)  # (champion, patch) raw record
        self.team_role_pool = defaultdict(_float_dd)
        self.player_pool = defaultdict(_wl_dd)
        self.roster_seen = defaultdict(dict)  # team -> role -> {player: (last_dt, n)}
        self.player_names = {}
        arch_samples = defaultdict(list)

        for gid, g in self.games.items():
            w, wm, wp = g["w"]["meta"], g["w"]["matchup"], g["w"]["pools"]
            core = g["core"]
            sides = self.players[gid]
            if not core:  # another region's game: evidence and pools only (see __init__)
                self._add_region_game(g, sides, w * self.region_weight, wm * self.region_weight, wp)
                if self.presence_weight > 0:
                    self._add_region_presence(gid, sides, w * self.presence_weight)
                continue
            recent = (self.ref_date - g["dt"]).days <= self.recent_days
            self.recent_games += 1 if recent else 0
            self.total_w += w
            self.total_wp += wp
            for c in self.unavailable.get(gid, ()):
                self.unavail_w[c] += w
            bucket = _bucket(g["length_min"])
            p_fp = self.p_fp.get(gid, 0.5)
            for s, o in (("B", "R"), ("R", "B")):
                mine, theirs = sides[s], sides[o]
                lst = list(mine.values())
                p_side = p_fp if s == "B" else 1.0 - p_fp
                for r, p in mine.items():
                    c, win = p["champion"], p["win"]
                    val = (win - p_side + 0.5) if self.adjusted else win
                    self.pick_w[c] += w
                    self.pick_wp[c] += wp
                    self.role_wl[(c, r)].add_adj(win, val, w)
                    self.role_long[(c, r)] += wm
                    self.role_wl_long[(c, r)].add_adj(win, val, wm)
                    if recent:
                        self.role_recent[(c, r)].add(win, 1.0)
                    self.champ_long[c].add_adj(win, val, wm)
                    self.raw_games[(c, r)] += 1
                    if bucket:
                        self.length[(c, bucket)].add(win, wm)
                    self.patch_wl[(c, g["patch"])].add(win, 1.0)
                    self._add_pools(p, g["dt"], c, r, win, wp)
                    q = theirs.get(r)
                    if q:
                        self.lane[(c, r, q["champion"])].add_adj(win, val, wm)
                    if r in ("BOT", "SUP"):
                        er = "SUP" if r == "BOT" else "BOT"
                        q2 = theirs.get(er)
                        if q2:
                            self.duo_vs[(c, r, q2["champion"], er)].add_adj(win, val, wm)
                    for q3 in theirs.values():
                        self.vs[(c, q3["champion"])].add_adj(win, val, wm)
                        self.vs_meta[(c, q3["champion"])] += wp
                for i in range(len(lst)):
                    for j in range(i + 1, len(lst)):
                        a, b = sorted((lst[i]["champion"], lst[j]["champion"]))
                        wv = lst[i]["win"]
                        self.syn[(a, b)].add_adj(wv, (wv - p_side + 0.5) if self.adjusted else wv, wm)
                        self.syn_meta[(a, b)] += wp
                if len(lst) == 5:
                    sc = archetype_scores([p["champion"] for p in lst], self.dd_champs)
                    for a, v in sc.items():
                        arch_samples[a].append(v)

            seq_of, champ_of = {}, {}
            for a in self.actions.get(gid, ()):
                if not a["champion"]:
                    continue
                if a["action"] == "ban":
                    self.ban_w[a["champion"]] += w
                    if a["seq"] <= 6:
                        self.ban1_w[a["champion"]] += w
                else:
                    role = a["role"]
                    side = sides.get(a["side"], {})
                    for r, p in side.items():  # trust the scoreboard role
                        if p["champion"] == a["champion"]:
                            role = r
                    if role:
                        seq_of[(a["side"], role)] = a["seq"]
                        champ_of[(a["side"], role)] = a["champion"]
                    if a["seq"] == 7:
                        self.first_pick_w[a["champion"]] += w
            for (s, r), sq in seq_of.items():
                opp = seq_of.get(("R" if s == "B" else "B", r))
                blind = 1.0 if (opp is None or sq < opp) else 0.0
                rec = self.blind[(champ_of[(s, r)], r)]
                rec[0] += w * blind
                rec[1] += w

        self.arch_norm = {}
        for a in ARCHETYPES:
            vals = arch_samples.get(a) or [0.0, 1.0]
            mean = sum(vals) / len(vals)
            var = sum((v - mean) ** 2 for v in vals) / max(1, len(vals) - 1)
            self.arch_norm[a] = (mean, math.sqrt(var) or 1.0)

        self.teams = sorted(self.team_role_pool)
        self._team_keys = {_key(t): t for t in self.teams}

    def _add_pools(self, p, when, c, r, win, wp, comfort=True):
        team, link = p["team"], p["player_link"] or p["player"]
        if team:
            self.team_role_pool[team][(r, c)] += wp
            seen = self.roster_seen[team].setdefault(r, {})
            last, n = seen.get(link, (when, 0))
            seen[link] = (max(last, when), n + 1)
        if link:
            if comfort:
                self.player_pool[link][c].add(win, wp)
            self.player_names[link] = p["player"]

    def _add_region_presence(self, gid, sides, w):
        """Another region's picks and bans, counted in presence at weight w (config "presence_weight")."""
        self.total_w += w
        for c in self.unavailable.get(gid, ()):
            self.unavail_w[c] += w
        for s in "BR":
            for p in sides[s].values():
                self.pick_w[p["champion"]] += w
        for a in self.actions.get(gid, ()):
            if a["champion"] and a["action"] == "ban":
                self.ban_w[a["champion"]] += w

    def _add_region_game(self, g, sides, we, wme, wp):
        """Another region's game: its teams' and players' pools at full weight; champion evidence
        (win rates, role shares, matchups, synergies) at the region weight, kept out of the records."""
        bucket = _bucket(g["length_min"])
        for s, o in (("B", "R"), ("R", "B")):
            mine, theirs = sides[s], sides[o]
            lst = list(mine.values())
            for r, p in mine.items():
                c, win = p["champion"], p["win"]
                self._add_pools(p, g["dt"], c, r, win, wp, comfort=self.region_comfort)
                if wme <= 0:
                    continue
                self.role_wl[(c, r)].add_w(win, we)
                self.role_long[(c, r)] += wme
                self.role_wl_long[(c, r)].add_w(win, wme)
                self.champ_long[c].add_w(win, wme)
                if bucket:
                    self.length[(c, bucket)].add_w(win, wme)
                q = theirs.get(r)
                if q:
                    self.lane[(c, r, q["champion"])].add_w(win, wme)
                    self.lane_other[(c, r, q["champion"])] += 1
                if r in ("BOT", "SUP"):
                    er = "SUP" if r == "BOT" else "BOT"
                    q2 = theirs.get(er)
                    if q2:
                        self.duo_vs[(c, r, q2["champion"], er)].add_w(win, wme)
                for q3 in theirs.values():
                    self.vs[(c, q3["champion"])].add_w(win, wme)
                    self.vs_other[(c, q3["champion"])] += 1
            if wme > 0:
                for i in range(len(lst)):
                    for j in range(i + 1, len(lst)):
                        a, b = sorted((lst[i]["champion"], lst[j]["champion"]))
                        self.syn[(a, b)].add_w(lst[i]["win"], wme)

    # ---------------------------------------------------------------- queries
    def presence(self, c):
        avail = self.total_w - self.unavail_w.get(c, 0.0)
        if avail <= 1e-9:
            return 0.0
        return min(1.0, (self.pick_w.get(c, 0.0) + self.ban_w.get(c, 0.0)) / avail)

    def pick_rate(self, c):
        avail = self.total_w - self.unavail_w.get(c, 0.0)
        return self.pick_w.get(c, 0.0) / avail if avail > 1e-9 else 0.0

    def ban_rate(self, c):
        avail = self.total_w - self.unavail_w.get(c, 0.0)
        return self.ban_w.get(c, 0.0) / avail if avail > 1e-9 else 0.0

    def role_share(self, c, r):
        total = sum(self.role_long.get((c, rr), 0.0) for rr in ROLES)
        return self.role_long.get((c, r), 0.0) / total if total > 0 else 0.0

    def roles(self, c):
        return sorted(((r, self.role_share(c, r)) for r in ROLES), key=lambda x: -x[1])

    def wr(self, c, r):
        return self.role_wl.get((c, r), EMPTY)

    def wr_long(self, c, r):
        return self.role_wl_long.get((c, r), EMPTY)

    def recent(self, c, r):
        """Raw record in the recent window (2 meta half-lives back from the newest game)."""
        return self.role_recent.get((c, r), EMPTY)

    def strength_rate(self, c, r):
        """Recent win rate, shrunk toward the champion's own long-run rate (not just 50%)."""
        prior = self.wr_long(c, r).rate(k=20)
        return self.wr(c, r).rate(prior=prior, k=25)

    def overall_wl(self, c):
        out = WL()
        for r in ROLES:
            x = self.role_wl.get((c, r))
            if x:
                out.w += x.w
                out.g += x.g
                out.rw += x.rw
                out.rg += x.rg
        return out

    def champ_long_rate(self, c):
        """Long-window win rate, used as the baseline that matchup/synergy residuals are measured against."""
        return self.champ_long.get(c, EMPTY).rate(k=20)

    def lane_wl(self, c, r, opp):
        return self.lane.get((c, r, opp), EMPTY)

    def duo_wl(self, c, r, e, er):
        return self.duo_vs.get((c, r, e, er), EMPTY)

    def syn_wl(self, a, b):
        return self.syn.get(tuple(sorted((a, b))), EMPTY)

    def vs_wl(self, c, e):
        return self.vs.get((c, e), EMPTY)

    def blind_share(self, c, r):
        b, t = self.blind.get((c, r), (0.0, 0.0))
        return (b + 1.0) / (t + 2.0)

    def length_rates(self, c):
        return {name: self.length.get((c, name), EMPTY) for _, _, name in LENGTH_BUCKETS}

    def length_index(self, c):
        lr = self.length_rates(c)
        return lr["short"].rate(k=8) - lr["long"].rate(k=8)

    def champions_in_role(self, r, min_games=3):
        return [c for (c, rr), n in self.raw_games.items() if rr == r and n >= min_games]

    def arch_z(self, champs):
        if not champs:
            return {a: 0.0 for a in ARCHETYPES}
        raw = archetype_scores(champs, self.dd_champs)
        scale = 5.0 / len(champs)
        return {a: (raw[a] * scale - self.arch_norm[a][0]) / self.arch_norm[a][1] for a in ARCHETYPES}

    # ------------------------------------------------------------ team pools
    def resolve_team(self, text):
        if not text:
            return None
        k = _key(text)
        if k in self._team_keys:
            return self._team_keys[k]
        alias = TEAM_ALIASES.get(k)
        if alias and _key(alias) in self._team_keys:
            return self._team_keys[_key(alias)]
        hits = [t for kk, t in self._team_keys.items() if k and k in kk]
        if len(hits) == 1:
            return hits[0]
        hits = [t for t in self.teams if "".join(w[0] for w in re.findall(r"[A-Za-z0-9]+", t)).lower() == k]
        if len(hits) == 1:
            return hits[0]
        raise ValueError(f"unknown team '{text}'. Examples: {', '.join(self.teams[:12])} ...")

    def roster(self, team):
        """Most recent player in each role for a team."""
        out = {}
        for r, seen in self.roster_seen.get(team, {}).items():
            link = max(seen.items(), key=lambda kv: (kv[1][0], kv[1][1]))[0]
            out[r] = link
        return out

    def comfort(self, team, role, champ):
        """(player name, weighted games on champ, record) for the team's player in that role."""
        link = self.roster(team).get(role)
        if not link:
            return None, 0.0, ""
        wl = self.player_pool[link].get(champ, EMPTY)
        return self.player_names.get(link, link), wl.g, wl.record

    # ---------------------------------------------------------------- summary
    def summary(self):
        if getattr(self, "_summary", None) is not None:   # (the in-browser snapshot has no per-game rows)
            return dict(self._summary)
        leagues = defaultdict(int)
        patches = defaultdict(int)
        core = [g for g in self.games.values() if g["core"]]
        for g in core:
            leagues[g["league"]] += 1
            patches[g["patch"]] += 1
        newest = max(core, key=lambda g: g["dt"]) if core else None
        return {
            "games": len(core),
            "region_games": self.region_games,
            "region_weight": self.region_weight if self.use_regions else 0.0,
            "first": min((g["dt"] for g in core), default=None),
            "last": self.ref_date,
            "leagues": dict(sorted(leagues.items(), key=lambda kv: -kv[1])),
            "latest_patch": newest["patch"] if newest else None,
            "latest_event": newest["tournament"] if newest else None,
            "fearless_series": self.fearless_series,
            "recent_days": int(self.recent_days),
            "recent_games": self.recent_games,
        }
