"""Turn cached Leaguepedia responses into one clean SQLite database (data/pro.db)."""
import json
import os

# (sqlite3 is imported where a database is opened: the in-browser engine has no databases and no sqlite3)

from . import DB_PATH, RAW

ROLE_MAP = {"top": "TOP", "jungle": "JNG", "mid": "MID", "bot": "BOT", "adc": "BOT", "support": "SUP"}

# Standard tournament draft. B = the team with first pick (in 2026 this is
# chosen separately from map side), R = the other team.
DRAFT_SEQUENCE = [
    ("B", "ban", 1), ("R", "ban", 1), ("B", "ban", 2), ("R", "ban", 2), ("B", "ban", 3), ("R", "ban", 3),
    ("B", "pick", 1), ("R", "pick", 1), ("R", "pick", 2), ("B", "pick", 2), ("B", "pick", 3), ("R", "pick", 3),
    ("R", "ban", 4), ("B", "ban", 4), ("R", "ban", 5), ("B", "ban", 5),
    ("R", "pick", 4), ("B", "pick", 4), ("B", "pick", 5), ("R", "pick", 5),
]

SCHEMA = """
CREATE TABLE tournaments(
  overview_page TEXT PRIMARY KEY, name TEXT, league TEXT, region TEXT, year INTEGER,
  date_start TEXT, date_end TEXT, fetched_at TEXT);
CREATE TABLE games(
  game_id TEXT PRIMARY KEY, match_id TEXT, overview_page TEXT, league TEXT, tournament TEXT,
  date_utc TEXT, patch TEXT, game_in_match INTEGER,
  blue_team TEXT, red_team TEXT, winner_side TEXT, length_min REAL,
  blue_dragons INT, red_dragons INT, blue_barons INT, red_barons INT, blue_towers INT, red_towers INT,
  blue_gold INT, red_gold INT, blue_kills INT, red_kills INT, blue_heralds INT, red_heralds INT,
  blue_grubs INT, red_grubs INT, blue_inhibs INT, red_inhibs INT,
  fp_team TEXT, sp_team TEXT, has_draft INTEGER);
CREATE TABLE draft_actions(
  game_id TEXT, seq INTEGER, side TEXT, action TEXT, n INTEGER, champion TEXT, role TEXT,
  PRIMARY KEY(game_id, seq));
CREATE TABLE players(
  game_id TEXT, team TEXT, map_side TEXT, draft_side TEXT, role TEXT, player TEXT, player_link TEXT,
  champion TEXT, win INTEGER, kills INT, deaths INT, assists INT, gold INT, cs INT, damage INT,
  items TEXT, trinket TEXT, spells TEXT, keystone TEXT, primary_tree TEXT, secondary_tree TEXT,
  runes TEXT, PRIMARY KEY(game_id, team, role));
CREATE INDEX idx_players_champ ON players(champion, role);
CREATE INDEX idx_games_date ON games(date_utc);
"""


def _int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return None


def _float(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _role(v):
    return ROLE_MAP.get(str(v or "").strip().lower())


def build(names, raw_dir=RAW, db_path=DB_PATH, verbose=True):
    """names: acp.names.ChampNames used to canonicalise champion names."""
    import sqlite3
    tmp = str(db_path) + ".tmp"
    if os.path.exists(tmp):
        os.remove(tmp)
    con = sqlite3.connect(tmp)
    con.executescript(SCHEMA)
    unknown_champs = set()
    side_mismatch = 0
    n_games = 0

    def champ(v):
        if not v or str(v).strip().lower() in ("none", "loss of ban", ""):
            return None
        c = names.canon(v)
        if c is None:
            unknown_champs.add(v)
            return str(v).strip()
        return c

    for fn in sorted(os.listdir(raw_dir)):
        if not fn.endswith(".json"):
            continue
        with open(os.path.join(raw_dir, fn), encoding="utf-8") as f:
            blob = json.load(f)
        t = blob["tournament"]
        con.execute(
            "INSERT OR REPLACE INTO tournaments VALUES (?,?,?,?,?,?,?,?)",
            (t["OverviewPage"], t.get("Name"), t.get("League"), t.get("Region"), _int(t.get("Year")),
             t.get("DateStart"), t.get("DateEnd"), blob.get("fetched_at")),
        )
        pb_by_game = {p["GameId"]: p for p in blob.get("picks_bans", []) if p.get("GameId")}
        players_by_game = {}
        for p in blob.get("players", []):
            players_by_game.setdefault(p.get("GameId"), []).append(p)

        for g in blob.get("games", []):
            gid = g.get("GameId")
            if not gid or gid not in players_by_game:
                continue
            winner = str(g.get("Winner") or "")
            if winner not in ("1", "2"):
                continue  # unplayed / forfeited
            pb = pb_by_game.get(gid)
            fp_team = pb["Team1"] if pb else g.get("Team1")
            sp_team = pb["Team2"] if pb else g.get("Team2")
            con.execute(
                "INSERT OR REPLACE INTO games VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (gid, g.get("MatchId"), t["OverviewPage"], t.get("League"), t.get("Name"),
                 g.get("DateTimeUTC"), g.get("Patch"), _int(g.get("NGameInMatch")),
                 g.get("Team1"), g.get("Team2"), "blue" if winner == "1" else "red",
                 _float(g.get("GamelengthNumber")),
                 _int(g.get("Team1Dragons")), _int(g.get("Team2Dragons")),
                 _int(g.get("Team1Barons")), _int(g.get("Team2Barons")),
                 _int(g.get("Team1Towers")), _int(g.get("Team2Towers")),
                 _int(g.get("Team1Gold")), _int(g.get("Team2Gold")),
                 _int(g.get("Team1Kills")), _int(g.get("Team2Kills")),
                 _int(g.get("Team1RiftHeralds")), _int(g.get("Team2RiftHeralds")),
                 _int(g.get("Team1VoidGrubs")), _int(g.get("Team2VoidGrubs")),
                 _int(g.get("Team1Inhibitors")), _int(g.get("Team2Inhibitors")),
                 fp_team, sp_team, 1 if pb else 0),
            )
            n_games += 1
            if pb:
                for seq, (side, action, n) in enumerate(DRAFT_SEQUENCE, start=1):
                    t_no = "1" if side == "B" else "2"
                    kind = "Ban" if action == "ban" else "Pick"
                    c = champ(pb.get(f"Team{t_no}{kind}{n}"))
                    role = _role(pb.get(f"Team{t_no}Role{n}")) if action == "pick" else None
                    con.execute(
                        "INSERT OR REPLACE INTO draft_actions VALUES (?,?,?,?,?,?,?)",
                        (gid, seq, side, action, n, c, role),
                    )
            for p in players_by_game[gid]:
                role = _role(p.get("Role"))
                c = champ(p.get("Champion"))
                if not role or not c:
                    continue
                map_side = "blue" if str(p.get("Side")) == "1" else "red"
                if (map_side == "blue") != (p.get("Team") == g.get("Team1")):
                    side_mismatch += 1
                draft_side = ("B" if p.get("Team") == fp_team else "R")
                con.execute(
                    "INSERT OR REPLACE INTO players VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (gid, p.get("Team"), map_side, draft_side, role, p.get("Name"), p.get("Link"), c,
                     1 if str(p.get("PlayerWin")).lower() == "yes" else 0,
                     _int(p.get("Kills")), _int(p.get("Deaths")), _int(p.get("Assists")),
                     _int(p.get("Gold")), _int(p.get("CS")), _int(p.get("DamageToChampions")),
                     p.get("Items") or "", p.get("Trinket") or "", p.get("SummonerSpells") or "",
                     p.get("KeystoneRune") or "", p.get("PrimaryTree") or "", p.get("SecondaryTree") or "",
                     p.get("Runes") or ""),
                )
    con.commit()
    con.close()
    os.replace(tmp, db_path)
    if verbose and unknown_champs:
        print(f"  note: {len(unknown_champs)} champion names not in Data Dragon: {sorted(unknown_champs)[:10]}")
    if verbose and side_mismatch:
        print(f"  note: {side_mismatch} player rows where Side did not match ScoreboardGames.Team1")
    return n_games


def connect(db_path=DB_PATH):
    import sqlite3
    if not os.path.exists(db_path):
        raise RuntimeError("No pro database yet - run: py update.py")
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    return con
