"""My Stats: your recent games next to the average pro in your role.

Your games come from your League client's match history (no Riot key needed): the end-of-game
numbers, the minute-by-minute frames and every kill - the same numbers Riot keeps for pro games,
in the same format, so every stat below is worked out the same way for you and for the pros.

The pros: every tier-1 game in the 12 months up to the newest one (LCK, LPL, internationals).
End-of-game numbers (KDA, kills, deaths, CS, gold, damage, kill participation, shares) come from all
of them; numbers only a Riot timeline has (vision, wards, damage taken, objectives, solo kills,
gold / CS / XP at 10 and 15 minutes) from LCK and the internationals (LPL games have none).

Each of your games is set against pros on the same champion in the same role when pros played it
12+ times in those months, and against the role's average otherwise (a Zac jungler isn't held to a
Graves jungler's farm). "Beats N% of pros": the share of pros with enough games in the role whose
own average is worse than yours.

data/mystats_baseline.json holds the pro side. It's rebuilt when the pro data changes and travels
with the website, where My Stats is answered in the browser from it (no database there).
"""
import datetime as dt
import json
import math
import os
from collections import Counter, defaultdict

from . import DATA, ROLES

BASELINE_PATH = DATA / "mystats_baseline.json"
LAST_PATH = DATA / "mystats_last.json"   # your last look-up (private: share.py leaves it out)
VERSION = 2              # (a new number rebuilds every saved baseline)
WINDOW_DAYS = 365
MIN_CHAMP_GAMES = 12     # pro games of a champion in a role before it gets its own average
MIN_PRO_GAMES = {"end": 20, "tl": 10}   # games a pro needs in the role to count in "beats N% of pros"
QUANTILES = 21           # 0%, 5%, ... 100% of the pros' own averages

# key, label, group, number format, better (1: more is better, -1: less, 0: neither), pro source
#   end: every pro game's end-of-game numbers; tl: only pro games with a Riot timeline
STATS = (
    ("gd10", "Gold lead at 10 min", "lane", "sgn0", 1, "tl"),
    ("gd15", "Gold lead at 15 min", "lane", "sgn0", 1, "tl"),
    ("csd10", "CS lead at 10 min", "lane", "sgn1", 1, "tl"),
    ("csd15", "CS lead at 15 min", "lane", "sgn1", 1, "tl"),
    ("xpd10", "XP lead at 10 min", "lane", "sgn0", 1, "tl"),
    ("xpd15", "XP lead at 15 min", "lane", "sgn0", 1, "tl"),
    ("cspm", "CS per minute", "farm", "f1", 1, "end"),
    ("cs10", "CS at 10 min", "farm", "f0", 1, "tl"),
    ("cs15", "CS at 15 min", "farm", "f0", 1, "tl"),
    ("gpm", "Gold per minute", "farm", "f0", 1, "end"),
    ("gold_share", "Share of your team's gold", "farm", "pct", 1, "end"),
    ("kda", "KDA", "fight", "f2", 1, "end"),
    ("kills", "Kills per game", "fight", "f1", 1, "end"),
    ("deaths", "Deaths per game", "fight", "f1", -1, "end"),
    ("assists", "Assists per game", "fight", "f1", 1, "end"),
    ("kp", "Kill participation", "fight", "pct", 1, "end"),
    ("solo", "Solo kills per game", "fight", "f1", 1, "tl"),
    ("cc", "Seconds of crowd control on enemies per game", "fight", "f0", 1, "tl"),
    ("dpm", "Damage to champions per minute", "damage", "f0", 1, "end"),
    ("dmg_share", "Share of your team's damage", "damage", "pct", 1, "end"),
    ("taken_pm", "Damage taken per minute", "damage", "f0", 0, "tl"),
    ("mitig_pm", "Damage blocked per minute", "damage", "f0", 0, "tl"),
    ("vspm", "Vision score per minute", "vision", "f2", 1, "tl"),
    ("wpm", "Wards placed per minute", "vision", "f2", 1, "tl"),
    ("wcpm", "Wards cleared per minute", "vision", "f2", 1, "tl"),
    ("cw", "Control wards per game", "vision", "f1", 1, "tl"),
    ("turret_pm", "Damage to towers per minute", "obj", "f0", 1, "tl"),
    ("obj_pm", "Damage to objectives per minute", "obj", "f0", 1, "tl"),
)
GROUPS = (("lane", "Lane phase", "your leads over the enemy in your role"),
          ("farm", "Farming and gold", ""),
          ("fight", "Fighting", ""),
          ("damage", "Damage", ""),
          ("vision", "Vision", ""),
          ("obj", "Objectives", ""))
STAT = {s[0]: s for s in STATS}
SOURCE = {s[0]: s[5] for s in STATS}
PER_GAME = {"kills", "deaths", "assists", "solo", "cc", "cw"}   # (their gaps read best in the same units: "+1.4 a game")
EXTRA = ("ka", "d")     # KDA = sum(kills + assists) / sum(deaths), so the parts are kept too
ROLE_WORD = {"TOP": "top laners", "JNG": "junglers", "MID": "mid laners", "BOT": "bot laners", "SUP": "supports"}


# ------------------------------------------------------------------ one player's game -> its stats
def end_stats(k, d, a, gold, cs, dmg, mins, team_kills, team_gold, team_dmg):
    """The end-of-game stats of one player-game (pros: Leaguepedia; you: the client)."""
    v = {"kills": k, "deaths": d, "assists": a, "ka": k + a, "d": d, "kda": (k + a) / max(1, d)}
    if team_kills:
        v["kp"] = min(1.0, (k + a) / team_kills)
    if mins and mins > 0:
        if cs is not None:
            v["cspm"] = cs / mins
        if gold is not None:
            v["gpm"] = gold / mins
        if dmg is not None:
            v["dpm"] = dmg / mins
    if gold is not None and team_gold:
        v["gold_share"] = gold / team_gold
    if dmg is not None and team_dmg:
        v["dmg_share"] = dmg / team_dmg
    return v


def timeline_stats(rec, pid, opp_pid):
    """The stats only a timeline has, for participant pid of one compact game record
    (acp.timelines.compact: pros and your client games alike); opp_pid: the enemy in the same role."""
    v = {}
    mins = (rec.get("dur") or 0) / 60.0
    x = (rec.get("x") or {}).get(str(pid)) or {}
    if mins > 0:
        for src, key in (("vision", "vspm"), ("wards", "wpm"), ("wk", "wcpm"), ("taken", "taken_pm"),
                         ("mitig", "mitig_pm"), ("turret_dmg", "turret_pm"), ("obj_dmg", "obj_pm")):
            if x.get(src) is not None:
                v[key] = x[src] / mins
    for src in ("cw", "cc"):
        if x.get(src) is not None:
            v[src] = x[src]
    i = pid - 1
    j = opp_pid - 1 if opp_pid else None
    for arr, lead in (("cs", "csd"), ("gold", "gd"), ("xp", "xpd")):
        frames = rec.get(arr) or []
        for m in (10, 15):
            if len(frames) > m and len(frames[m]) == 10:
                row = frames[m]
                if not any(row):   # (a frame the client left empty)
                    continue
                if arr == "cs":
                    v[f"cs{m}"] = row[i]
                if j is not None:
                    v[f"{lead}{m}"] = row[i] - row[j]
    ev = rec.get("ev")
    if ev is not None and rec.get("gold"):   # (kills come with the timeline)
        v["solo"] = sum(1 for e in ev if e[1] == "K" and e[3] == pid and not e[5])
    return v


# ------------------------------------------------------------------ the pros (PC only: reads data/pro.db)
def _window(con):
    newest = con.execute("SELECT MAX(date_utc) FROM games").fetchone()[0]
    newest = str(newest or dt.date.today().isoformat())[:10]
    lo = (dt.date.fromisoformat(newest) - dt.timedelta(days=WINDOW_DAYS)).isoformat()
    return lo, newest


def _pro_end_rows(con, lo, hi):
    """(role, champion, player, stats) for every tier-1 player-game from lo to hi (end-of-game numbers)."""
    games = {}
    for r in con.execute("SELECT game_id, date_utc, length_min FROM games"):
        day = str(r["date_utc"] or "")[:10]
        if lo <= day <= hi and r["length_min"] and r["length_min"] >= 10:
            games[r["game_id"]] = float(r["length_min"])
    teams = defaultdict(list)
    for p in con.execute("SELECT game_id, team, role, player, player_link, champion, kills, deaths, assists, gold, cs, "
                         "damage FROM players"):
        if p["game_id"] in games:
            teams[(p["game_id"], p["team"])].append(p)
    for (gid, _team), mine in teams.items():
        if len(mine) != 5:
            continue
        mins = games[gid]
        tk = sum(p["kills"] or 0 for p in mine)
        tg = sum(p["gold"] or 0 for p in mine) if all(p["gold"] is not None for p in mine) else None
        td = sum(p["damage"] for p in mine) if all(p["damage"] is not None for p in mine) else None
        for p in mine:
            if p["role"] not in ROLES:
                continue
            who = (p["player_link"] or p["player"] or "").casefold()
            yield p["role"], p["champion"], who, end_stats(p["kills"] or 0, p["deaths"] or 0, p["assists"] or 0, p["gold"],
                                                           p["cs"], p["damage"], mins, tk, tg, td)


def _pro_tl_rows(con, lo, hi):
    """(role, champion, player, stats) for every player-game with a Riot timeline from lo to hi."""
    from . import timelines
    who = {}
    for p in con.execute("SELECT game_id, map_side, role, player, player_link FROM players"):
        who[(p["game_id"], p["map_side"], p["role"])] = (p["player_link"] or p["player"] or "").casefold()
    for gid, rec in timelines.load(con).items():
        if not (lo <= rec.get("date", "") <= hi) or rec.get("v") != 5 or not rec.get("x"):
            continue
        by_role = {(s, r): int(pid) for pid, (s, r) in rec["side"].items()}
        for pid, (side, role) in rec["side"].items():
            opp = by_role.get(("red" if side == "blue" else "blue", role))
            champ = rec["p"][pid][1]
            yield role, champ, who.get((gid, side, role), ""), timeline_stats(rec, int(pid), opp)


def _r(x, sig=4):
    """Rounded to sig significant digits (a smaller file)."""
    if x is None or x == 0 or not math.isfinite(x):
        return x
    return round(x, max(0, sig - 1 - int(math.floor(math.log10(abs(x))))))


def _quantiles(vals, n=QUANTILES):
    vals = sorted(vals)
    if not vals:
        return []
    out = []
    for k in range(n):
        pos = k * (len(vals) - 1) / (n - 1)
        lo = int(math.floor(pos))
        hi = min(lo + 1, len(vals) - 1)
        out.append(_r(vals[lo] + (vals[hi] - vals[lo]) * (pos - lo)))
    return out


def build_baseline():
    """The pro side of My Stats, from data/pro.db and the Riot timelines (a few seconds)."""
    from . import db
    con = db.connect()
    try:
        lo, hi = _window(con)
        rows = {"end": list(_pro_end_rows(con, lo, hi)), "tl": list(_pro_tl_rows(con, lo, hi))}
        sig = signature(con)
    finally:
        con.close()
    keys = {src: [s[0] for s in STATS if s[5] == src and s[0] != "kda"] + (list(EXTRA) + ["kda"] if src == "end" else [])
            for src in ("end", "tl")}
    roles = {}
    for role in ROLES:
        out_s, champs, n_src, pros_n = {}, defaultdict(lambda: {"n": 0, "nt": 0, "s": {}}), {}, {}
        for src in ("end", "tl"):
            mine = [(c, w, v) for r, c, w, v in rows[src] if r == role]
            n_src[src] = len(mine)
            by_champ, by_pro = defaultdict(list), defaultdict(list)
            for c, w, v in mine:
                by_champ[c].append(v)
                if w:
                    by_pro[w].append(v)
            pros = {w: vs for w, vs in by_pro.items() if len(vs) >= MIN_PRO_GAMES[src]}
            pros_n[src] = len(pros)
            for key in keys[src]:
                vals = [v[key] for _, _, v in mine if v.get(key) is not None]
                if not vals:
                    continue
                if key == "kda":   # the role's KDA: all kills + assists over all deaths
                    ka = sum(v["ka"] for _, _, v in mine)
                    mean = ka / max(1, sum(v["d"] for _, _, v in mine))
                    per_pro = [sum(v["ka"] for v in vs) / max(1, sum(v["d"] for v in vs)) for vs in pros.values()]
                else:
                    mean = sum(vals) / len(vals)
                    per_pro = [sum(v[key] for v in vs if v.get(key) is not None) / max(1, sum(1 for v in vs if v.get(key) is not None))
                               for vs in pros.values() if any(v.get(key) is not None for v in vs)]
                if key == "kda":   # (a KDA's spread on a log scale: one deathless game would swamp it otherwise)
                    logs = [math.log((v["ka"] + 1) / (v["d"] + 1)) for _, _, v in mine]
                    ml = sum(logs) / len(logs)
                    sd = math.sqrt(sum((x - ml) ** 2 for x in logs) / max(1, len(logs) - 1))
                else:
                    sd = math.sqrt(sum((x - mean) ** 2 for x in vals) / max(1, len(vals) - 1))
                pm = sum(per_pro) / len(per_pro) if per_pro else None
                sd_pro = math.sqrt(sum((x - pm) ** 2 for x in per_pro) / max(1, len(per_pro) - 1)) if len(per_pro) > 2 else None
                out_s[key] = [_r(mean), _r(sd), len(vals), _r(sd_pro), _quantiles(per_pro)]
            for c, vs in by_champ.items():
                if len(vs) < MIN_CHAMP_GAMES:
                    continue
                e = champs[c]
                e["n" if src == "end" else "nt"] = len(vs)
                for key in keys[src]:
                    if key == "kda":
                        continue
                    xs = [v[key] for v in vs if v.get(key) is not None]
                    if len(xs) >= MIN_CHAMP_GAMES:
                        e["s"][key] = _r(sum(xs) / len(xs))
        roles[role] = {"n_end": n_src["end"], "n_tl": n_src["tl"], "pros": pros_n, "s": out_s, "c": dict(champs)}
    return {"version": VERSION, "made": dt.datetime.now().isoformat(timespec="seconds"), "from": lo, "to": hi,
            "games": {"end": round(len(rows["end"]) / 10), "tl": round(len(rows["tl"]) / 10)},   # (10 player-games a game)
            "min_champ": MIN_CHAMP_GAMES, "min_pro": MIN_PRO_GAMES, "sig": sig, "roles": roles}


def signature(con=None):
    """What the baseline was built from: the pro games and the timeline files (rebuilt when either changes)."""
    from . import db, timelines
    own = con is None
    con = con or db.connect()
    try:
        n, newest = con.execute("SELECT COUNT(*), MAX(date_utc) FROM games").fetchone()
    finally:
        if own:
            con.close()
    files = sorted(timelines.TL_DIR.glob("*.json")) if timelines.TL_DIR.exists() else []
    return {"games": n, "newest": str(newest or "")[:10], "tl_files": len(files),
            "tl_bytes": sum(f.stat().st_size for f in files), "version": VERSION}


_BASE = {"b": None, "at": 0.0, "fixed": False}


def baseline(rebuild=None):
    """The pro side (cached; looked at again every 10 minutes and rebuilt when the pro data changed since it
    was saved). rebuild=True forces it, False never rebuilds (what's cached, else the saved file, else None)."""
    import time
    b = _BASE["b"]
    if b is not None and not rebuild and (_BASE["fixed"] or rebuild is False or time.monotonic() - _BASE["at"] < 600):
        return b
    base = None
    if BASELINE_PATH.exists():
        try:
            with open(BASELINE_PATH, encoding="utf-8") as f:
                base = json.load(f)
        except (OSError, ValueError):
            base = None
    if rebuild is not False:
        stale = base is None or base.get("version") != VERSION
        if not stale and rebuild is None:
            try:
                stale = base.get("sig") != signature()
            except Exception:  # noqa: BLE001 - no pro database here: use the file as it is
                stale = False
        if stale or rebuild:
            base = build_baseline()
            tmp = str(BASELINE_PATH) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(base, f, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, BASELINE_PATH)
    _BASE.update(b=base, at=time.monotonic())
    return base


def use_baseline(base):
    """The browser: the baseline that came in the website's snapshot (there's no pro database to rebuild it from)."""
    _BASE.update(b=base, fixed=True)


# ------------------------------------------------------------------ your games (from the League client)
def game_record(game, timeline, acc, champ_name, role_prob, maps):
    """One game from the client's match history (+ its timeline, optional) -> your record for My Stats:
    {id, date, champ, role, opp, win, length, stats}; None for remakes, early surrenders and games the
    account isn't in. maps: acp.timelines.champ_maps(Data Dragon champions)."""
    from . import leagueclient as lc
    from . import timelines
    base = lc.client_record(game, acc, champ_name, role_prob)
    if not base:
        return None
    st = end_stats(base["k"], base["d"], base["a"], base["gold"], base["cs"], base["dmg"], base["length"],
                   base["team_kills"], base["team_gold"], base["team_dmg"])
    rec = timelines.compact(game, timeline if timeline and timeline.get("frames") else None, maps)
    if rec:
        st.update(timeline_stats(rec, base["pid"], base.get("opp_pid")))
    return {"id": base["id"], "date": base["date"], "created": base.get("created"), "champ": base["champ"],
            "role": base["role"], "opp": base.get("opp_champ"), "win": base["win"],
            "k": base["k"], "d": base["d"], "a": base["a"], "length": round(base["length"], 2),
            "queue": base.get("event"), "stats": {k: (round(v, 4) if isinstance(v, float) else v) for k, v in st.items()}}


def from_client(lcu, champ_name, role_prob, maps, queue="ranked", count=20):
    """The PC version: your last `count` games in `queue` straight from the League client ->
    (account, your records newest first, rank)."""
    from . import leagueclient as lc
    acc = lc.client_account(lcu)
    if not acc:
        raise LookupError("Your League client isn't signed in yet.")
    hist = lc.client_history(lcu, acc, queue, count)
    ids = [g.get("gameId") for g in hist]
    lc._prefetch(lcu, ids, timelines=True)
    recs = []
    for gid in ids:
        game = lc.client_game(lcu, gid)
        if not game:
            continue
        try:
            tl = lc.client_timeline(lcu, gid)
        except OSError:   # (a timeline that won't come: that game keeps its end-of-game numbers)
            tl = None
        r = game_record(game, tl, acc, champ_name, role_prob, maps)
        if r:
            recs.append(r)
    return acc, recs, lc.client_rank(lcu, acc["puuid"])


def records_from_raw(raw, champ_name, role_prob, maps, queue="ranked", count=20):
    """The browser version: what the League helper read from the client ({me, ranked, history, games,
    timelines}) -> (account, your records, rank)."""
    from . import leagueclient as lc
    me = raw.get("me") or {}
    acc = {"puuid": me.get("puuid"), "name": lc._name_of(me), "me": True, "summonerId": me.get("summonerId"),
           "accountId": me.get("accountId")}
    if not acc["puuid"]:
        raise LookupError("Your League client isn't signed in yet.")
    want = lc.HISTORY_QUEUES.get(queue, lc.HISTORY_QUEUES["ranked"])
    hist = [g for g in raw.get("history") or [] if isinstance(g, dict) and lc.history_queue_id(g) in want]
    hist.sort(key=lambda g: g.get("gameCreation") or 0, reverse=True)
    games, tls = raw.get("games") or {}, raw.get("timelines") or {}
    recs = []
    for g in hist[:count]:
        gid = str(g.get("gameId"))
        full = games.get(gid)
        if not isinstance(full, dict) or len(full.get("participants") or []) != 10:
            continue
        r = game_record(full, tls.get(gid), acc, champ_name, role_prob, maps)
        if r:
            recs.append(r)
    return acc, recs, lc.parse_rank(raw.get("ranked"))


# ------------------------------------------------------------------ you vs the pros
def _pct_rank(q, x, better):
    """The share of pros (their own averages: quantiles q) you beat."""
    if not q or x is None:
        return None
    if better < 0:   # less is better: you beat the pros above you
        return 1 - _pct_rank(q, x, 1)
    if x <= q[0]:
        return 0.0
    if x >= q[-1]:
        return 1.0
    step = 1 / (len(q) - 1)
    for k in range(1, len(q)):
        if x <= q[k]:
            span = q[k] - q[k - 1]
            return (k - 1) * step + (step * (x - q[k - 1]) / span if span else 0)
    return 1.0


def _verdict(z, better):
    if better == 0 or z is None:
        return "info"
    if z >= 0.25:
        return "better"
    if z >= -0.35:
        return "close"
    if z >= -1.0:
        return "behind"
    return "far"


def compare(records, base, role=None):
    """Your records vs the pros in one role (the one you play most unless role is given)."""
    if not base or not base.get("roles"):
        raise ValueError("The pro numbers for My Stats aren't built yet (they come with the pro data).")
    if not records:
        raise ValueError("no games to compare")
    roles = Counter(r["role"] for r in records if r.get("role") in ROLES)
    if not roles:
        raise ValueError("couldn't tell which role you played in these games")
    role = role if role in roles else roles.most_common(1)[0][0]
    mine = [r for r in records if r.get("role") == role]
    R = base["roles"][role]
    S, C = R["s"], R["c"]

    def ref(rec, key):
        """The pro number this game is held to: same champion when pros played it enough, else the role."""
        src = SOURCE.get(key, "end")
        c = C.get(rec["champ"])
        if c and c.get("n" if src == "end" else "nt", 0) >= MIN_CHAMP_GAMES and key in c["s"]:
            return c["s"][key], True
        s = S.get(key)
        return (s[0], False) if s else (None, False)

    rows = {}
    for key, label, group, fmt, better, src in STATS:
        s = S.get(key)
        if not s:
            continue
        if key == "kda":
            ka = sum(r["stats"]["ka"] for r in mine)
            d = sum(r["stats"]["d"] for r in mine)
            you = ka / max(1, d)
            refs = [(ref(r, "ka"), ref(r, "d")) for r in mine]
            pka, pd = sum(a[0] for a, _ in refs if a[0] is not None), sum(b[0] for _, b in refs if b[0] is not None)
            pro = pka / pd if pd else s[0]
            champ_n = sum(1 for a, _ in refs if a[1])
            n = len(mine)
        else:
            sel = [r for r in mine if r["stats"].get(key) is not None]
            if not sel:
                continue
            you = sum(r["stats"][key] for r in sel) / len(sel)
            refs = [ref(r, key) for r in sel]
            pro = sum(x for x, _ in refs) / len(refs)
            champ_n = sum(1 for _, c in refs if c)
            n = len(sel)
        mean, sd, _pn, sd_pro, q = s
        gap = you - pro
        if key == "kda":   # (its spread is on a log scale)
            z = math.log(max(you, 0.05) / pro) / sd if (sd and pro) else None
        else:
            z = (gap / sd) * (better or 1) if sd else None
        signed = fmt in ("sgn0", "sgn1")
        # where you'd stand among the pros (their averages, any champion) once your champions are allowed for
        adj = you * mean / pro if (not signed and pro and mean) else you + (mean - pro)
        # how the gap reads best: share points, the same units (leads, counts per game), or a percentage (rates)
        show = "pts" if fmt == "pct" else "abs" if (signed or key in PER_GAME) else "rel"
        rows[key] = {"key": key, "label": label, "group": group, "fmt": fmt, "better": better, "you": you, "pro": pro,
                     "show": show, "pro_role": mean, "gap": gap, "rel": (you / pro - 1) if (pro and not signed) else None,
                     "z": z, "verdict": _verdict(z, better), "games": n, "champ_games": champ_n,
                     "beats": _pct_rank(q, adj, better) if better else None,
                     "band": [q[2], q[18]] if len(q) == QUANTILES else None, "pros": R["pros"][src]}
    ranked = sorted((r for r in rows.values() if r["better"] and r["z"] is not None), key=lambda r: r["z"])
    wins = sum(r["win"] for r in mine)
    by_champ = []
    for champ, n in Counter(r["champ"] for r in mine).most_common():
        cs = [r for r in mine if r["champ"] == champ]
        row = {"champ": champ, "games": n, "wins": sum(r["win"] for r in cs),
               "pro_champ": bool(C.get(champ) and C[champ].get("n", 0) >= MIN_CHAMP_GAMES), "stats": {}}
        for key in ("kda", "cspm", "gpm", "dpm", "kp", "vspm", "gd15", "deaths"):
            if key == "kda":
                you = sum(r["stats"]["ka"] for r in cs) / max(1, sum(r["stats"]["d"] for r in cs))
                a = [ref(r, "ka")[0] for r in cs]
                b = [ref(r, "d")[0] for r in cs]
                pro = (sum(x for x in a if x is not None) / sum(x for x in b if x is not None)) if all(x is not None for x in a + b) and sum(b) else None
            else:
                sel = [r for r in cs if r["stats"].get(key) is not None]
                if not sel:
                    continue
                you = sum(r["stats"][key] for r in sel) / len(sel)
                pros = [ref(r, key)[0] for r in sel]
                pro = sum(pros) / len(pros) if all(p is not None for p in pros) else None
            row["stats"][key] = [you, pro]
        by_champ.append(row)
    games = []
    for r in sorted(mine, key=lambda r: (r.get("created") or 0, r["date"]), reverse=True):
        st = r["stats"]
        games.append({"id": r["id"], "date": r["date"], "queue": r.get("queue"), "champ": r["champ"], "opp": r.get("opp"), "win": r["win"],
                      "k": r["k"], "d": r["d"], "a": r["a"], "length": r["length"],
                      "cspm": st.get("cspm"), "gd15": st.get("gd15"), "dpm": st.get("dpm"), "vspm": st.get("vspm"),
                      "kp": st.get("kp")})
    timeline_games = sum(1 for r in mine if "gd10" in r["stats"] or "vspm" in r["stats"])
    return {"role": role, "role_word": ROLE_WORD.get(role, role), "roles": dict(roles.most_common()),
            "games": len(mine), "all_games": len(records), "wins": wins, "timeline_games": timeline_games,
            "groups": [{"key": g, "label": lbl, "note": note, "rows": [rows[s[0]] for s in STATS if s[2] == g and s[0] in rows]}
                       for g, lbl, note in GROUPS],
            "best": [r["key"] for r in ranked[::-1][:3] if r["z"] > -0.35],
            "worst": [r["key"] for r in ranked[:3] if r["z"] < -0.35],
            "by_champion": by_champ, "recent": games,
            "pro": {"from": base["from"], "to": base["to"], "games": base["games"], "role_games": R["n_end"],
                    "role_tl_games": R["n_tl"], "pros": R["pros"], "min_champ": base["min_champ"],
                    "leagues": "LCK, LPL and internationals", "tl_leagues": "LCK and internationals"}}


def payload(state, base, role=None, count=None):
    """state = {account, rank, records (newest first), queue, count, fetched, source} -> what the My Stats
    tab shows (count: only the newest that many of the records)."""
    from . import leagueclient as lc
    recs = state["records"][:count] if count else state["records"]
    res = compare(recs, base, role)
    q = state.get("queue") or "ranked"
    res.update(account={"name": state["account"].get("name"), "me": True}, rank=(state.get("rank") or {}).get(q)
               if q in ("ranked", "flex") else None, queue=q, queue_name=lc.HISTORY_NAMES.get(q, q), count=count or state.get("count"),
        fetched=state.get("fetched"), source=state.get("source", "client"))
    return res


def save_last(state):
    tmp = str(LAST_PATH) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, LAST_PATH)


def load_last():
    try:
        with open(LAST_PATH, encoding="utf-8") as f:
            st = json.load(f)
        return st if isinstance(st, dict) and st.get("records") else None
    except (OSError, ValueError):
        return None
