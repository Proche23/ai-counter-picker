"""The website's answers without a server: the in-browser version (build_web.py makes it) runs this
module inside the browser with Pyodide (Python compiled to WebAssembly).

The engine is the same Python as the local site. build_web.py builds the Advisor on the PC and saves
a snapshot of it (make_snapshot): the statistics the engine reads, the learned model, every build
guide worked out in advance (StaticBuilds), the solo queue tables and the page's champion list. The
pro database itself (100+ MB) never goes to the browser. In the browser, load() reads the snapshot
once and handle() answers each /api/... request the page makes, like serve.py does on the PC.

What the browser version can't do (needs the PC): following your League client, phone mode, the
draft tracker window, Riot-key look-ups and the Players page.
"""
import datetime as dt
import json
import pickle
import zlib
from urllib.parse import parse_qs

from . import ROLES

STATE = {}
SNAPSHOT_VERSION = 1


class StaticBuilds:
    """Every champion's build guide in every role it has pro games in, worked out on the PC
    (Builds.for_champ with no lane opponent: the browser has no per-game rows to narrow it down)."""

    def __init__(self, table):
        self.table = table   # (champion, role) -> the build, or None

    def for_champ(self, champ, role, opp=None):
        return self.table.get((champ, role))


def _lite(adv):
    """A copy of an Advisor without the per-game rows (players, draft actions, games: ~50 MB for the pro
    data), with every champion-role's build worked out now (StaticBuilds); the summary is kept."""
    import copy
    st = adv.stats
    table = {}
    for (c, r), n in st.raw_games.items():
        if n:
            try:
                table[(c, r)] = adv.builds.for_champ(c, r)
            except Exception:  # noqa: BLE001 - a champion without a usable build just has none
                table[(c, r)] = None
    summary = st.summary()
    lite = copy.copy(adv)
    lst = copy.copy(st)
    lst.players, lst.actions, lst.games = {}, {}, {}
    lst._summary = summary
    lite.stats = lst
    sb = StaticBuilds(table)
    lite.builds = sb
    lite.engine = copy.copy(adv.engine)
    lite.engine.s, lite.engine.b, lite.engine._cache = lst, sb, {}
    lite.predictor = copy.copy(adv.predictor)
    lite.predictor.s = lst
    if getattr(lite.predictor, "engine", None) is not None:
        lite.predictor.engine = lite.engine
    lite.engine.predictor = lite.predictor if adv.engine.predictor is not None else None
    lite.planner = copy.copy(adv.planner)
    lite.planner.s, lite.planner.b = lst, sb
    return lite


def make_snapshot(adv, solo_book=None, meta=None, solo_files=(), solo_status=None):
    """The Advisor as bytes for the browser: zlib(pickle). solo_files: the solo queue snapshots built next
    to it (engine/solo-<rank>.bin, loaded when the page first asks for that rank); solo_status: what the
    rank picker and the Lab page show about them."""
    lite = _lite(adv)
    files = {}   # data files the engine itself reads while answering (the verdict's calibration table)
    from . import DATA
    rep = DATA / "lab_report.json"
    if rep.exists():
        with open(rep, encoding="utf-8") as f:
            files["lab_report.json"] = json.dumps({"calibration": json.load(f).get("calibration", {})})
    from . import mystats
    payload = {"version": SNAPSHOT_VERSION, "made": dt.datetime.now().isoformat(timespec="seconds"), "files": files,
               "adv": lite, "solo": solo_book if (solo_book is not None and solo_book.matches) else None, "meta": meta,
               "solo_files": list(solo_files), "solo_status": solo_status,
               "mystats": mystats.baseline()}   # (My Stats: the pros' numbers your games are set against)
    return zlib.compress(pickle.dumps(payload, protocol=5), 6)


def make_solo_snapshot(sadv=None, book=None):
    """One rank's solo queue advisor (acp.solorank.SoloAdvisor) and that rank's Solo queue page tables
    (or, with no advisor, every rank's tables), for engine/solo-<rank>.bin. The Data Dragon data isn't
    repeated in it: load_solo() gives it the main snapshot's."""
    lite = None
    if sadv is not None:
        lite = _lite(sadv)
        lite.dd = lite.names = None
        lite.engine.dd = None
        lite.planner.dd = None
        lite.stats.dd_champs = None
    payload = {"version": SNAPSHOT_VERSION, "rank": getattr(sadv, "rank", None), "adv": lite,
               "book": book.pruned() if (book is not None and book.matches) else None}
    return zlib.compress(pickle.dumps(payload, protocol=5), 6)


def load_solo(key, path):
    """Read engine/solo-<key>.bin (written to `path` by the page's engine worker) next to the main snapshot."""
    with open(path, "rb") as f:
        payload = pickle.loads(zlib.decompress(f.read()))
    main = STATE["adv"]
    adv = payload.get("adv")
    if adv is not None:
        champs = main.dd["champions"]
        adv.dd, adv.names = main.dd, main.names
        adv.engine.dd = champs
        adv.planner.dd = champs
        adv.stats.dd_champs = champs
        STATE.setdefault("solo_advs", {})[key] = adv
    if payload.get("book") is not None:
        payload["book"].dd = main.dd
        STATE.setdefault("solo_books", {})[key] = payload["book"]
    return True


class NeedSolo(Exception):
    """The page asked for a solo queue rank whose snapshot isn't loaded yet: the worker fetches it."""


def _solo_adv(rank):
    from .soloq import RANK_LABEL
    have = STATE.get("solo_advs") or {}
    if rank in have:
        return have[rank]
    if rank in (STATE.get("solo_files") or []):
        raise NeedSolo(rank)
    if rank not in RANK_LABEL:
        raise ValueError(f"unknown rank '{rank}'")
    if (STATE.get("solo_status") or {}).get("web_off"):
        raise ValueError(f"No {RANK_LABEL[rank]} solo queue games on this website yet: Riot's rules allow ranked-game data on a "
                         "public site only once the site is registered with Riot. Solo queue works in the PC version of "
                         "AI Counter Picker (website.bat), with your own Riot key.")
    raise ValueError(f"No {RANK_LABEL[rank]} solo queue games yet. This website's solo queue games are downloaded with "
                     "the full version on a PC (it needs a Riot key) and come with the next update of the site.")


def _solo_book(rank):
    key = rank or "all"
    have = STATE.get("solo_books") or {}
    if key in have:
        return have[key]
    if key in (STATE.get("solo_files") or []):
        raise NeedSolo(key)
    return None


def load_bytes(data, data_dir=None):
    """Read a snapshot. The data files it carries are written to data_dir (default: this copy's data/
    folder, which in the browser starts empty), so the engine finds them where it always looks."""
    import os
    from . import DATA
    from .learning import set_params
    STATE.clear()
    STATE.update(pickle.loads(zlib.decompress(data)))
    folder = data_dir or DATA
    for name, text in (STATE.get("files") or {}).items():
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, name)
        if not os.path.exists(path):
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
    adv = STATE["adv"]
    set_params(adv.model.get("params"))   # (module-level settings the engine was built with)
    STATE["solo_eng"] = None
    if STATE.get("mystats"):
        from . import mystats
        mystats.use_baseline(STATE["mystats"])
    return STATE


def _mystats(path, data, adv):
    """My Stats in the browser. /api/mystats-parse: what the League helper read from your client (match
    history, games, timelines, rank) -> your records; /api/mystats-compare: records -> the tab's numbers."""
    from . import leagueclient as lc
    from . import mystats
    from . import timelines
    data = data if isinstance(data, dict) else {}
    if path == "/api/mystats-parse":
        champs = adv.dd["champions"]
        by_key = {int(c["key"]): n for n, c in champs.items() if str(c.get("key") or "").isdigit()}
        queue = data.get("queue") if data.get("queue") in lc.HISTORY_QUEUES else "ranked"
        try:
            count = max(5, min(int(data.get("count") or 20), 50))
        except (TypeError, ValueError):
            count = 20
        try:
            acc, recs, rank = mystats.records_from_raw(data.get("raw") or {}, by_key.get, adv.engine.role_prob,
                                                       timelines.champ_maps(champs), queue, count)
        except LookupError as exc:
            return 404, {"error": str(exc)}
        if not recs:
            return 404, {"error": f"No {lc.HISTORY_NAMES[queue]} games in your recent match history (the client keeps "
                                  "about your last 20 games): try another queue.", "empty": True}
        return 200, {"account": {"name": acc["name"]}, "rank": rank, "records": recs, "queue": queue, "count": count,
                     "fetched": data.get("fetched") or dt.datetime.now().isoformat(timespec="seconds"), "source": "helper"}
    state = data.get("state") or {}
    if not state.get("records"):
        return 400, {"error": "no games to compare"}
    out = mystats.payload(state, mystats.baseline(rebuild=False), data.get("role") or None, data.get("count") or None)
    out["stale"] = bool(data.get("stale"))
    out["stale_why"] = str(data.get("why") or "") if out["stale"] else ""
    return 200, out


def load(path):
    with open(path, "rb") as f:
        return load_bytes(f.read())


def _json(obj):
    def default(o):
        if isinstance(o, (dt.datetime, dt.date)):
            return o.isoformat()
        if isinstance(o, set):
            return sorted(o)
        return str(o)
    return json.dumps(obj, default=default, ensure_ascii=False)


def _solo_engine(adv):
    book = STATE.get("solo")
    if book is None:
        return None
    if STATE.get("solo_eng") is None:
        from .soloq import solo_engine
        STATE["solo_eng"] = solo_engine(adv, book)
    return STATE["solo_eng"]


def _soloq(path, q, adv):
    from .soloq import TIER_LABEL, rank_of
    exact_counts = (STATE.get("solo_status") or {}).get("exact_counts") or {}
    if path == "/api/soloq/ranks":   # the board's rank picker and the Lab page
        out = dict(STATE.get("solo_status") or {"lab": {}, "ranks": {}})
        out.update(download={"running": False, "web": True}, riot={"configured": False, "blocked": True, "web": True})
        return 200, out
    book = _solo_book(q.get("rank") or "")
    if book is None:
        if path == "/api/soloq/meta":
            return 200, {"summary": {"games": 0, "patches": [], "tiers": {}, "platforms": {}, "newest": None, "oldest": None},
                         "download": {"running": False, "web": True}, "riot": {"configured": False, "blocked": True, "web": True},
                         "platform": "na1", "platforms": {}, "tiers": TIER_LABEL, "version": adv.dd["version"],
                         "champ_ids": {}, "roles": {}, "web": True,
                         "ranks": exact_counts}
        return 404, {"error": "This copy has no solo queue games."}
    if q.get("patch"):   # (one patch only: the browser keeps all patches; filter by building one book per patch on the PC)
        pass
    if path == "/api/soloq/meta":
        dd = adv.dd
        return 200, {"summary": book.summary(), "download": {"running": False, "web": True},
                     "riot": {"configured": False, "blocked": True, "web": True}, "platform": "na1",
                     "platforms": (STATE.get("solo_status") or {}).get("platforms") or {}, "tiers": TIER_LABEL,
                     "version": dd["version"], "spells": dd.get("spells") or {},
                     "runes": {ru["name"]: ru.get("icon") for tree in dd.get("runes") or [] for slot in tree.get("slots") or []
                               for ru in slot.get("runes") or []},
                     "champ_ids": {n: c.get("id") for n, c in dd["champions"].items()},
                     "roles": {r: sum(1 for (c, rr) in book.cr if rr == r) for r in ROLES}, "web": True,
                     "ranks": exact_counts,
                     "rank": getattr(book, "rank", None)}
    if path == "/api/soloq/role":
        role = q.get("role") or "MID"
        if role not in ROLES:
            return 400, {"error": "unknown role"}
        return 200, {"role": role, "games": book.matches, "rows": book.role_rows(role, pro=adv.stats)}
    if path == "/api/soloq/champ":
        champ = adv.names.resolve(q.get("name") or "")
        role = q.get("role") or ""
        if role not in ROLES:
            role = max(ROLES, key=lambda r: book.cr[(champ, r)].n if (champ, r) in book.cr else 0)
        return 200, book.champ_report(champ, role, pro=adv.stats)
    return 404, {"error": "not found"}


def handle(method, path, query="", body=""):
    """One request from the page -> JSON text {"status": ..., "body": ...}."""
    try:
        adv = STATE["adv"]
        q = {k: v[0] for k, v in parse_qs(query or "").items()}
        data = json.loads(body) if body else {}
        if path == "/api/analyze" and method == "POST":
            from . import api
            data = data if isinstance(data, dict) else {}
            if data.get("mode") == "solo":   # the Solo queue tab: one rank's solo queue games
                out = api.analyze(_solo_adv(data.get("rank") or ""), data)
                out["mode"], out["rank"] = "solo", data.get("rank")
                status = 200
            else:
                status, out = 200, api.analyze(adv, data, solo_engine=_solo_engine)
        elif path == "/api/meta":
            status, out = 200, STATE.get("meta")
        elif path == "/api/champion":
            if q.get("mode") == "solo":
                adv = _solo_adv(q.get("rank") or "")
            champ = adv.names.resolve(q.get("name") or "")
            vs = adv.names.resolve(q["vs"]) if q.get("vs") else None
            role = q.get("role")
            status, out = 200, adv.champion_report(champ, role if role in ROLES else None, vs)
        elif path == "/api/my-build":
            if q.get("mode") == "solo":
                adv = _solo_adv(q.get("rank") or "")
            champ = adv.names.resolve(q.get("name") or "")
            vs = adv.names.resolve(q["vs"]) if q.get("vs") else None
            enemies = [adv.names.resolve(e) for e in (q.get("enemies") or "").split(",") if e.strip()][:5]
            status, out = 200, adv.my_build(champ, q.get("role") or None, vs, enemies)
        elif path.startswith("/api/soloq/"):
            status, out = _soloq(path, q, adv)
        elif path == "/api/my-pool":
            status, out = 200, {"riot_id": None, "games": 0, "main_role": None, "roles": {}, "web": True}
        elif path in ("/api/mystats-parse", "/api/mystats-compare") and method == "POST":   # My Stats (web-shim.js)
            status, out = _mystats(path, data, adv)
        elif path == "/api/client-parse" and method == "POST":   # the League helper's read of the client -> state
            from . import leagueclient as lc
            if "client_maps" not in STATE:
                dd = adv.dd
                champs, items, item_ids = dd["champions"], dd.get("items") or {}, dd.get("item_ids") or {}
                STATE["client_maps"] = (
                    {int(c["key"]): n for n, c in champs.items() if str(c.get("key") or "").isdigit()},
                    {c["id"]: n for n, c in champs.items() if c.get("id")},
                    {iid: items[n]["gold"] for iid, n in item_ids.items() if n in items})
            by_id, by_dd_id, item_gold = STATE["client_maps"]
            status, out = 200, lc.state_from_raw(data, by_id, by_dd_id, item_gold)
        else:
            status, out = 404, {"error": "not in the web version"}
    except NeedSolo as exc:   # (the worker loads engine/solo-<rank>.bin and asks again)
        status, out = 409, {"need_solo": str(exc.args[0])}
    except ValueError as exc:
        status, out = 400, {"error": str(exc)}
    except Exception as exc:  # noqa: BLE001 - the page shows the message
        import traceback
        traceback.print_exc()
        status, out = 500, {"error": f"{type(exc).__name__}: {exc}"}
    return _json({"status": status, "body": out})
