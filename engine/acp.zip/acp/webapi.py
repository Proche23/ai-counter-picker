"""The website's answers without a server: the in-browser version (build_web.py makes it) runs this
module inside the browser with Pyodide (Python compiled to WebAssembly).

The engine is the same Python as the local site. build_web.py builds the Advisor on the PC and saves
a snapshot of it (make_snapshot): the statistics the engine reads, the learned model, every build
guide worked out in advance (StaticBuilds), the solo queue tables and the page's champion list. The
pro database itself (100+ MB) never goes to the browser. In the browser, load() reads the snapshot
once and handle() answers each /api/... request the page makes, like serve.py does on the PC.

What the browser version can't do (needs the PC): following your League client, phone mode, the
draft tracker window, Riot-key look-ups and the Players page.
"""
import datetime as dt
import json
import pickle
import zlib
from urllib.parse import parse_qs

from . import ROLES

STATE = {}
SNAPSHOT_VERSION = 1


class StaticBuilds:
    """Every champion's build guide in every role it has pro games in, worked out on the PC
    (Builds.for_champ with no lane opponent: the browser has no per-game rows to narrow it down)."""

    def __init__(self, table):
        self.table = table   # (champion, role) -> the build, or None

    def for_champ(self, champ, role, opp=None):
        return self.table.get((champ, role))


def make_snapshot(adv, solo_book=None, meta=None):
    """The Advisor (and solo queue tables) as bytes for the browser: zlib(pickle). Builds are worked
    out for every champion-role now, and the per-game rows (players, draft actions, games: ~50 MB)
    are left out; the summary every answer carries is kept as it was."""
    import copy
    st = adv.stats
    table = {}
    for (c, r), n in st.raw_games.items():
        if n:
            try:
                table[(c, r)] = adv.builds.for_champ(c, r)
            except Exception:  # noqa: BLE001 - a champion without a usable build just has none
                table[(c, r)] = None
    summary = st.summary()
    lite = copy.copy(adv)
    lst = copy.copy(st)
    lst.players, lst.actions, lst.games = {}, {}, {}
    lst._summary = summary
    lite.stats = lst
    sb = StaticBuilds(table)
    lite.builds = sb
    lite.engine = copy.copy(adv.engine)
    lite.engine.s, lite.engine.b, lite.engine._cache = lst, sb, {}
    lite.predictor = copy.copy(adv.predictor)
    lite.predictor.s = lst
    if getattr(lite.predictor, "engine", None) is not None:
        lite.predictor.engine = lite.engine
    lite.engine.predictor = lite.predictor if adv.engine.predictor is not None else None
    lite.planner = copy.copy(adv.planner)
    lite.planner.s, lite.planner.b = lst, sb
    files = {}   # data files the engine itself reads while answering (the verdict's calibration table)
    from . import DATA
    rep = DATA / "lab_report.json"
    if rep.exists():
        with open(rep, encoding="utf-8") as f:
            files["lab_report.json"] = json.dumps({"calibration": json.load(f).get("calibration", {})})
    payload = {"version": SNAPSHOT_VERSION, "made": dt.datetime.now().isoformat(timespec="seconds"), "files": files,
               "adv": lite, "solo": solo_book if (solo_book is not None and solo_book.matches) else None, "meta": meta}
    return zlib.compress(pickle.dumps(payload, protocol=5), 6)


def load_bytes(data, data_dir=None):
    """Read a snapshot. The data files it carries are written to data_dir (default: this copy's data/
    folder, which in the browser starts empty), so the engine finds them where it always looks."""
    import os
    from . import DATA
    from .learning import set_params
    STATE.clear()
    STATE.update(pickle.loads(zlib.decompress(data)))
    folder = data_dir or DATA
    for name, text in (STATE.get("files") or {}).items():
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, name)
        if not os.path.exists(path):
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
    adv = STATE["adv"]
    set_params(adv.model.get("params"))   # (module-level settings the engine was built with)
    STATE["solo_eng"] = None
    return STATE


def load(path):
    with open(path, "rb") as f:
        return load_bytes(f.read())


def _json(obj):
    def default(o):
        if isinstance(o, (dt.datetime, dt.date)):
            return o.isoformat()
        if isinstance(o, set):
            return sorted(o)
        return str(o)
    return json.dumps(obj, default=default, ensure_ascii=False)


def _solo_engine(adv):
    book = STATE.get("solo")
    if book is None:
        return None
    if STATE.get("solo_eng") is None:
        from .soloq import solo_engine
        STATE["solo_eng"] = solo_engine(adv, book)
    return STATE["solo_eng"]


def _soloq(path, q, adv):
    from .soloq import TIER_LABEL
    book = STATE.get("solo")
    if book is None:
        if path == "/api/soloq/meta":
            return 200, {"summary": {"games": 0, "patches": [], "tiers": {}, "platforms": {}, "newest": None, "oldest": None},
                         "download": {"running": False, "web": True}, "riot": {"configured": False, "blocked": True, "web": True},
                         "platform": "na1", "platforms": {}, "tiers": TIER_LABEL, "version": adv.dd["version"],
                         "champ_ids": {}, "roles": {}, "web": True}
        return 404, {"error": "This copy has no solo queue games."}
    if q.get("patch"):   # (one patch only: the browser keeps all patches; filter by building one book per patch on the PC)
        pass
    if path == "/api/soloq/meta":
        dd = adv.dd
        return 200, {"summary": book.summary(), "download": {"running": False, "web": True},
                     "riot": {"configured": False, "blocked": True, "web": True}, "platform": "na1",
                     "platforms": {}, "tiers": TIER_LABEL, "version": dd["version"], "spells": dd.get("spells") or {},
                     "runes": {ru["name"]: ru.get("icon") for tree in dd.get("runes") or [] for slot in tree.get("slots") or []
                               for ru in slot.get("runes") or []},
                     "champ_ids": {n: c.get("id") for n, c in dd["champions"].items()},
                     "roles": {r: sum(1 for (c, rr) in book.cr if rr == r) for r in ROLES}, "web": True}
    if path == "/api/soloq/role":
        role = q.get("role") or "MID"
        if role not in ROLES:
            return 400, {"error": "unknown role"}
        return 200, {"role": role, "games": book.matches, "rows": book.role_rows(role, pro=adv.stats)}
    if path == "/api/soloq/champ":
        champ = adv.names.resolve(q.get("name") or "")
        role = q.get("role") or ""
        if role not in ROLES:
            role = max(ROLES, key=lambda r: book.cr[(champ, r)].n if (champ, r) in book.cr else 0)
        return 200, book.champ_report(champ, role, pro=adv.stats)
    return 404, {"error": "not found"}


def handle(method, path, query="", body=""):
    """One request from the page -> JSON text {"status": ..., "body": ...}."""
    try:
        adv = STATE["adv"]
        q = {k: v[0] for k, v in parse_qs(query or "").items()}
        data = json.loads(body) if body else {}
        if path == "/api/analyze" and method == "POST":
            from . import api
            status, out = 200, api.analyze(adv, data if isinstance(data, dict) else {}, solo_engine=_solo_engine)
        elif path == "/api/meta":
            status, out = 200, STATE.get("meta")
        elif path == "/api/champion":
            champ = adv.names.resolve(q.get("name") or "")
            vs = adv.names.resolve(q["vs"]) if q.get("vs") else None
            role = q.get("role")
            status, out = 200, adv.champion_report(champ, role if role in ROLES else None, vs)
        elif path == "/api/my-build":
            champ = adv.names.resolve(q.get("name") or "")
            vs = adv.names.resolve(q["vs"]) if q.get("vs") else None
            enemies = [adv.names.resolve(e) for e in (q.get("enemies") or "").split(",") if e.strip()][:5]
            status, out = 200, adv.my_build(champ, q.get("role") or None, vs, enemies)
        elif path.startswith("/api/soloq/"):
            status, out = _soloq(path, q, adv)
        elif path == "/api/my-pool":
            status, out = 200, {"riot_id": None, "games": 0, "main_role": None, "roles": {}, "web": True}
        else:
            status, out = 404, {"error": "not in the web version"}
    except ValueError as exc:
        status, out = 400, {"error": str(exc)}
    except Exception as exc:  # noqa: BLE001 - the page shows the message
        import traceback
        traceback.print_exc()
        status, out = 500, {"error": f"{type(exc).__name__}: {exc}"}
    return _json({"status": status, "body": out})
