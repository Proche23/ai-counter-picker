"""Your League client, read live: queue, champ select as it happens, and the score of the game you're in.

The League client runs a small web service on your own PC for its own windows (the "LCU"); tools like
op.gg, Porofessor and Blitz read champ select the same way. Its port and password are in the client's
"lockfile", which exists only while the client is open. While a game runs, the game itself answers on
127.0.0.1:2999 (Riot's Live Client Data API, no password).

This module only ever READS: it never picks, bans, accepts or locks anything. Everything stays on
127.0.0.1, and the client's password stays inside this process (the web page never sees it).
"""
import base64
import hashlib
import http.client
import json
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

POSITION = {"top": "TOP", "jungle": "JNG", "middle": "MID", "mid": "MID", "bottom": "BOT", "bot": "BOT",
            "utility": "SUP", "support": "SUP"}
LIVE_POSITION = {"TOP": "TOP", "JUNGLE": "JNG", "MIDDLE": "MID", "BOTTOM": "BOT", "UTILITY": "SUP"}
QUEUES = {400: "Normal Draft", 420: "Ranked Solo/Duo", 440: "Ranked Flex", 430: "Normal Blind", 490: "Quickplay",
          480: "Swiftplay", 450: "ARAM", 700: "Clash", 720: "ARAM Clash", 0: "Custom game", 1700: "Arena",
          1900: "URF", 900: "ARURF", 3100: "Custom game", 3140: "Practice Tool"}
BARON_BUFF_S, ELDER_BUFF_S = 180, 150   # (same as acp.gamestate)
IN_GAME = ("GameStart", "InProgress", "Reconnect")
GAME_EXE = "League of Legends.exe"   # the game itself (the client is LeagueClient / LeagueClientUx)
LIVE_URL = "https://127.0.0.1:2999"
NO_WINDOW = 0x08000000 if os.name == "nt" else 0   # don't flash a console when asking Windows about processes


def _insecure_local_tls():
    """The client and the game use Riot's own self-signed certificate on 127.0.0.1."""
    import ssl   # (here, not at the top: the in-browser version imports this module for its parsers only)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


# ------------------------------------------------------------------ finding the client
def install_dirs():
    """Where League might be installed: the Riot Client's own record first, then the usual folders."""
    out = []
    meta = (Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "Riot Games" / "Metadata"
            / "league_of_legends.live" / "league_of_legends.live.product_settings.yaml")
    try:
        for line in meta.read_text(encoding="utf-8", errors="replace").splitlines():
            m = re.match(r'\s*product_install_full_path:\s*"?(.+?)"?\s*$', line)
            if m:
                out.append(Path(m.group(1)))
    except OSError:
        pass
    if os.name == "nt":   # (only C: - asking an empty card-reader drive can hang)
        out += [Path("C:/Riot Games/League of Legends"),
                Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Riot Games" / "League of Legends"]
    elif sys.platform == "darwin":
        out.append(Path("/Applications/League of Legends.app/Contents/LoL"))
    seen, uniq = set(), []
    for p in out:
        k = str(p).lower()
        if k not in seen:
            seen.add(k)
            uniq.append(p)
    return uniq


def read_lockfile(path):
    """lockfile text "LeagueClient:<pid>:<port>:<password>:<protocol>" -> credentials, or None."""
    try:
        parts = Path(path).read_text(encoding="utf-8", errors="replace").strip().split(":")
    except OSError:
        return None
    if len(parts) < 5 or not parts[2].isdigit():
        return None
    return {"port": int(parts[2]), "password": parts[3], "protocol": parts[4] or "https"}


def game_running():
    """Is the game itself running? Asked of Windows' own list of running programs (what Task Manager
    shows): nothing is read from League or the game."""
    if os.name != "nt":
        return False
    try:
        out = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {GAME_EXE}", "/NH"], capture_output=True,
                             text=True, timeout=5, creationflags=NO_WINDOW).stdout
    except (OSError, subprocess.SubprocessError):
        return False
    return GAME_EXE.lower() in out.lower()


def _client_process_running():
    if os.name != "nt":
        return False
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq LeagueClientUx.exe", "/NH"], capture_output=True,
                             text=True, timeout=5, creationflags=NO_WINDOW).stdout
    except (OSError, subprocess.SubprocessError):
        return False
    return "LeagueClientUx.exe" in out


def _from_process():
    """Port + password from the running client's command line (when the lockfile isn't where we look)."""
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             "(Get-CimInstance Win32_Process -Filter \"Name='LeagueClientUx.exe'\").CommandLine"],
            capture_output=True, text=True, timeout=10, creationflags=NO_WINDOW).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    port = re.search(r"--app-port=(\d+)", out)
    token = re.search(r"--remoting-auth-token=([\w-]+)", out)
    if port and token:
        return {"port": int(port.group(1)), "password": token.group(1), "protocol": "https"}
    folder = re.search(r'--install-directory=([^"]+)', out)   # (each argument is in its own quotes)
    return read_lockfile(Path(folder.group(1).strip()) / "lockfile") if folder else None


# ------------------------------------------------------------------ talking to it
class Lcu:
    """GET requests to the League client (one kept-alive connection)."""

    def __init__(self, port, password, protocol="https"):
        self.port, self.protocol = port, protocol
        self.auth = "Basic " + base64.b64encode(f"riot:{password}".encode()).decode()
        self.conn = None

    def _connect(self):
        if self.protocol == "https":
            return http.client.HTTPSConnection("127.0.0.1", self.port, timeout=3, context=_insecure_local_tls())
        return http.client.HTTPConnection("127.0.0.1", self.port, timeout=3)

    def get(self, path):
        """JSON at `path`; None when the client has nothing there (404: no champ select right now).
        Raises PermissionError if the password is refused and OSError when the client is gone."""
        for attempt in (0, 1):
            if self.conn is None:
                self.conn = self._connect()
            try:
                self.conn.request("GET", path, headers={"Authorization": self.auth, "Accept": "application/json"})
                resp = self.conn.getresponse()
                body = resp.read()
            except (OSError, http.client.HTTPException):
                self.close()
                if attempt:
                    raise OSError("League client not answering")
                continue
            if resp.status in (401, 403):
                raise PermissionError("the League client refused the password in its lockfile")
            if resp.status >= 400:
                return None
            try:
                return json.loads(body or b"null")
            except ValueError:
                return None
        return None

    def close(self):
        if self.conn is not None:
            try:
                self.conn.close()
            except OSError:
                pass
        self.conn = None

    def clone(self):
        """A second connection with the same credentials (for look-ups from another thread)."""
        c = Lcu.__new__(Lcu)
        c.port, c.protocol, c.auth, c.conn = self.port, self.protocol, self.auth, None
        return c


def live_game(url=LIVE_URL, timeout=1.5):
    """The running game's data (Live Client Data API), or None when no game is running."""
    u = urlparse(url)
    if u.hostname not in ("127.0.0.1", "localhost"):
        return None   # only ever the game on this PC
    cls = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
    kw = {"context": _insecure_local_tls()} if u.scheme == "https" else {}
    conn = cls("127.0.0.1", u.port or 2999, timeout=timeout, **kw)
    try:
        conn.request("GET", "/liveclientdata/allgamedata", headers={"Accept": "application/json"})
        resp = conn.getresponse()
        body = resp.read()
        return json.loads(body) if resp.status == 200 else None
    except (OSError, http.client.HTTPException, ValueError):
        return None
    finally:
        conn.close()


# ------------------------------------------------------------------ match history (no Riot key needed)
# The client keeps your recent games and can open anyone's profile, so while it's open it can answer
# the Players page without a Riot API key. Read-only GETs: one list per 20 games, one per game.
HISTORY_QUEUES = {"ranked": (420,), "flex": (440,), "draft": (400,), "all": (400, 420, 430, 440, 480, 490, 700)}
HISTORY_NAMES = {"ranked": "Ranked Solo/Duo", "flex": "Ranked Flex", "draft": "Normal Draft", "all": "Summoner's Rift"}
SUPPORT_ITEMS = {3850, 3851, 3853, 3854, 3855, 3857, 3858, 3859, 3860, 3862, 3863, 3864, 3865, 3866, 3867,
                 3869, 3870, 3871, 3876, 3877}
SMITE = 11
ROLES5 = ("TOP", "JNG", "MID", "BOT", "SUP")
_GAMES = {}          # gameId -> the client's details (a finished game never changes)
_GAMES_MAX = 500
_GAMES_LOCK = threading.Lock()


def _q(s):
    from urllib.parse import quote
    return quote(str(s), safe="")


def _name_of(d):
    d = d if isinstance(d, dict) else {}
    gn, tl = d.get("gameName"), d.get("tagLine")
    return f"{gn}#{tl}" if gn and tl else (d.get("displayName") or d.get("summonerName") or "")


def client_account(lcu, riot_id=None):
    """The signed-in account (riot_id empty or yours), or another one by Riot ID through the client's
    own look-up: {"puuid", "name", "me", "summonerId", "accountId"}; None when the client can't find it."""
    me = lcu.get("/lol-summoner/v1/current-summoner") or {}
    mine = _name_of(me)
    you = {"puuid": me.get("puuid"), "name": mine, "me": True, "summonerId": me.get("summonerId"),
           "accountId": me.get("accountId")} if me.get("puuid") else None
    if not riot_id:
        return you
    gn, sep, tl = riot_id.strip().rpartition("#")
    gn, tl = gn.strip(), tl.strip()
    if not sep or not gn or not tl:
        raise ValueError("Enter a Riot ID as Name#TAG (the tag is the part after # on the profile).")
    for path in (f"/lol-summoner/v1/alias/lookup?gameName={_q(gn)}&tagLine={_q(tl)}",
                 f"/lol-summoner/v1/summoners?name={_q(gn + '#' + tl)}",
                 f"/player-account/aliases/v1/lookup?gameName={_q(gn)}&tagLine={_q(tl)}"):
        r = lcu.get(path)
        if isinstance(r, list):
            r = r[0] if r else None
        if isinstance(r, dict) and r.get("puuid"):
            nm = _name_of(r) if r.get("gameName") else _name_of(r.get("alias"))
            return {"puuid": r["puuid"], "name": nm if "#" in nm else f"{gn}#{tl}", "me": r["puuid"] == me.get("puuid"),
                    "summonerId": r.get("summonerId"), "accountId": r.get("accountId"), "via": path.split("?")[0]}
    return you if you and f"{gn}#{tl}".lower() == mine.lower() else None


def client_history(lcu, acc, queue="ranked", count=20, pages=5):
    """The account's recent games in `queue` from the client's match history, newest first (summaries)."""
    want = HISTORY_QUEUES.get(queue, HISTORY_QUEUES["ranked"])
    paths = [f"/lol-match-history/v1/products/lol/{_q(acc['puuid'])}/matches"]
    if acc.get("me"):
        paths.append("/lol-match-history/v1/products/lol/current-summoner/matches")
    seen, games = set(), []
    for base in paths:
        for page in range(pages):
            lst = lcu.get(f"{base}?begIndex={page * 20}&endIndex={page * 20 + 19}")
            chunk = ((lst or {}).get("games") or {}).get("games") if isinstance(lst, dict) else None
            new = [g for g in chunk or [] if g.get("gameId") not in seen]
            for g in new:
                seen.add(g.get("gameId"))
            games += new
            if not new or len(chunk) < 20 or sum(1 for g in games if g.get("queueId") in want) >= count:
                break
        if games:
            break
    games = [g for g in games if g.get("queueId") in want]
    games.sort(key=lambda g: g.get("gameCreation") or 0, reverse=True)
    return games[:count]


def client_game(lcu, game_id):
    """One game with all ten players (the history list only carries the player themself)."""
    if game_id in _GAMES:
        return _GAMES[game_id]
    try:
        g = lcu.get(f"/lol-match-history/v1/games/{int(game_id)}")
    except (TypeError, ValueError):
        return None
    if isinstance(g, dict) and len(g.get("participants") or []) == 10:
        with _GAMES_LOCK:
            if len(_GAMES) >= _GAMES_MAX:
                _GAMES.pop(next(iter(_GAMES)))
            _GAMES[game_id] = g
        return g
    return None


def _prefetch(lcu, ids, workers=4):
    """Fetch several games at once (each worker on its own connection): ~4x faster than one by one."""
    todo = [i for i in ids if i not in _GAMES]
    n = min(workers, len(todo))
    if n <= 1:
        return

    def run(chunk):
        c = lcu.clone()
        try:
            for gid in chunk:
                try:
                    client_game(c, gid)
                except (OSError, PermissionError):
                    return
        finally:
            c.close()

    threads = [threading.Thread(target=run, args=(todo[k::n],), daemon=True) for k in range(n)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=60)


def _hint(p):
    """(role, how sure) from what the client records about a player's game."""
    st = p.get("stats") or {}
    pos = str(p.get("teamPosition") or st.get("teamPosition") or p.get("individualPosition") or "").upper()
    if pos in LIVE_POSITION:
        return LIVE_POSITION[pos], 3.0
    tl = p.get("timeline") or {}
    lane, role = str(tl.get("lane") or "").upper(), str(tl.get("role") or "").upper()
    items = {st.get(f"item{i}") for i in range(7)}
    if SMITE in (p.get("spell1Id"), p.get("spell2Id")):
        return "JNG", 2.5
    if items & SUPPORT_ITEMS or role == "DUO_SUPPORT":
        return "SUP", 2.0
    if lane in ("MIDDLE", "MID"):
        return "MID", 1.5
    if lane == "TOP":
        return "TOP", 1.5
    if lane == "JUNGLE":
        return "JNG", 1.5
    if lane in ("BOTTOM", "BOT") or role == "DUO_CARRY":
        return "BOT", 1.0
    return None, 0.0


def _team_roles(team, champ_name, role_prob=None):
    """participantId -> role for one team: the client's hints, settled by the champions' usual roles."""
    import itertools
    import math
    hints = [_hint(p) for p in team]
    names = [champ_name(p.get("championId")) for p in team]
    best, best_s = None, -1e18
    for perm in itertools.permutations(ROLES5, len(team)):
        s = 0.0
        for (h, sure), nm, r in zip(hints, names, perm):
            if h == r:
                s += sure
            p = role_prob(nm, r) if (role_prob and nm) else 0.2
            s += 0.6 * math.log(max(p, 0.003))
        if s > best_s:
            best_s, best = s, perm
    return {p.get("participantId"): r for p, r in zip(team, best or ())}


def client_record(g, acc, champ_name, role_prob=None):
    """One game from the client -> the Players page's game record (as riotapi.to_games), or None."""
    parts = g.get("participants") or []
    ids = {pi.get("participantId"): (pi.get("player") or {}) for pi in g.get("participantIdentities") or []}

    def is_me(p):
        pl = ids.get(p.get("participantId")) or {}
        if pl.get("puuid") and acc.get("puuid"):
            return pl["puuid"] == acc["puuid"]
        for k, ak in (("summonerId", "summonerId"), ("accountId", "accountId"), ("currentAccountId", "accountId")):
            if pl.get(k) and acc.get(ak) and str(pl[k]) == str(acc[ak]):
                return True
        nm = _name_of(pl)
        return bool(nm) and nm.lower() in (acc["name"].lower(), acc["name"].split("#")[0].lower())

    me = next((p for p in parts if is_me(p)), None)
    if me is None or len(parts) != 10:
        return None
    st = me.get("stats") or {}
    dur = float(g.get("gameDuration") or 0)
    if dur > 20000:
        dur /= 1000.0
    if dur < 600 or st.get("gameEndedInEarlySurrender"):
        return None
    team = me.get("teamId")
    mates = [p for p in parts if p.get("teamId") == team]
    foes = [p for p in parts if p.get("teamId") != team]
    if len(mates) != 5 or len(foes) != 5:
        return None
    roles_m, roles_f = _team_roles(mates, champ_name, role_prob), _team_roles(foes, champ_name, role_prob)
    role = roles_m.get(me.get("participantId"))
    opp = next((p for p in foes if roles_f.get(p.get("participantId")) == role), None)
    created = g.get("gameCreation") or 0
    day = time.strftime("%Y-%m-%d", time.gmtime(created / 1000)) if created else "1970-01-01"
    s = lambda p, k: (p.get("stats") or {}).get(k) or 0   # noqa: E731
    cname = lambda p: champ_name(p.get("championId")) or "?"   # noqa: E731
    return {"id": f"client-{g.get('gameId')}", "date": day, "year": int(day[:4]),
            "event": QUEUES.get(g.get("queueId"), "Game"), "team": "your team",
            "opp": f"vs {cname(opp)}" if opp else "", "role": role, "champ": cname(me),
            "win": 1 if st.get("win") else 0, "k": s(me, "kills"), "d": s(me, "deaths"), "a": s(me, "assists"),
            "gold": s(me, "goldEarned"), "dmg": s(me, "totalDamageDealtToChampions"),
            "cs": s(me, "totalMinionsKilled") + s(me, "neutralMinionsKilled"), "length": dur / 60.0,
            "team_kills": sum(s(p, "kills") for p in mates), "team_gold": sum(s(p, "goldEarned") for p in mates),
            "team_dmg": sum(s(p, "totalDamageDealtToChampions") for p in mates),
            "team_champs": [cname(p) for p in mates], "enemy_champs": [cname(p) for p in foes]}


def client_rank(lcu, puuid):
    """{"ranked": "Silver II · 45 LP", "flex": ...} from the client; {} when it won't say."""
    try:
        r = lcu.get(f"/lol-ranked/v1/ranked-stats/{_q(puuid)}") or {}
    except PermissionError:
        return {}
    entries = dict((r.get("queueMap") or {})) if isinstance(r, dict) else {}
    for e in (r.get("queues") or []) if isinstance(r, dict) else []:
        entries.setdefault(e.get("queueType"), e)
    out = {}
    for key, q in (("RANKED_SOLO_5x5", "ranked"), ("RANKED_FLEX_SR", "flex")):
        e = entries.get(key) or {}
        tier = str(e.get("tier") or "").upper()
        if tier and tier != "NONE":
            div = str(e.get("division") or "")
            div = "" if tier in ("MASTER", "GRANDMASTER", "CHALLENGER") or div in ("", "NA") else f" {div}"
            out[q] = f"{tier.title()}{div} · {e.get('leaguePoints', 0)} LP"
    return out


def client_lookup(lcu, champ_name, riot_id=None, queue="ranked", count=20, role_prob=None):
    """Everything a Players-page look-up needs from the client: (account, game records, rank)."""
    acc = client_account(lcu, riot_id)
    if not acc:
        raise LookupError(f"Your League client couldn't find {riot_id}: check the spelling and the tag after #."
                          if riot_id else "Your League client isn't signed in yet.")
    recs = []
    hist = client_history(lcu, acc, queue, count)
    _prefetch(lcu, [g.get("gameId") for g in hist])
    for g in hist:
        full = client_game(lcu, g.get("gameId"))
        rec = client_record(full, acc, champ_name, role_prob) if full else None
        if rec:
            recs.append(rec)
    return acc, recs, client_rank(lcu, acc["puuid"])


# ------------------------------------------------------------------ champ select -> the draft board
def parse_champ_select(s, champ_name):
    """The client's champ select session -> what the draft board needs: your side and slot, bans,
    locked picks per side (in pick order), hovers, whose turn it is and the timer.
    champ_name(id) -> champion name or None."""
    name = lambda cid: champ_name(cid) if cid else None
    me_cell = s.get("localPlayerCellId")
    ally = sorted(s.get("myTeam") or [], key=lambda p: p.get("cellId", 0))
    enemy = sorted(s.get("theirTeam") or [], key=lambda p: p.get("cellId", 0))
    team_no = next((p.get("team") for p in ally if p.get("team") in (1, 2)), None)
    if team_no is None:
        team_no = 1 if (me_cell if isinstance(me_cell, int) else 0) < 5 else 2
    us = "B" if team_no == 1 else "R"
    them = "R" if us == "B" else "B"
    cell_side = {p.get("cellId"): (us, i + 1) for i, p in enumerate(ally)}
    cell_side.update({p.get("cellId"): (them, i + 1) for i, p in enumerate(enemy)})

    actions = [a for group in (s.get("actions") or []) for a in (group or [])]
    pick_act = {}
    for a in actions:
        if a.get("type") == "pick":
            pick_act[a.get("actorCellId")] = a   # (the last pick action per player)
    live = [a for a in actions if a.get("isInProgress") and not a.get("completed") and a.get("type") in ("ban", "pick")]

    def side_picks(team, is_ally):
        out = []
        for i, p in enumerate(team):
            act = pick_act.get(p.get("cellId"))
            cid = p.get("championId") or (act.get("championId") if act else 0) or 0
            locked = bool(act.get("completed")) if act else bool(cid)
            hover = None
            if not locked:
                hid = (act.get("championId") if act else 0) or (p.get("championPickIntent") if is_ally else 0) or 0
                hover = name(hid)
            out.append({"slot": i + 1, "champ": name(cid) if locked else None, "hover": hover,
                        "role": POSITION.get(str(p.get("assignedPosition") or "").lower()),
                        "me": p.get("cellId") == me_cell,
                        "picking": any(a.get("actorCellId") == p.get("cellId") and a.get("type") == "pick" for a in live)})
        return out

    picks = {us: side_picks(ally, True), them: side_picks(enemy, False)}

    bans = {"B": [], "R": []}
    for a in actions:   # completed bans, in order (the enemy's show once the client reveals them)
        if a.get("type") == "ban" and a.get("completed") and a.get("championId"):
            side = (cell_side.get(a.get("actorCellId")) or (us if a.get("isAllyAction") else them, 0))[0]
            c = name(a["championId"])
            if c and c not in bans[side]:
                bans[side].append(c)
    b = s.get("bans") or {}
    for side, ids in ((us, b.get("myTeamBans") or []), (them, b.get("theirTeamBans") or [])):
        for cid in ids:
            c = name(cid)
            if c and c not in bans[side]:
                bans[side].append(c)

    timer = s.get("timer") or {}
    tphase = timer.get("phase") or ""
    kinds = {a.get("type") for a in live}
    stage = {"PLANNING": "planning", "FINALIZATION": "finalization", "GAME_STARTING": "starting"}.get(
        tphase, "bans" if "ban" in kinds else "picks" if "pick" in kinds or tphase == "BAN_PICK" else "waiting")

    turn = None
    if live:
        kind = "ban" if "ban" in kinds else "pick"
        cur = [a for a in live if a.get("type") == kind]
        sides = {}
        for a in cur:
            side, slot = cell_side.get(a.get("actorCellId")) or (us if a.get("isAllyAction") else them, None)
            sides.setdefault(side, []).append(slot)
        turn = {"type": kind, "side": us if us in sides else them, "slots": sides,
                "mine": any(a.get("actorCellId") == me_cell for a in cur)}

    me_row = next((p for p in picks[us] if p["me"]), None)
    my_act_hover = None
    for a in live:
        if a.get("actorCellId") == me_cell and a.get("championId"):
            my_act_hover = name(a["championId"])
    me = {"slot": me_row["slot"] if me_row else None, "role": me_row["role"] if me_row else None,
          "champ": me_row["champ"] if me_row else None, "hover": my_act_hover or (me_row or {}).get("hover")}

    left, total, now = timer.get("adjustedTimeLeftInPhase"), timer.get("totalTimeInPhase"), timer.get("internalNowInEpochMs")
    deadline = None
    if isinstance(left, (int, float)) and left > 0 and not timer.get("isInfinite"):
        deadline = int((now if isinstance(now, (int, float)) and now > 0 else time.time() * 1000) + left)

    members = sorted(str(p.get("puuid") or p.get("summonerId") or p.get("cellId")) for p in ally)
    key = f"{s.get('gameId') or 0}-" + hashlib.sha1(("|".join(members) + f"|{me_cell}").encode()).hexdigest()[:10]
    return {"key": key, "side": us, "me": me, "stage": stage, "turn": turn, "bans": bans, "picks": picks,
            "timer": {"phase": tphase, "deadline": deadline, "total_ms": total if isinstance(total, (int, float)) else None},
            "draft": any(a.get("type") == "ban" for a in actions) and not s.get("hasSimultaneousPicks"),
            "unknown": sorted({str(c) for c in _all_ids(s) if c and not champ_name(c)})}


def _all_ids(s):
    for p in (s.get("myTeam") or []) + (s.get("theirTeam") or []):
        yield p.get("championId")
    for g in s.get("actions") or []:
        for a in g or []:
            if a.get("completed"):
                yield a.get("championId")


# ------------------------------------------------------------------ the running game -> the live card
def parse_live(d, item_gold, by_dd_id=None):
    """Live Client Data -> the score the live card uses (Blue minus Red, like acp.gamestate.snapshot):
    gold (from the items each team has bought: the API doesn't show the enemy's gold), kills, towers,
    dragons, soul, elder/baron buffs, grubs, herald, barons, inhibitors; plus the 10 champions by role."""
    gd = d.get("gameData") or {}
    t = float(gd.get("gameTime") or 0)
    sign = {"ORDER": 1, "CHAOS": -1}
    team_of, champ_of, kills, gold = {}, {}, {"ORDER": 0, "CHAOS": 0}, {"ORDER": 0, "CHAOS": 0}
    champs = {"B": [], "R": []}
    people = []   # the ten Riot IDs, as the game shows them (Tab): for a look-up from the Players page
    for p in d.get("allPlayers") or []:
        tm = p.get("team")
        if tm not in sign:
            continue
        rid = p.get("riotId") or ""
        if "#" not in rid and p.get("riotIdGameName") and p.get("riotIdTagLine"):
            rid = f"{p['riotIdGameName']}#{p['riotIdTagLine']}"
        raw = str(p.get("rawChampionName") or "").rsplit("_", 1)[-1]   # "game_character_displayname_MonkeyKing"
        champ = (by_dd_id or {}).get(raw) or p.get("championName")       # (championName is in the client's language)
        for nm in (p.get("summonerName"), p.get("riotIdGameName"), rid, rid.split("#")[0]):
            if nm:
                team_of[nm] = tm
                champ_of[nm] = champ
        kills[tm] += int((p.get("scores") or {}).get("kills") or 0)
        for it in p.get("items") or []:
            if it.get("consumable"):
                continue
            g = item_gold.get(str(it.get("itemID")))
            gold[tm] += (g if g is not None else int(it.get("price") or 0)) * max(1, int(it.get("count") or 1))
        champs["B" if tm == "ORDER" else "R"].append({"champ": champ,
                                                      "role": LIVE_POSITION.get(str(p.get("position") or "").upper())})
        sc = p.get("scores") or {}
        people.append({"riot_id": rid or p.get("summonerName") or "", "champ": champ, "side": "B" if tm == "ORDER" else "R",
                       "role": LIVE_POSITION.get(str(p.get("position") or "").upper()), "level": p.get("level"),
                       "k": sc.get("kills") or 0, "d": sc.get("deaths") or 0, "a": sc.get("assists") or 0,
                       "cs": sc.get("creepScore") or 0})
    f = {k: 0.0 for k in ("gold", "kills", "towers", "dragons", "soul", "elder", "grubs", "herald",
                          "baron", "barons", "inhibs", "atakhan")}
    dragons = {"ORDER": 0, "CHAOS": 0}
    soul = None
    for e in (d.get("events") or {}).get("Events") or []:
        ev, et = e.get("EventName"), float(e.get("EventTime") or 0)
        side = team_of.get(e.get("KillerName") or "")
        s = sign.get(side, 0)
        if ev == "TurretKilled":
            lost = "ORDER" if "_T1_" in (e.get("TurretKilled") or "") else "CHAOS" if "_T2_" in (e.get("TurretKilled") or "") else None
            if lost:
                f["towers"] -= sign[lost]   # a Red turret down = +1 for Blue
        elif ev == "InhibKilled":
            lost = "ORDER" if "_T1_" in (e.get("InhibKilled") or "") else "CHAOS" if "_T2_" in (e.get("InhibKilled") or "") else None
            if lost:
                f["inhibs"] -= sign[lost]
        elif ev == "DragonKill" and s:
            if str(e.get("DragonType") or "").lower() == "elder":
                if t - et <= ELDER_BUFF_S:
                    f["elder"] = s
            else:
                f["dragons"] += s
                dragons[side] += 1
                if dragons[side] == 4 and soul is None:
                    soul = side
        elif ev == "BaronKill" and s:
            f["barons"] += s
            if t - et <= BARON_BUFF_S:
                f["baron"] = s
        elif ev == "HeraldKill" and s:
            f["herald"] += s
        elif ev == "HordeKill" and s:   # void grubs
            f["grubs"] += s
        elif ev and "atakhan" in ev.lower() and s:
            f["atakhan"] += s
    f["kills"] = kills["ORDER"] - kills["CHAOS"]
    f["gold"] = round((gold["ORDER"] - gold["CHAOS"]) / 1000.0, 1)
    f["soul"] = sign[soul] if soul else 0
    me_team = me_champ = None
    ap = d.get("activePlayer") or {}
    for nm in (ap.get("riotId"), ap.get("summonerName"), ap.get("riotIdGameName"), (ap.get("riotId") or "").split("#")[0]):
        if nm and nm in team_of:
            me_team = "B" if team_of[nm] == "ORDER" else "R"
            me_champ = champ_of.get(nm)
            break
    me_ids = {x for x in (ap.get("riotId"), ap.get("summonerName"), ap.get("riotIdGameName")) if x}
    for x in people:
        x["me"] = bool(x["riot_id"]) and (x["riot_id"] in me_ids or x["riot_id"].split("#")[0] in me_ids)
    return {"time": round(t), "state": f, "champs": champs, "my_side": me_team, "me": me_champ,
            "mode": gd.get("gameMode"), "map": gd.get("mapNumber"), "players": people}


# ------------------------------------------------------------------ one read of the client -> the page's state
def state_from_raw(raw, by_id, by_dd_id=None, item_gold=None):
    """What the page shows, from one raw read of the client: the League helper's /state (the in-browser
    version, web/league-helper.ps1) has the gameflow phase, your Riot ID, the queue, the matchmaking
    search, the champ select session and the live game data as the client gives them. Same shape as
    ClientWatcher's state (status, phase, account, queue, queue_since, ready, champ_select, game)."""
    if not isinstance(raw, dict) or not raw.get("client"):
        return {"status": "off"}
    if raw.get("paused"):   # your game is on and the helper reads nothing until it closes
        st = {"status": "on", "phase": "InProgress", "paused": True}
        me = raw.get("summoner") if isinstance(raw.get("summoner"), dict) else {}
        account = f"{me.get('gameName')}#{me.get('tagLine')}" if me.get("gameName") else me.get("displayName")
        if account:
            st["account"] = account
        return st
    phase = raw.get("phase") if isinstance(raw.get("phase"), str) and raw.get("phase") else "None"
    st = {"status": "on", "phase": phase}
    me = raw.get("summoner") if isinstance(raw.get("summoner"), dict) else {}
    account = f"{me.get('gameName')}#{me.get('tagLine')}" if me.get("gameName") else me.get("displayName")
    if account:
        st["account"] = account
    q = raw.get("queue") if isinstance(raw.get("queue"), dict) else {}
    if phase != "None" and q:
        qid = q.get("id")
        st["queue"] = {"id": qid, "name": QUEUES.get(qid) or q.get("description") or q.get("shortName") or "",
                       "ranked": bool(q.get("isRanked"))}
    search = raw.get("search") if isinstance(raw.get("search"), dict) else {}
    if phase == "Matchmaking":
        t = search.get("timeInQueue")
        st["queue_since"] = int(time.time() * 1000 - t * 1000) if isinstance(t, (int, float)) else None
        est = search.get("estimatedQueueTime")
        st["queue_estimate"] = round(est) if isinstance(est, (int, float)) else None
    elif phase == "ReadyCheck":
        st["ready"] = ((search.get("readyCheck") or {}).get("playerResponse")) or "None"
    elif phase == "ChampSelect" and isinstance(raw.get("champ_select"), dict):
        st["champ_select"] = parse_champ_select(raw["champ_select"], (by_id or {}).get)
    elif phase in ("GameStart", "InProgress", "Reconnect") and isinstance(raw.get("live"), dict):
        st["game"] = parse_live(raw["live"], item_gold or {}, by_dd_id)
    return st


# ------------------------------------------------------------------ the watcher
class ClientWatcher(threading.Thread):
    """Follows the League client in the background. snapshot() is what the web page shows; wait(v)
    blocks until something changes (the page long-polls it), so picks appear the moment they lock."""

    def __init__(self, champions, items, item_ids, lockfile=None, live_url=None, quiet=None):
        super().__init__(daemon=True, name="league-client")
        self.quiet = quiet          # () -> True: read nothing at all while your game runs (the setting "quietInGame")
        self._paused = False
        self.by_id = {int(c["key"]): name for name, c in champions.items() if str(c.get("key") or "").isdigit()}
        self.by_dd_id = {c["id"]: name for name, c in champions.items() if c.get("id")}
        self.item_gold = {iid: items[n]["gold"] for iid, n in item_ids.items() if n in items}
        self.lockfile = Path(lockfile) if lockfile else None
        self.live_url = live_url or LIVE_URL
        self.cond = threading.Condition()
        self.v = 0
        self.state = {"status": "off"}
        self.lcu = None
        self._next_find = 0.0
        self._next_scan = 0.0
        self._dirs, self._dirs_at = [], 0.0
        self._phase = None
        self._queue = None
        self._queue_since = None
        self._me = None

    # -- what the page sees
    def snapshot(self):
        with self.cond:
            return dict(self.state, v=self.v)

    def wait(self, v, timeout=20.0):
        with self.cond:
            self.cond.wait_for(lambda: self.v != v, timeout)
            return dict(self.state, v=self.v)

    def _publish(self, state):
        with self.cond:
            if state != self.state:
                self.state = state
                self.v += 1
                self.cond.notify_all()

    def poke(self):
        """Wake the open pages without a client change (a phone connected, a shared setting changed)."""
        with self.cond:
            self.v += 1
            self.cond.notify_all()

    def lookup_lcu(self):
        """A separate connection to the client for a look-up (the watcher's own stays its own), or None."""
        lcu = self.lcu
        return lcu.clone() if lcu is not None else None

    # -- finding the client
    def _credentials(self):
        now = time.monotonic()
        if now < self._next_find:
            return None
        self._next_find = now + 2.0
        if not self.lockfile and now >= self._dirs_at:
            self._dirs, self._dirs_at = install_dirs(), now + 30.0
        paths = [self.lockfile] if self.lockfile else [d / "lockfile" for d in self._dirs]
        for p in paths:
            if p and p.exists():
                cred = read_lockfile(p)
                if cred:
                    return cred
        if self.lockfile or os.name != "nt" or now < self._next_scan:
            return None
        self._next_scan = now + 15.0   # the slower look: ask Windows for the client's command line
        return _from_process() if _client_process_running() else None

    # -- the loop
    def run(self):
        while True:
            try:
                delay = self._tick()
            except Exception as exc:  # noqa: BLE001 - never let the watcher die
                self._drop()
                self._publish({"status": "error", "error": f"{type(exc).__name__}: {exc}"})
                delay = 5.0
            time.sleep(delay)

    def _drop(self):
        if self.lcu:
            self.lcu.close()
        self.lcu = None
        self._phase = self._queue = self._queue_since = self._me = None

    def _tick(self):
        if self.lcu is None:
            cred = self._credentials()
            if not cred:
                self._publish({"status": "off"})
                return 2.0
            self.lcu = Lcu(cred["port"], cred["password"], cred.get("protocol") or "https")
        quiet = bool(self.quiet()) if self.quiet else False
        if quiet and (self._paused or self._phase in IN_GAME):
            if game_running():   # your game is on: nothing is read from League or the game until it closes
                self._paused = True
                st = {"status": "on", "phase": "InProgress", "paused": True}
                if self._me:
                    st["account"] = self._me
                if self._queue:
                    st["queue"] = self._queue
                self._publish(st)
                return 5.0
            if self._paused:   # the game closed: follow the client again
                self._paused = False
                self._phase = None
        try:
            phase = self.lcu.get("/lol-gameflow/v1/gameflow-phase")
        except PermissionError as exc:
            self._drop()
            self._publish({"status": "error", "error": str(exc)})
            return 5.0
        except OSError:
            self._drop()
            self._publish({"status": "off"})
            return 1.0
        phase = phase if isinstance(phase, str) else "None"
        if phase != self._phase:   # new phase: look up the queue again, restart the queue timer
            self._phase = phase
            self._queue = None
            if phase != "Matchmaking":
                self._queue_since = None
        st = {"status": "on", "phase": phase}
        if not self._me:   # (asked again until you're signed in)
            me = self.lcu.get("/lol-summoner/v1/current-summoner") or {}
            self._me = f"{me.get('gameName')}#{me.get('tagLine')}" if me.get("gameName") else me.get("displayName")
        if self._me:
            st["account"] = self._me
        if phase not in ("None", "") and self._queue is None:
            q = ((self.lcu.get("/lol-gameflow/v1/session") or {}).get("gameData") or {}).get("queue") or {}
            qid = q.get("id")
            self._queue = {"id": qid, "name": QUEUES.get(qid) or q.get("description") or q.get("shortName") or "",
                           "ranked": bool(q.get("isRanked"))}
        if self._queue:
            st["queue"] = self._queue
        delay = 2.0
        if phase == "Matchmaking":
            srch = self.lcu.get("/lol-matchmaking/v1/search") or {}
            if self._queue_since is None and isinstance(srch.get("timeInQueue"), (int, float)):
                self._queue_since = int(time.time() * 1000 - srch["timeInQueue"] * 1000)
            st["queue_since"] = self._queue_since
            est = srch.get("estimatedQueueTime")
            st["queue_estimate"] = round(est) if isinstance(est, (int, float)) else None
            delay = 0.5   # (so "match found" shows the moment it pops)
        elif phase == "ReadyCheck":
            srch = self.lcu.get("/lol-matchmaking/v1/search") or {}
            st["ready"] = ((srch.get("readyCheck") or {}).get("playerResponse")) or "None"
            delay = 0.5
        elif phase == "ChampSelect":
            sess = self.lcu.get("/lol-champ-select/v1/session")
            if sess:
                st["champ_select"] = parse_champ_select(sess, self.by_id.get)
            delay = 0.35
        elif phase in IN_GAME:
            if not quiet:   # (quiet: the game isn't read; the next look checks whether it's running yet)
                d = live_game(self.live_url)
                if d:
                    st["game"] = parse_live(d, self.item_gold, self.by_dd_id)
            delay = 2.0
        self._publish(st)
        return delay


class Quiet:
    """Stands in for ClientWatcher when following the client is switched off (serve.py --no-client):
    the page's long poll still waits instead of asking again at once, and can still be woken."""

    def __init__(self):
        self.cond = threading.Condition()
        self.v = 0

    def snapshot(self):
        return {"status": "disabled", "v": self.v}

    def lookup_lcu(self):
        return None

    def wait(self, v, timeout=20.0):
        with self.cond:
            self.cond.wait_for(lambda: self.v != v, timeout)
            return {"status": "disabled", "v": self.v}

    def poke(self):
        with self.cond:
            self.v += 1
            self.cond.notify_all()
