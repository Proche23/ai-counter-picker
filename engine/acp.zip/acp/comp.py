"""Game-plan writer: turns two compositions into a named win condition,
a phase-by-phase plan, and clear win / lose conditions.

Identity comes from knowledge-base archetype scores normalised against every
pro composition in the data (z-scores); tempo and lane priority lean on pro
results (game-length win rates, head-to-head records); power spikes (and the minute
they land, from Riot timelines) come from the pro item builds.
"""
import re

from . import ROLES
from .kb import ARCHETYPES, ARCHETYPE_LABEL, DAMAGE_WEIGHT, curve_sum, damage_profile, profile

NOUN = {"engage": "Blitz", "teamfight": "Clash", "pick": "Ambush", "poke": "Siege",
        "split": "Split", "protect": "Escort", "skirmish": "Brawl"}


def ult_name(champ, dd):
    spells = (dd.get(champ) or {}).get("spells") or []
    name = spells[3] if len(spells) >= 4 else champ
    if not name:
        return champ or "Team"
    name = re.sub(r"^(Command|Transform|Ultimate)\s*:\s*", "", name)
    name = re.sub(r"^The\s+", "", name)
    return name.strip(" !.") or champ


def _join(names):
    names = [n for n in names if n]
    if not names:
        return ""
    if len(names) == 1:
        return names[0]
    return ", ".join(names[:-1]) + " and " + names[-1]


class Team:
    """Who does what inside one composition."""

    def __init__(self, roles, stats, dd):
        self.roles = dict(roles)                     # role -> champion
        self.champs = list(self.roles.values())
        self.dd = dd
        self.p = {c: profile(c, dd) for c in self.champs}
        self.z = stats.arch_z(self.champs) if self.champs else {a: 0.0 for a in ARCHETYPES}
        ranked = sorted(self.z, key=self.z.get, reverse=True)
        self.identity, self.secondary = (ranked + ["teamfight", "engage"])[:2]
        self.curve = curve_sum(self.champs, dd) if self.champs else (0, 0, 0)
        self.n = max(1, len(self.champs))
        self.dmg = damage_profile(self.champs, dd) if self.champs else {"AD": 0.5, "AP": 0.5}

    def best(self, trait, minimum=2, exclude=()):
        pool = [(self.p[c]["traits"][trait], c) for c in self.champs if c not in exclude]
        pool = [x for x in pool if x[0] >= minimum]
        return max(pool)[1] if pool else None

    def all_with(self, trait, minimum=2, exclude=()):
        return [c for c in self.champs if self.p[c]["traits"][trait] >= minimum and c not in exclude]

    @property
    def carry(self):
        if not self.champs:
            return None

        def carry_score(c):
            pr = self.p[c]
            role_bonus = 1.0 if self.role_of(c) in ("BOT", "MID") else 0.0
            return DAMAGE_WEIGHT.get(pr["class"], 0.8) * (1 + pr["traits"]["hc"] + 0.5 * pr["traits"]["bu"]
                                                          + 0.3 * pr["curve"][2]) + role_bonus
        return max(self.champs, key=carry_score)

    def role_of(self, c):
        for r, cc in self.roles.items():
            if cc == c:
                return r
        return None

    def key_for(self, arch):
        if not self.champs:
            return None
        if arch == "protect":
            return self.carry
        if arch == "split":
            return max(self.champs, key=lambda c: (self.p[c]["traits"]["sp"] * 2 + self.p[c]["traits"]["sk"]))
        w = ARCHETYPES[arch]
        return max(self.champs, key=lambda c: sum(v * self.p[c]["traits"][t] for t, v in w.items()))

    def per5(self, i):
        return self.curve[i] * 5.0 / self.n


def win_con_name(team, dd):
    key = team.key_for(team.identity)
    return f"The {ult_name(key, dd)} {NOUN[team.identity]}", key


# the measurable version of each style's win condition, as tested by the lab (insights.SIGNATURES)
STYLE_TEST = {"engage": "obj_fights", "teamfight": "obj_fights", "pick": "picks_before_obj", "poke": "towers20",
              "split": "side_towers", "protect": "length", "skirmish": "kills15"}


class Planner:
    def __init__(self, stats, builds, dd, conditions=None):
        self.s = stats
        self.b = builds
        self.dd = dd
        self.c = conditions or {}

    def _tested(self, us, tempo):
        """Short lines with what the lab measured in real pro games for comps like this one."""
        c = self.c
        if not c:
            return []
        out = []
        tl = (c.get("tempo_by_length") or {}).get(tempo) or {}
        s, l = tl.get("short"), tl.get("long")
        if tempo in ("early", "late") and s and l:
            n = s[1] + l[1]
            if tempo == "early":
                out.append(f"Earlier comps won {s[0]:.0%} of pro games that ended before 28 min and {l[0]:.0%} of "
                           f"games that went past 35 ({n:,} games).")
            else:
                out.append(f"Later-scaling comps won {l[0]:.0%} of pro games that went past 35 min and {s[0]:.0%} of "
                           f"games that ended before 28 ({n:,} games).")
        key = STYLE_TEST.get(us.identity)
        sig = next((x for x in (c.get("signatures") or {}).get(us.identity, []) if x["key"] == key), None)
        if sig and sig.get("win_done") and sig.get("win_not"):
            out.append(f"{ARCHETYPE_LABEL[us.identity]} comps that {sig['condition']} won {sig['win_done'][0]:.0%} "
                       f"of the time; when they didn't, {sig['win_not'][0]:.0%} ({sig['win_done'][1] + sig['win_not'][1]:,} games).")
        b15 = (c.get("behind15") or {}).get(tempo)
        if b15 and b15[1] >= 40:
            out.append(f"Comps like this that were 1,500+ gold behind at 15 min came back {b15[0]:.0%} of the time "
                       f"({b15[1]:,} games).")
        paths = (c.get("paths_by_tempo") or {}).get(tempo) or {}
        top2 = sorted(((p, v) for p, v in paths.items() if p != "games"), key=lambda kv: -kv[1])[:2]
        if len(top2) == 2:
            out.append(f"When comps like this win, it is most often by: {top2[0][0].lower()} ({top2[0][1]:.0%}) or "
                       f"{top2[1][0].lower()} ({top2[1][1]:.0%}).")
        return out

    def _lane_prio(self, us, them, role):
        c, e = us.roles.get(role), them.roles.get(role)
        if not c or not e:
            return 0.0, None
        early = us.p[c]["curve"][0] - them.p[e]["curve"][0]
        lw = self.s.lane_wl(c, role, e)
        exp = 0.5 + (self.s.champ_long_rate(c) - self.s.champ_long_rate(e))
        resid = lw.rate(prior=exp, k=12) - 0.5
        return early + resid * 20, lw

    def _length_line(self, team):
        short_w = short_g = long_w = long_g = 0.0
        raw = 0
        for c in team.champs:
            lr = self.s.length_rates(c)
            short_w += lr["short"].w
            short_g += lr["short"].g
            long_w += lr["long"].w
            long_g += lr["long"].g
            raw += lr["short"].rg + lr["long"].rg
        if raw < 40 or short_g < 3 or long_g < 3:
            return None, 0.0
        s_rate = (short_w + 5) / (short_g + 10)
        l_rate = (long_w + 5) / (long_g + 10)
        return (s_rate, l_rate), s_rate - l_rate

    def _spike(self, champ, role):
        """(first two finished items, minute the second one lands in pro games or None)."""
        if not champ or not role:
            return None, None
        bd = self.b.for_champ(champ, role)
        if not bd or len(bd.get("path", [])) < 2:
            return None, None
        t = bd["path"][1].get("t")
        return f"{bd['path'][0]['item']} + {bd['path'][1]['item']}", (round(t / 60) if t else None)

    def plan(self, ours, theirs):
        """ours/theirs: {role: champion} (partial drafts are fine)."""
        dd = self.dd
        us, them = Team(ours, self.s, dd), Team(theirs, self.s, dd)
        name, key = win_con_name(us, dd)
        has_enemy = len(them.champs) >= 2

        jng = us.roles.get("JNG")
        carry = us.carry
        carry_role = us.role_of(carry)
        spike, spike_min = self._spike(carry, carry_role)
        at = f", ~{spike_min} min" if spike_min else ""
        eng = us.best("en")
        tf = us.best("tf", 2)
        front = us.best("fl")
        picker = us.best("pk")
        poker = us.best("po")
        poker2 = us.best("po", 2, exclude=(poker,))
        splitter = us.best("sp")
        peelers = us.all_with("pe", 2, exclude=(carry,))
        wavers = us.all_with("wc", 2, exclude=(splitter,))
        e_carry = them.carry if them.champs else None
        e_late = max(them.champs, key=lambda c: them.p[c]["curve"][2]) if them.champs else None

        # ---- tempo -------------------------------------------------------
        n_us, n_them = max(1, len(us.champs)), max(1, len(them.champs))
        if has_enemy:
            k = min(n_us, n_them)
            e_diff = (us.curve[0] / n_us - them.curve[0] / n_them) * k
            l_diff = (us.curve[2] / n_us - them.curve[2] / n_them) * k
        else:  # no enemy comp yet: describe our own lean, make no head-to-head claims
            e_diff = (us.curve[0] / n_us - 3.0) * n_us * 0.5
            l_diff = (us.curve[2] / n_us - 3.5) * n_us * 0.5
        length_rates, length_idx = self._length_line(us)
        e_length_idx = self._length_line(them)[1] if has_enemy else 0.0
        tempo_score = 0.35 * e_diff - 0.35 * l_diff + 30 * (length_idx - e_length_idx)
        tempo = "early" if tempo_score >= 1.0 else ("late" if tempo_score <= -1.0 else "even")

        # ---- lane priority (only from matchups that are actually known) --
        prio = {r: self._lane_prio(us, them, r) for r in ROLES}
        bot_prio = prio["BOT"][0] + prio["SUP"][0]
        top_prio = prio["TOP"][0]
        known_lanes = [r for r in ("TOP", "MID", "BOT", "SUP") if prio[r][1] is not None]

        # ---- story ---------------------------------------------------------
        follow = _join([c for c in us.champs if c not in (eng,) and us.p[c]["traits"]["tf"] + us.p[c]["traits"]["dv"] >= 2][:2])
        stories = {
            "engage": f"You're the team that starts the fights. {eng or key} decides when a fight begins, and with {follow or 'your follow-up'} diving in behind, it's over before {e_carry or 'their carries'} can answer.",
            "teamfight": (f"You win the big 5v5. {front} starts the fight with {ult_name(front, dd)} and soaks the damage, and {carry} cleans up from behind."
                          if front and front == (tf or key) else
                          f"You win the big 5v5. {front or 'Your frontline'} soaks the damage, {tf or key}'s {ult_name(tf or key, dd)} breaks their formation, and {carry} cleans up from behind."),
            "pick": f"You win in the fog. {picker or key} takes one of them off the map before every objective, so every fight is a free 5v4.",
            "poke": f"You win before the fight starts. {_join([poker, poker2]) or key} wear them down from range, so they show up to every objective at half HP.",
            "split": f"You win on the map, not in the 5v5. {splitter or key} is a side-lane problem they need two players to answer, and that frees objectives for your other four.",
            "protect": f"You win through {carry}. The other four exist to keep {carry} alive, and if they do, {carry} out-damages everything late.",
            "skirmish": f"You win by fighting early and often. Take every 2v2 and 3v3 around {jng or 'your jungler'}, snowball the map, and close before their scaling matters.",
        }
        story = stories[us.identity]
        tempo_line = None
        if length_rates:
            s_rate, l_rate = length_rates
            tempo_line = (f"Pro data: these champions win {s_rate:.0%} of games under 28 min "
                          f"and {l_rate:.0%} of games over 35 min.")

        # ---- phases ---------------------------------------------------------
        early = []
        if jng and known_lanes:
            if bot_prio >= max(top_prio, 0.5):
                duo_list = [x for x in (us.roles.get("BOT"), us.roles.get("SUP")) if x]
                duo = _join(duo_list) or "your bot lane"
                verb = "has" if len(duo_list) == 1 else "have"
                early.append(f"{jng} plays bot side. {duo} {verb} 2v2 priority, so the first dragons are yours to take.")
            elif top_prio >= 0.5:
                early.append(f"{jng} starts toward top. {us.roles.get('TOP')} has priority, so take Void Grubs and Herald and trade dragons if you have to.")
            elif not (has_enemy and e_diff >= 2):
                early.append(f"No lane has clear priority, so {jng} tracks their jungler and counter-paths instead of forcing anything.")
        if not has_enemy:
            lean = {"early": "strongest early, so draft the rest to snowball: lane priority and early skirmish power",
                    "late": "strongest late, so draft the rest to survive the early game: safe lanes, waveclear and peel",
                    "even": "built for the mid game, so draft the rest around objective fights from 14-25 min"}[tempo]
            early.append(f"{_join(us.champs)} {'is' if len(us.champs) == 1 else 'are'} {lean}.")
        elif e_diff >= 2:
            early.append("You're the stronger early team: invade, contest every early objective, and force fights before their spikes.")
        elif e_diff <= -2:
            hold = f" until {spike}{f' (~{spike_min} min)' if spike_min else ''}" if spike else ""
            early.append(f"They're stronger early. Ward defensively, give up contested early objectives, and keep {carry} even{hold}.")
        else:
            early.append("The early game is even. Trade objectives on whichever side you have priority and skip coin-flip fights.")

        disengager = (peelers[0] if peelers else None) or front or "your peel"
        mid = {
            "engage": f"Group around objective timers. {eng or key} looks for a {ult_name(eng or key, dd)} flank into tight jungle chokes, and {follow or 'everyone'} must follow instantly.",
            "teamfight": f"Group as five and fight on objectives they must contest. {front or 'Your frontline'} holds the front, {_join(peelers) or 'your support'} {'peel' if len(peelers) > 1 else 'peels'}, and {carry} hits the closest target.",
            "pick": f"Take vision control deep in their jungle. {picker or key} hunts whoever walks into fog, and every catch turns into a tower or objective. Never take a 5v5 without a pick first.",
            "poke": f"Siege, don't brawl. {poker or key} chips them before every objective while you take towers wave by wave. If they dive, {disengager} disengages and you poke again.",
            "split": f"Play 1-3-1. {splitter or key} pushes the side lane opposite the next objective, the other four hold mid with waveclear ({_join(wavers) or 'your mid'}), and you stall until two of them have to answer.",
            "protect": f"Everything is built around {carry}. {_join(peelers) or 'Your support'} stay glued to {carry}, you fight front-to-back, and {carry} free-hits whatever comes closest.",
            "skirmish": f"Keep forcing 2v2s and 3v3s around {jng or 'your jungler'}. Invade with lane priority and turn each win into towers before they hit their spikes.",
        }[us.identity]
        late = {
            "engage": f"Set up Baron and Elder with vision, then start the fight yourselves: {eng or key}'s {ult_name(eng or key, dd)} goes first and everyone follows. Don't sit back and get poked while you wait.",
            "teamfight": f"Win the 5v5 at Soul, Baron or Elder. {tf or key}'s {ult_name(tf or key, dd)} is the fight-winning moment, so don't fight while it's down.",
            "pick": "Never walk into a 5v5 head-on. Set traps in the fog around Baron and Elder and only commit after a catch.",
            "poke": "Siege inhibitors with Baron buff. Poke before every objective and disengage whenever they try to force.",
            "split": f"{splitter or key} keeps the side lanes pushed while four stall. Start Baron the moment they send two to answer.",
            "protect": f"Fight front-to-back at Elder and Baron. {carry} with 4+ items wins long fights as long as the frontline holds.",
            "skirmish": f"Close it out: siege with the gold lead and don't give them late 5v5s at {e_late or 'their scaling'}'s power level.",
        }[us.identity]
        if tempo == "late" and us.identity in ("skirmish", "engage"):
            late += (" If the lead slips, don't flip coins: you scale better, but in pro play a deficit is hard to recover"
                     " even for scaling comps, so trade objectives cross-map and fight on your item spikes.")

        # ---- win conditions --------------------------------------------------
        win = []
        core = {
            "engage": f"Land {eng or key}'s {ult_name(eng or key, dd)} on two or more targets and follow up instantly.",
            "teamfight": (f"Fight front-to-back on objectives: {front} engages with {ult_name(front, dd)} and absorbs, {carry} deals the damage."
                          if front and front == (tf or key) else
                          f"Fight front-to-back on objectives: {front or 'frontline'} absorbs, {tf or key}'s {ult_name(tf or key, dd)} splits them, {carry} deals the damage."),
            "pick": f"Catch one target before every objective with {picker or key}, then take it 5v4.",
            "poke": f"Get them below ~70% HP with {poker or key} before every objective. They can't contest at half HP.",
            "split": f"{splitter or key} wins the side lane 1v1 and draws two players; trade objectives cross-map.",
            "protect": f"Keep {carry} alive and auto-attacking: every fight goes front-to-back around them.",
            "skirmish": f"Win the early 2v2s and 3v3s with {jng or 'your jungler'} and roll the lead into towers.",
        }[us.identity]
        win.append(core)
        if tempo == "early":
            win.append("Build the lead before their scaling kicks in. These champions win more in short pro games, so close by ~30 min.")
        elif tempo == "late":
            win.append(f"Play for the late game: hit {carry}'s 2-item spike{f' ({spike}{at})' if spike else ''} "
                       "and fight for Soul and Baron after 25 min.")
        elif spike:
            win.append(f"{carry}'s 2-item spike ({spike}{at}) is your first real fight window.")
        if bot_prio >= 1.0 and us.roles.get("BOT"):
            win.append("Use bot-lane priority to stack early dragons.")
        elif top_prio >= 1.0 and us.roles.get("TOP"):
            win.append(f"Use {us.roles['TOP']}'s top priority: Void Grubs and Herald turn into early tower plates.")
        if has_enemy and e_carry:
            win.append(f"Focus {e_carry}: most of their damage runs through them.")

        # ---- lose conditions --------------------------------------------------
        lose = []
        their_name = None
        if has_enemy:
            their_name, their_key = win_con_name(them, dd)
            e_eng, e_pick = them.best("en"), them.best("pk")
            e_split, e_poke = them.best("sp"), them.best("po")
            threat = {
                "engage": f"{e_eng or their_key} lands {ult_name(e_eng or their_key, dd)} on your backline first.",
                "teamfight": f"You take a straight 5v5 into {their_key}'s {ult_name(their_key, dd)} without a pick or a flank.",
                "pick": f"You face-check without vision and {e_pick or their_key} catches whoever walks first.",
                "poke": f"{e_poke or their_key} pokes you down before objectives and you hand them over for free.",
                "split": f"{e_split or their_key} gets free side-lane pressure with nobody to match them 1v1.",
                "protect": f"{them.carry} free-hits behind their frontline and peel.",
                "skirmish": f"You lose early skirmishes to {them.roles.get('JNG') or their_key} and fall behind before your spikes.",
            }[them.identity]
            lose.append(f'Their plan, "{their_name}" ({ARCHETYPE_LABEL[them.identity].lower()}): {threat}')
            if tempo == "early" or l_diff <= -2:
                lose.append(f"The game goes past ~35 min: {e_late} out-scales you.")
            elif tempo == "late" or e_diff <= -2:
                e_early = _join(sorted(them.champs, key=lambda c: -them.p[c]["curve"][0])[:2])
                lose.append(f"You bleed early. {e_early} want fights before 20 min, so don't give them free skirmishes before your spikes.")
        # comp gaps: a lose condition once the comp is final, a drafting need before that
        needs = []
        gap_keys = []
        major = "AD" if us.dmg["AD"] >= us.dmg["AP"] else "AP"
        gaps = [
            (not us.all_with("fl", 2), "a frontline",
             f"You have no real frontline. If they dive, nothing stands between them and {carry}."),
            (max(us.dmg["AD"], us.dmg["AP"]) >= 0.8, f"{'magic' if major == 'AD' else 'physical'} damage",
             f"Your damage is {us.dmg[major]:.0%} {major}, so they can stack {'armor' if major == 'AD' else 'magic resist'}."),
            (us.identity in ("teamfight", "protect", "poke") and not us.best("en"), "hard engage",
             "You have no hard engage. If they refuse to fight, you can't force one."),
        ]
        for missing, need, warning in gaps:
            if not missing or len(us.champs) < 3:
                continue
            if len(us.champs) == 5:
                lose.append(warning)
                gap_keys.append(need)
            else:
                needs.append(need)
        bad = [(p, r, lw) for r, (p, lw) in prio.items() if lw is not None and lw.rg >= 3 and p <= -1.0]
        lane_loss = None
        if bad:
            p, r, lw = min(bad, key=lambda x: x[0])
            lane_loss = [r, them.roles[r]]
            where = {"TOP": "top side", "MID": "in mid", "BOT": "bot side", "SUP": "bot side", "JNG": "in the jungle"}[r]
            what = "the jungle matchup" if r == "JNG" else "lane"
            lose.append(f"{us.roles[r]} loses {what} to {them.roles[r]} ({lw.record} in pro play) "
                        f"and they snowball {where}.")

        return {
            "name": name, "key": key, "identity": us.identity, "label": ARCHETYPE_LABEL[us.identity],
            "secondary": ARCHETYPE_LABEL[us.secondary], "story": story, "tempo": tempo,
            "tempo_line": tempo_line, "early": " ".join(early), "mid": mid, "late": late,
            "win": win[:5], "lose": lose[:5], "their_name": their_name,
            "their_label": ARCHETYPE_LABEL[them.identity] if has_enemy else None,
            "carry": carry, "spike": spike, "spike_min": spike_min, "z": us.z,
            "partial": len(us.champs) < 5 or len(them.champs) < 5,
            "needs": needs,
            "tested": self._tested(us, tempo) if has_enemy else [],
            # machine-readable version of the claims above, so the lab can test them against real games
            "tags": {"tempo_score": round(tempo_score, 3), "e_diff": round(e_diff, 3), "l_diff": round(l_diff, 3),
                     "bot_prio": round(bot_prio, 3), "top_prio": round(top_prio, 3),
                     "lane_loss": lane_loss, "gaps": gap_keys},
        }
