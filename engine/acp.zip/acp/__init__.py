"""AI Counter Picker: pro-play (LCK / LPL / internationals) draft engine."""
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
RAW = DATA / "raw"
RAW_REGIONS = DATA / "raw_regions"   # other regions' leagues (LEC, LCS, ...): see regions.py
DD_DIR = DATA / "ddragon"
DB_PATH = DATA / "pro.db"

ROLES = ["TOP", "JNG", "MID", "BOT", "SUP"]
ROLE_NAMES = {"TOP": "Top", "JNG": "Jungle", "MID": "Mid", "BOT": "Bot", "SUP": "Support"}


def load_config():
    with open(ROOT / "config.json", encoding="utf-8") as f:
        return json.load(f)


def ensure_dirs():
    for d in (DATA, RAW, DD_DIR):
        os.makedirs(d, exist_ok=True)
