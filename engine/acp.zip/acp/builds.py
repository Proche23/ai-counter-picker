"""Pro runes, summoner spells, item build order and skill order for a champion in a role.

Two sources, best first:

* Riot timelines (LCK and international games, see timelines.py) record every purchase
  and level-up with its time. That gives the real start, first back, the order the items
  were finished in and when, boots timing, trinket swap and skill order.
* Leaguepedia stores each player's *final* inventory for every game, LPL included. Where a
  champion has too few timeline games, the order is inferred from build size: in a game
  that ended with k finished items, those k items are the first k bought, so the average
  build size of the games an item appears in rises with its slot.

Every game is weighted by recency (the 'builds' half-life), so the guide follows what pros
build right now.
"""
import datetime as dt
import json
import math
import os
from collections import Counter, defaultdict

from . import DATA, timelines
from .kb import damage_profile, profile

SUPPORT_LINE = {"World Atlas", "Runic Compass", "Bounty of Worlds", "Celestial Opposition",
                "Solstice Sleigh", "Bloodsong", "Dream Maker", "Zaz'Zak's Realmspike"}
SUPPORT_UPGRADES = SUPPORT_LINE - {"World Atlas", "Runic Compass", "Bounty of Worlds"}
JUNGLE_PETS = {"Gustwalker Hatchling", "Mosstomper Seedling", "Scorchclaw Pup"}
CONSUMABLE_HINTS = ("Potion", "Elixir", "Control Ward", "Stealth Ward", "Oracle Lens", "Farsight", "Stopwatch",
                    "Biscuit", "Poro-Snax", "Cookie")
BOOT_HINTS = ("Boots", "Greaves", "Treads", "Shoes", "Steelcaps", "Lucidity", "Swiftness",
              "Swiftmarch", "Crushers", "Armored Advance", "Forever Forward", "Ninja Tabi")
STARTER_HINTS = ("Doran's", "Cull", "Dark Seal", "Tear of the Goddess")

BUILD_LOG = DATA / "buildlog.json"
START_S = 90            # everything bought in the first 90 s is the start
TRIP_GAP_S = 20         # purchases less than 20 s apart are one trip to the shop
MIN_TL_GAMES = 4        # fewer timeline games than this: fall back to the inferred order
TRINKETS = ("Stealth Ward", "Oracle Lens", "Farsight Alteration")
SWAP_TRINKETS = ("Oracle Lens", "Farsight Alteration")
TRANSFORMS = {"Muramana": "Manamune", "Seraph's Embrace": "Archangel's Staff",
              "Fimbulwinter": "Winter's Approach"}
KEYS = "QWER"


class ItemBook:
    def __init__(self, dd_items, item_ids=None):
        self.dd = dd_items or {}
        self.by_id = {rec["id"]: name for name, rec in self.dd.items()}
        self.names = dict(item_ids or {})   # every Data Dragon id (all game modes) -> name
        self.names.update(self.by_id)
        self._kind = {}

    def name(self, iid):
        return self.names.get(str(iid))

    def kind(self, name):
        if name in self._kind:
            return self._kind[name]
        rec = self.dd.get(name)
        tags = set(rec["tags"]) if rec else set()
        if any(h in name for h in CONSUMABLE_HINTS) or (rec and (rec["consumed"] or "Trinket" in tags)):
            k = "consumable"
        elif name in SUPPORT_LINE:
            k = "support"
        elif name in JUNGLE_PETS:
            k = "pet"
        elif "Boots" in tags or any(h in name for h in BOOT_HINTS):
            k = "boots1" if name == "Boots" or (rec and rec["gold"] <= 350) else "boots"
        elif any(name.startswith(h) for h in STARTER_HINTS):
            k = "starter"
        elif rec:
            if rec["into"] and rec["gold"] < 2000:
                k = "component"
            elif rec["gold"] >= 1300 or not rec["into"]:
                k = "legendary" if rec["gold"] >= 1000 else "component"
            else:
                k = "component"
        else:
            k = "legendary"  # retired item no longer in Data Dragon - assume finished
        self._kind[name] = k
        return k

    def boots_base(self, name):
        """Tier-3 (feat upgrade) boots -> their tier-2 base, so they count together."""
        rec = self.dd.get(name)
        if not rec:
            return name
        for fid in rec.get("from", []):
            base = self.by_id.get(fid)
            if base and self.kind(base) == "boots":
                return base
        return name


def _split(s, sep):
    return [x.strip() for x in (s or "").split(sep) if x.strip()]


def _share(counter):
    total = sum(counter.values()) or 1.0
    return sorted(((k, v / total) for k, v in counter.items()), key=lambda kv: -kv[1])


def _wmedian(pairs):
    """Weighted median of [(value, weight)]."""
    pairs = sorted(pairs)
    total = sum(w for _, w in pairs)
    if total <= 0:
        return None
    acc = 0.0
    for v, w in pairs:
        acc += w
        if acc >= total / 2:
            return v
    return pairs[-1][0]


_KIND_ORDER = {"starter": 0, "pet": 0, "support": 0, "legendary": 1, "boots": 1, "boots1": 2,
               "component": 2, "consumable": 3}


def _combo(names, book):
    """A shopping list as ((item, count), ...): starting items first, potions last."""
    return tuple(sorted(Counter(names).items(), key=lambda kv: (_KIND_ORDER.get(book.kind(kv[0]), 2), kv[0])))


# ------------------------------------------------------------------ build log
def _tl_mtime():
    try:
        return max((os.path.getmtime(timelines.TL_DIR / fn) for fn in os.listdir(timelines.TL_DIR)
                    if fn.endswith(".json")), default=0.0)
    except OSError:
        return 0.0


def write_build_log(dd=None, con=None, path=BUILD_LOG):
    """Purchases and level-ups of every validated timeline game, compacted for the build guides
    (data/buildlog.json: a few MB instead of the ~90 MB of full timelines). Wards and potions
    bought after the start are dropped; the first trinket swap is kept."""
    from . import ddragon
    dd = dd or ddragon.load()
    book = ItemBook(dd.get("items"), dd.get("item_ids"))
    games = {}
    for gid, rec in timelines.load(con).items():
        ps = []
        for pid in map(str, range(1, 11)):
            side, role = rec["side"][pid]
            buys, swapped = [], False
            for t, iid in (rec.get("items") or {}).get(pid, []):
                name = book.name(iid)
                if name == "Stealth Ward":
                    continue
                if name in SWAP_TRINKETS:
                    if swapped:
                        continue
                    swapped = True
                elif name and t > START_S and book.kind(name) == "consumable":
                    continue
                buys.append(f"{int(round(t))}:{iid}")
            ps.append([side, role, rec["p"][pid][1], " ".join(buys), (rec.get("skills") or {}).get(pid, "")])
        games[gid] = {"d": rec["date"], "p": ps}
    tmp = str(path) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"v": 1, "built": dt.datetime.now().isoformat(timespec="seconds"), "games": games},
                  f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)
    return len(games)


_LOG = {"mtime": None, "games": {}}


def build_log(dd=None):
    """game_id -> {d, p: [[map side, role, champion, purchases, skills] x10]}; rebuilt when the
    timelines are newer than data/buildlog.json, cached per process."""
    newest = _tl_mtime()
    if not newest:
        return {}
    have = os.path.getmtime(BUILD_LOG) if BUILD_LOG.exists() else 0.0
    if have < newest:
        try:
            write_build_log(dd)
            have = os.path.getmtime(BUILD_LOG)
        except Exception:  # a stale log beats none
            if not have:
                return {}
    if _LOG["mtime"] != have:
        with open(BUILD_LOG, encoding="utf-8") as f:
            _LOG.update(mtime=have, games=json.load(f).get("games", {}))
    return _LOG["games"]


class Builds:
    def __init__(self, stats, dd, log=None):
        self.stats = stats
        self.dd = dd
        self.items = ItemBook(dd.get("items"), dd.get("item_ids"))
        self.dd_champs = dd.get("champions", {})
        self.rune_slot = {}
        for tree in dd.get("runes", []):
            for si, slot in enumerate(tree.get("slots", [])):
                for rune in slot.get("runes", []):
                    self.rune_slot[rune["name"]] = (tree["name"], si)
        self._log = log        # build log override (tests); default: data/buildlog.json
        self._tl = None        # (champion, role) -> timeline rows, built on first use
        self._cache = {}
        # Timeline purchases are item ids, named with the current Data Dragon. Ids get renamed
        # between seasons (2022's Luden's Tempest is today's Luden's Companion), so the real order
        # only uses this season and last (patch N.x is season 2010 + N); older replays fall back
        # to the inferred order, which uses Leaguepedia's names from the time.
        try:
            self.item_era = f"{2010 + int(str(dd.get('version', '')).split('.')[0]) - 1}-01-01"
        except ValueError:
            self.item_era = ""

    def _rows(self, champ, role):
        out = []
        for gid, sides in self.stats.players.items():
            if not self.stats.games[gid].get("core", 1):  # builds: LCK / LPL / international only
                continue
            for s, o in (("B", "R"), ("R", "B")):
                p = sides[s].get(role)
                if p and p["champion"] == champ:
                    enemy = [q["champion"] for q in sides[o].values()]
                    opp = sides[o].get(role)
                    out.append((self.stats.games[gid]["w"]["builds"], p, enemy,
                                opp["champion"] if opp else None))
        return out

    def _tl_rows(self, champ, role):
        """[(weight, purchases, skills, lane opponent, keystone, date)] from the timeline games these
        stats cover (the keystone comes from the same game's Leaguepedia rune page)."""
        if self._tl is None:
            games = self._log if self._log is not None else build_log(self.dd)
            idx = defaultdict(list)
            for gid, g in games.items():
                sg = self.stats.games.get(gid)
                if sg is None:  # outside the stats window, excluded, or after the replay date
                    continue
                w = sg["w"]["builds"] + 1e-6
                lane = {(q[0], q[1]): q[2] for q in g["p"]}
                ks = {(r, p["champion"]): p.get("keystone")
                      for sides in self.stats.players.get(gid, {}).values() for r, p in sides.items()}
                for side, r, ch, buys, skills in g["p"]:
                    idx[(ch, r)].append((w, buys, skills, lane.get(("red" if side == "blue" else "blue", r)),
                                         ks.get((r, ch)), g["d"]))
            self._tl = idx
        return self._tl.get((champ, role), [])

    @staticmethod
    def _same_page(rows, ks, key, min_games=5, min_share=0.3):
        """The rows whose player ran keystone ks, when they are a real part of the sample: an item
        build only makes sense with the rune page it goes with (Comet Varus rushes Youmuu's,
        Lethal Tempo Varus rushes Statikk Shiv)."""
        if not ks:
            return rows
        sub = [r for r in rows if key(r) == ks]
        if len(sub) >= min_games and sum(r[0] for r in sub) >= min_share * sum(r[0] for r in rows):
            return sub
        return rows

    def for_champ(self, champ, role, opp=None):
        key = (champ, role, opp)
        if key not in self._cache:
            self._cache[key] = self._for_champ(champ, role, opp)
        return self._cache[key]

    def _for_champ(self, champ, role, opp):
        rows = self._rows(champ, role)
        if not rows:
            return None
        res = {"champion": champ, "role": role, "n": len(rows)}
        res.update(self._runes(rows, opp))
        res["spells"] = self._spells(rows)
        ks = (res.get("page") or {}).get("keystone")
        page_rows = self._same_page(rows, ks, lambda r: r[1]["keystone"])
        res.update(self._items(page_rows, role))
        res["order_source"] = "inferred"
        tl_all = self._tl_rows(champ, role)
        tl = self._same_page(tl_all, ks, lambda r: r[4])
        def narrowed(sub, full):  # the page filter dropped a real share (10%+) of the games
            return sub is not full and sum(r[0] for r in sub) < 0.9 * sum(r[0] for r in full)
        res["items_for"] = ks if (narrowed(page_rows, rows) or narrowed(tl, tl_all)) else None
        if tl:
            sk = self._skills(champ, [(r[0], r[2]) for r in tl if r[2]])
            if sk:
                res["skills"] = sk
            order = self._timeline(tl, opp)
            if order and order.get("path"):
                res["timeline"] = order
                res["order_source"] = "timeline"
                res["path"] = order["path"]
                if order.get("boots"):
                    legacy = res.get("boots") or {}
                    up = legacy.get("upgrade") if legacy.get("item") == order["boots"]["item"] else None
                    res["boots"] = {**order["boots"], "upgrade": up}
        cands = res.pop("_cands")
        used = {p["item"] for p in res["path"]} | {a for p in res["path"] for a, _ in p.get("alt", [])}
        used |= {TRANSFORMS.get(n, n) for n in used}  # Muramana is the Manamune already listed
        res["situational"] = [c for c in cands if TRANSFORMS.get(c["item"], c["item"]) not in used][:4]
        res["alt_build"] = self._alt_build(res, rows, tl_all, role)
        return res

    def _alt_build(self, res, rows, tl_all, role):
        """The other common rune page and the items that go with it (e.g. on-hit vs poke Varus)."""
        main = (res.get("page") or {}).get("keystone")
        for k2, share in (res.get("keystones") or [])[1:2]:
            if share < 0.2 or k2 == main:
                continue
            tl2 = [r for r in tl_all if r[4] == k2]
            order = self._timeline(tl2, None) if len(tl2) >= MIN_TL_GAMES else None
            if order and order.get("path"):
                items, src = [p["item"] for p in order["path"][:3]], "timeline"
            else:
                rows2 = [r for r in rows if r[1]["keystone"] == k2]
                if len(rows2) < 5:
                    continue
                items, src = [p["item"] for p in self._items(rows2, role)["path"][:3]], "inferred"
            main_items = [p["item"] for p in res.get("path", [])[:2]]
            if items and items[:2] != main_items:
                return {"keystone": k2, "share": share, "items": items, "source": src}
        return None

    # ------------------------------------------------------- timeline order
    def _timeline(self, tl, opp):
        """Real start, first back, trinket, finished-item order with times and boots timing."""
        ib = self.items
        parsed, w_all = [], 0.0
        for w, buys, _, o, _, day in tl:
            if day < self.item_era:  # item ids get renamed across seasons: name only recent ones
                continue
            if not buys:
                continue
            w_all += w
            lst = []
            for tok in buys.split():
                t, _, iid = tok.partition(":")
                name = ib.name(iid)
                if name is None or name not in ib.dd:  # unknown or retired item: can't use this game
                    lst = None
                    break
                lst.append((int(t), TRANSFORMS.get(name, name)))
            if lst:
                parsed.append((w, lst, o))
        if len(parsed) < MIN_TL_GAMES or sum(w for w, _, _ in parsed) < 0.8 * w_all:
            return None
        W = sum(w for w, _, _ in parsed)
        out = {"games": len(parsed), "n_eff": round(W * W / sum(w * w for w, _, _ in parsed), 1)}

        # start (and whether it depends on the lane opponent's range)
        starts, by_rng, n_rng = defaultdict(float), defaultdict(lambda: defaultdict(float)), Counter()
        for w, lst, o in parsed:
            combo = _combo([n for t, n in lst if t <= START_S and n not in TRINKETS], ib)
            if not combo:
                continue
            starts[combo] += w
            if o:
                rng = profile(o, self.dd_champs)["range"]
                by_rng[rng][combo] += w
                n_rng[rng] += 1
        if starts:
            out["start"] = [{"items": c, "share": v} for c, v in _share(starts)[:2] if v >= 0.1]
            vs = {}
            for rng in ("M", "R"):
                if n_rng[rng] >= 4:
                    c, v = _share(by_rng[rng])[0]
                    vs[rng] = {"items": c, "share": v, "games": n_rng[rng]}
            if len(vs) == 2 and vs["M"]["items"] != vs["R"]["items"]:
                out["start_vs"] = vs
                if opp:
                    rng = profile(opp, self.dd_champs)["range"]
                    out["start_now"] = {**vs[rng], "opp": opp, "range": rng}

        # trinket swap (Oracle Lens / Farsight), when most games make one
        swaps = defaultdict(list)
        for w, lst, _ in parsed:
            for t, n in lst:
                if n in SWAP_TRINKETS:
                    swaps[n].append((t, w))
                    break
        if swaps:
            n, pairs = max(swaps.items(), key=lambda kv: sum(w for _, w in kv[1]))
            share = sum(w for _, w in pairs) / W
            if share >= 0.5:
                out["trinket"] = {"item": n, "t": _wmedian(pairs), "share": share}

        # first back: the first trip to the shop after the start
        fb_items, fb_combo, fb_t, w_fb = defaultdict(float), defaultdict(float), [], 0.0
        for w, lst, _ in parsed:
            post = [(t, n) for t, n in lst if t > START_S and n not in TRINKETS and ib.kind(n) != "consumable"]
            if not post:
                continue
            trip = [post[0]]
            for t, n in post[1:]:
                if t - trip[-1][0] > TRIP_GAP_S:
                    break
                trip.append((t, n))
            names = [n for _, n in trip]
            w_fb += w
            fb_t.append((trip[0][0], w))
            for n in set(names):
                fb_items[n] += w
            fb_combo[_combo(names, ib)] += w
        if w_fb:
            c, v = _share(fb_combo)[0]
            out["first_back"] = {
                "t": _wmedian(fb_t), "combo": c if v >= 0.25 else None, "combo_share": v,
                "items": [(n, x / w_fb) for n, x in sorted(fb_items.items(), key=lambda kv: -kv[1])
                          if x / w_fb >= 0.2][:3]}

        # finished items in the order they were completed, and tier-2 boots
        seqs = []
        for w, lst, _ in parsed:
            legs, seen, boots = [], set(), None
            for t, n in lst:
                k = ib.kind(n)
                if k == "legendary" and n not in seen:
                    seen.add(n)
                    legs.append((t, n))
                elif k == "boots" and boots is None:
                    boots = (t, ib.boots_base(n), len(legs))
            seqs.append((w, legs, boots))
        path = self._tl_path(seqs, W)
        out["path"] = path
        w_boots = sum(w for w, _, b in seqs if b)
        boots = None
        if w_boots >= 0.3 * W:
            cnt = defaultdict(float)
            for w, _, b in seqs:
                if b:
                    cnt[b[1]] += w
            item, iw = max(cnt.items(), key=lambda kv: kv[1])
            pos = _wmedian([(b[2], w) for w, _, b in seqs if b and b[1] == item])
            t = _wmedian([(b[0], w) for w, _, b in seqs if b and b[1] == item and b[2] == pos])
            boots = {"item": item, "share": w_boots / W, "type_share": iw / w_boots, "after_slot": pos, "t": t}
            out["boots"] = boots
        steps = [{"item": p["item"], "kind": "item", "t": p["t"], "share": p["share"], "alt": p["alt"]}
                 for p in path]
        if boots:
            steps.insert(min(boots["after_slot"], len(steps)),
                         {"item": boots["item"], "kind": "boots", "t": boots["t"], "share": boots["type_share"],
                          "alt": []})
        out["order"] = steps
        return out

    @staticmethod
    def _tl_path(seqs, W, slots=5):
        """Most common finished item at each step. A step follows the games that built the
        items chosen so far when enough did (so the build stays coherent), else all games."""
        path, chosen = [], []
        for k in range(slots):
            reach = [(w, legs) for w, legs, _ in seqs if len(legs) > k]
            wk = sum(w for w, _ in reach)
            if len(reach) < 3 or wk < 0.15 * W:
                break
            cond = [(w, legs) for w, legs in reach if {n for _, n in legs[:k]} == set(chosen)]
            pool = cond if (len(cond) >= 3 and sum(w for w, _ in cond) >= 0.4 * wk) else reach
            pool = [(w, legs) for w, legs in pool if legs[k][1] not in chosen]
            wp = sum(w for w, _ in pool)
            if len(pool) < 3 or wp <= 0:
                break
            cnt = defaultdict(float)
            for w, legs in pool:
                cnt[legs[k][1]] += w
            best, bw = max(cnt.items(), key=lambda kv: kv[1])
            if bw / wp < 0.15:  # no item is standard at this step any more
                break
            t = _wmedian([(legs[k][0], w) for w, legs in pool if legs[k][1] == best])
            path.append({"slot": k + 1, "item": best, "share": bw / wp, "t": t, "games": len(pool), "alt": []})
            chosen.append(best)
        for a, b in zip(path, path[1:]):  # steps from different game subsets: keep the times in order
            if a["t"] is not None and b["t"] is not None and b["t"] < a["t"]:
                b["t"] = a["t"]
        named = set(chosen)  # the most common other item at each step, each named once
        for k, p in enumerate(path):
            cnt, wk = defaultdict(float), 0.0
            for w, legs, _ in seqs:
                if len(legs) > k:
                    wk += w
                    if legs[k][1] not in named:
                        cnt[legs[k][1]] += w
            if cnt and wk:
                a, aw = max(cnt.items(), key=lambda kv: kv[1])
                if aw / wk >= 0.15:
                    p["alt"] = [(a, aw / wk)]
                    named.add(a)
        return path

    # ------------------------------------------------------------ skills
    def _skills(self, champ, rows, levels=18):
        """Skill order from the level-up events: the most typical path through the per-level
        skill-point states (a Viterbi pass), so champions with unusual rules (Jayce's 6-rank
        basics, Udyr's levelled R, Aphelios) come out right without special cases."""
        rows = [(w, s) for w, s in rows if len(s) >= 3 and set(s) <= set("1234")]
        if len(rows) < 3:
            return None
        starts = defaultdict(float)  # the first three points as pros actually take them
        for w, s in rows:
            starts[s[:3]] += w
        start_digits, start_share = _share(starts)[0]
        states = [defaultdict(float) for _ in range(levels)]
        tot, reach = [0.0] * levels, [0] * levels
        forced, cnt = [], [0, 0, 0, 0]
        for c in start_digits:
            cnt[int(c) - 1] += 1
            forced.append(tuple(cnt))
        for w, s in rows:
            cnt = [0, 0, 0, 0]
            for lv, c in enumerate(s[:levels]):
                cnt[int(c) - 1] += 1
                states[lv][tuple(cnt)] += w
                tot[lv] += w
                reach[lv] += 1
        prev, back = {}, []
        for lv in range(levels):
            if reach[lv] < 3:
                break
            cur, bk = {}, {}
            for st, wt in states[lv].items():
                if lv < 3 and st != forced[lv]:  # the path starts with the most common start
                    continue
                sc = math.log(wt / tot[lv] + 1e-3)
                if lv == 0:
                    cur[st], bk[st] = sc, None
                    continue
                best = None
                for k in range(4):
                    if st[k]:
                        p = st[:k] + (st[k] - 1,) + st[k + 1:]
                        if p in prev and (best is None or prev[p] > prev[best]):
                            best = p
                if best is not None:
                    cur[st], bk[st] = prev[best] + sc, best
            if not cur:
                break
            back.append(bk)
            prev = cur
        st = max(prev, key=prev.get)
        chain = [st]
        for lv in range(len(back) - 1, 0, -1):
            st = back[lv][st]
            chain.append(st)
        chain.reverse()
        seq, last = "", (0, 0, 0, 0)
        for st in chain:
            seq += KEYS[next(i for i in range(4) if st[i] != last[i])]
            last = st
        r_basic = seq.count("R") > 3          # Udyr-style: R is levelled like a basic ability
        abil = [k for k in KEYS if seq.count(k) and (k != "R" or r_basic)]
        order = sorted(abil, key=lambda k: max(i for i, c in enumerate(seq) if c == k))
        # how often pros max the same ability first (the most points at level 9)
        first = order[0] if order else None
        agree = w9 = 0.0
        for w, s in rows:
            if len(s) < 9:
                continue
            pts = Counter(KEYS[int(c) - 1] for c in s[:9])
            cand = [k for k in abil if k in pts]
            if not cand:
                continue
            top = max(cand, key=lambda k: (pts[k], -s[:9].index(str(KEYS.index(k) + 1))))
            w9 += w
            agree += w * (top == first)
        names = (self.dd_champs.get(champ) or {}).get("spells") or []
        return {"seq": seq, "start": seq[:3], "start_share": start_share,
                "max": order, "max_share": agree / w9 if w9 else None,
                "r_levels": [] if r_basic else [i + 1 for i, c in enumerate(seq) if c == "R"],
                "games": len(rows), "names": dict(zip(KEYS, names)) if len(names) == 4 else {}}

    # ------------------------------------------------------------- runes
    def _runes(self, rows, opp):
        keystones, pages = defaultdict(float), defaultdict(float)
        for w, p, _, _ in rows:
            runes = _split(p["runes"], ",")
            if p["keystone"]:
                keystones[p["keystone"]] += w + 1e-6
            if len(runes) >= 6:
                pages[(p["primary_tree"], p["secondary_tree"], tuple(runes))] += w + 1e-6
        if not keystones:
            return {"keystones": [], "page": None, "vs_runes": None}
        ks_share = _share(keystones)
        best_ks = ks_share[0][0]
        slot_votes = defaultdict(lambda: defaultdict(float))
        sec_tree, sec_pair = defaultdict(float), defaultdict(float)
        prim_tree = defaultdict(float)
        for (pt, st, runes), w in pages.items():
            if runes[0] != best_ks:
                continue
            prim_tree[pt] += w
            for i in (1, 2, 3):
                if i < len(runes):
                    slot_votes[i][runes[i]] += w
            sec_tree[st] += w
            sec_pair[(st, tuple(runes[4:6]))] += w
            for i in (6, 7, 8):
                if i < len(runes):
                    slot_votes[i][runes[i]] += w
        page = None
        if prim_tree:
            st = max(sec_tree.items(), key=lambda kv: kv[1])[0]
            pair = max(((k, v) for k, v in sec_pair.items() if k[0] == st), key=lambda kv: kv[1])[0][1]
            pair = sorted(pair, key=lambda r: self.rune_slot.get(r, ("", 9))[1])
            page = {
                "primary": max(prim_tree.items(), key=lambda kv: kv[1])[0],
                "keystone": best_ks,
                "primary_runes": [max(slot_votes[i].items(), key=lambda kv: kv[1])[0]
                                  for i in (1, 2, 3) if slot_votes[i]],
                "secondary": st,
                "secondary_runes": list(pair),
                "shards": [max(slot_votes[i].items(), key=lambda kv: kv[1])[0]
                           for i in (6, 7, 8) if slot_votes[i]],
                "share": ks_share[0][1],
            }
        vs = None
        if opp:
            vk = defaultdict(float)
            n = 0
            for w, p, _, o in rows:
                if o == opp and p["keystone"]:
                    vk[p["keystone"]] += 1
                    n += 1
            if n >= 2:
                vs = {"opp": opp, "n": n, "keystones": _share(vk)}
        # keystone choice by lane-opponent range (e.g. Grasp vs ranged, Conqueror vs melee)
        by_range = defaultdict(lambda: defaultdict(float))
        for w, p, _, o in rows:
            if o and p["keystone"]:
                by_range[profile(o, self.dd_champs)["range"]][p["keystone"]] += w + 1e-6
        range_split = {}
        for rng, cnt in by_range.items():
            if sum(cnt.values()) > 0:
                range_split[rng] = _share(cnt)[0]
        return {"keystones": ks_share[:3], "page": page, "vs_runes": vs, "keystone_by_range": range_split}

    # ------------------------------------------------------------- spells
    def _spells(self, rows):
        cnt = defaultdict(float)
        for w, p, _, _ in rows:
            sp = tuple(sorted(_split(p["spells"], ","), key=lambda s: (s != "Flash", s)))
            if sp:
                cnt[" + ".join(sp)] += w + 1e-6
        return _share(cnt)[:2]

    # -------------------------------------------------------------- items
    def _items(self, rows, role):
        ib = self.items
        builds = []  # (weight, legendaries, boots_base, starters, support, enemy)
        for w, p, enemy, _ in rows:
            legend, boots, starters, support = set(), None, set(), None
            for it in _split(p["items"], ";"):
                k = ib.kind(it)
                if k == "legendary":
                    legend.add(it)
                elif k == "boots":
                    boots = (ib.boots_base(it), it)
                elif k in ("starter", "pet"):
                    starters.add(it)
                elif k == "support":
                    support = it
            builds.append((w + 1e-6, legend, boots, starters, support, enemy))
        W = sum(b[0] for b in builds)
        size_w = defaultdict(float)
        for w, legend, *_ in builds:
            size_w[len(legend)] += w
        # E[k | k >= m] for each slot m, from this champion's own build-size spread
        tail = {}
        for m in range(1, 7):
            tw = sum(v for k, v in size_w.items() if k >= m)
            if tw > 0:
                tail[m] = sum(k * v for k, v in size_w.items() if k >= m) / tw
        pres, ksum = defaultdict(float), defaultdict(float)
        for w, legend, *_ in builds:
            for it in legend:
                pres[it] += w
                ksum[it] += w * len(legend)

        def slot_of(it):
            mean_k = ksum[it] / pres[it]
            return min(tail, key=lambda m: abs(tail[m] - mean_k)) if tail else 1

        cands = sorted((it for it in pres if pres[it] / W >= 0.08), key=lambda it: -pres[it])
        slots = {it: slot_of(it) for it in cands}
        path, used = [], set()
        for m in range(1, 6):
            floor = 0.12 if m <= 2 else 0.2
            options = [it for it in cands if slots[it] == m and it not in used and pres[it] / W >= floor]
            if not options:
                options = sorted((it for it in cands if it not in used and pres[it] / W >= 0.25),
                                 key=lambda it: (abs(slots[it] - m), -pres[it]))[:1]
            if not options:
                break
            best = max(options, key=lambda it: pres[it])
            alt = [it for it in options if it != best and pres[it] >= 0.5 * pres[best] and pres[it] / W >= 0.15]
            path.append({"slot": m, "item": best, "share": pres[best] / W,
                         "alt": [(a, pres[a] / W) for a in alt[:1]]})
            used.add(best)
            used.update(a for a in alt[:1])
        # boots
        boots_cnt, upgrade_cnt, boots_k = defaultdict(float), defaultdict(lambda: defaultdict(float)), defaultdict(float)
        for w, legend, boots, *_ in builds:
            if boots:
                boots_cnt[boots[0]] += w
                boots_k[boots[0]] += w * len(legend)
                if boots[1] != boots[0]:
                    upgrade_cnt[boots[0]][boots[1]] += w
        boots_info = None
        if boots_cnt:
            b, bw = max(boots_cnt.items(), key=lambda kv: kv[1])
            mean_k = boots_k[b] / bw
            after = min(tail, key=lambda m: abs(tail[m] - mean_k)) if tail else 1
            up = max(upgrade_cnt[b].items(), key=lambda kv: kv[1])[0] if upgrade_cnt[b] else None
            boots_info = {"item": b, "share": sum(boots_cnt.values()) / W, "type_share": bw / sum(boots_cnt.values()),
                          "after_slot": after, "upgrade": up}
        # situational items + what they answer (for every common item: the final path may come
        # from the timelines instead, and situational = the common items that aren't in it)
        base_ap = sum(w * damage_profile(e, self.dd_champs)["AP"] for w, *_, e in builds) / W
        base_heal = sum(w * self._count(e, "hl", 2) for w, *_, e in builds) / W
        base_tank = sum(w * self._tanks(e) for w, *_, e in builds) / W
        situational = []
        for it in cands:
            iw = pres[it]
            with_item = [(w, e) for w, legend, *_, e in builds if it in legend]
            ap = sum(w * damage_profile(e, self.dd_champs)["AP"] for w, e in with_item) / iw
            heal = sum(w * self._count(e, "hl", 2) for w, e in with_item) / iw
            tank = sum(w * self._tanks(e) for w, e in with_item) / iw
            note = ""
            if len(with_item) >= 10:  # only explain items with a real sample, one reason max
                signals = [((ap - base_ap) / 0.12, "vs AP threats"), ((base_ap - ap) / 0.12, "vs AD threats"),
                           ((heal - base_heal) / 0.5, "vs healing"), ((tank - base_tank) / 0.5, "vs tanks")]
                strength, label = max(signals)
                if strength >= 1.0:
                    note = label
            situational.append({"item": it, "share": iw / W, "note": note})
        # start
        start_cnt, sup_cnt = defaultdict(float), defaultdict(float)
        for w, _, _, starters, support, _ in builds:
            for s in starters:
                start_cnt[s] += w
            if support:
                sup_cnt[support] += w
        # starters are often sold before the game ends, so list the top two seen
        start = [s for s, sw in sorted(start_cnt.items(), key=lambda kv: -kv[1]) if sw / W >= 0.1][:2] or None
        support_item = None
        if sup_cnt:
            s, sw = max(sup_cnt.items(), key=lambda kv: kv[1])
            support_item = {"item": s, "share": sw / W}
        return {"path": path, "boots": boots_info, "_cands": situational,
                "start": start, "support_item": support_item, "avg_items": sum(k * v for k, v in size_w.items()) / W}

    def _count(self, champs, trait, level):
        return sum(1 for c in champs if profile(c, self.dd_champs)["traits"][trait] >= level)

    def _tanks(self, champs):
        return sum(1 for c in champs if profile(c, self.dd_champs)["class"] == "tank"
                   or profile(c, self.dd_champs)["traits"]["fl"] >= 3)
