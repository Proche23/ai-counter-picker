"""One call that answers 'what now?' for any draft state.

Returns a plain dict (JSON-serialisable), so a future website can call
analyze() directly and render it however it likes.
"""
import math

from . import ROLES, db, ddragon, load_config
from .builds import Builds
from .comp import Planner
from .engine import OTHER, SIDE_NAME, Draft, Engine, load_model
from .kb import damage_profile, profile
from .names import ChampNames
from .predictor import EnemyPredictor
from .stats import ProStats


class Advisor:
    def __init__(self, cfg=None, exclude_pages=(), before=None, lookahead=True):
        self.cfg = cfg or load_config()
        self.dd = ddragon.load()
        self.names = ChampNames(self.dd["champions"])
        con = db.connect()
        self.stats = ProStats(con, self.cfg, self.dd["champions"], exclude_pages=exclude_pages, before=before)
        con.close()
        self.model = load_model()
        self.builds = Builds(self.stats, self.dd)
        self.engine = Engine(self.stats, self.builds, self.dd["champions"], model=self.model)
        self.predictor = EnemyPredictor(self.stats, weights=self.model.get("predictor"), engine=self.engine)
        if lookahead:
            self.engine.predictor = self.predictor
        self.planner = Planner(self.stats, self.builds, self.dd["champions"], conditions=self.model.get("conditions"))

    # ----------------------------------------------------------------
    def analyze(self, draft, us=None, role=None, top=5, next_override=None, solo=None):
        """solo (solo queue, needs us + role): {"slot": your pick number 1-5 or None, "pool": [your champions]
        or None, "ban_stage": True while the 10 bans are being entered, "engine": the solo queue engine
        (acp.soloq.SoloBlend: solo queue evidence for champions with few pro games) or None}."""
        eng, st = (solo or {}).get("engine") or self.engine, self.stats
        if solo and solo.get("ban_stage") and us:
            nb = len(draft.bans["B"]) + len(draft.bans["R"])
            next_override = {"seq": 0, "side": us, "action": "ban", "n": nb + 1, "double": False, "solo": True}
        nxt = next_override or draft.next_action()
        res = {"summary": st.summary(), "draft": self._state(draft), "next": nxt}
        if nxt is None:
            res["complete"] = True
            ev = eng.evaluate(draft)
            ev["info"] = eng.model.get("info", {})
            ev["calibration"] = self._calibration(ev["p_blue"], ev.get("model", "draft"))
            res["verdict"] = ev
            res["plans"], res["team_builds"] = {}, {}
            for side in ("B", "R"):   # both teams' ways to win and lose; builds for your side (or both)
                ours = eng.assign(draft.picks[side])
                theirs = eng.assign(draft.picks[OTHER[side]])
                res["plans"][side] = self.planner.plan(ours, theirs)
                if not us or side == us:
                    res["team_builds"][side] = {r: self.builds.for_champ(c, r, opp=theirs.get(r))
                                                for r, c in ours.items()}
            res["ingame"] = self.ingame_context(ev, res["plans"])
            return res

        side = nxt["side"]
        res["acting"] = side
        res["perspective"] = "enemy" if (us and us != side) else "us"
        if nxt["action"] == "ban":
            keep = set((solo or {}).get("keep") or [])   # your teammates' planned picks: never suggest banning them
            hover = (solo or {}).get("hover")
            ranked = [b for b in eng.bans(draft, side, 30 if hover else top + len(keep)) if b["champ"] not in keep]
            res["bans"] = ranked[:top]
            if hover:   # the ban you're hovering in the client: how it ranks
                res["hover"] = self._rank_of(hover, ranked)
            res["own_targets"], _ = eng.recommend(draft, side, top=8)
            bctx = eng.context(draft, "B", with_enemy=False, lookahead=False)
            res["p_blue_now"] = bctx["p_now"]
            return res

        if solo and us and role:
            role, recs, ctx = self._solo_recs(draft, side, us, role, solo, top, res, eng)
        else:
            recs, ctx = eng.recommend(draft, side, role=role, top=top)
        res["recs"] = recs
        # what pro teams in this exact spot most often pick (the predictor, not the engine's advice)
        res["likely_now"] = self.predictor.next_pick(ctx["allies"], ctx["enemies"], ctx["unavail"],
                                                     [role] if role else ctx["open"], draft.teams[side], top=5)
        if not recs:
            res["error"] = "No pro-proven champion is available for the open roles."
            return res
        if nxt.get("double") and not role:
            res["pair"] = eng.best_pair(draft, side, recs)
        best = recs[0]
        d2 = draft.copy_with_pick(side, best["champ"], best["role"])
        plan_side = us or side
        ours = eng.assign(d2.picks[plan_side])
        theirs = eng.assign(d2.picks[OTHER[plan_side]])
        # judge their *likely finished* comp, not just what is locked in
        likely = {}
        if len(theirs) < 5:
            pred = self.predictor.predict(d2, OTHER[plan_side], top=3)
            taken = set(theirs.values()) | set(ours.values())
            for r, dist in pred.items():
                for c, p in dist:
                    if c not in taken:
                        likely[r] = (c, p)
                        taken.add(c)
                        break
        if ours:   # (no plan yet for a team with no champions: you're Red and Blue is making the first pick)
            res["plan"] = self.planner.plan(ours, {**theirs, **{r: c for r, (c, _) in likely.items()}})
            res["plan"]["their_likely"] = {r: [c, p] for r, (c, p) in likely.items()}
        else:
            res["plan"] = None
        res["plan_side"] = plan_side
        res["build"] = self.builds.for_champ(best["champ"], best["role"],
                                             opp=eng.assign(d2.picks[OTHER[side]]).get(best["role"]))
        ctx2 = eng.context(d2, side, with_enemy=False)
        res["then"] = {r: eng.candidates(ctx2, [r], with_denial=False)[:2] for r in ctx2["open"]}
        enemy_side = OTHER[side]
        e_own = eng.assign(d2.picks[enemy_side])
        e_opp = eng.assign(d2.picks[side])
        e_roles = [r for r in ROLES if r not in e_own]
        res["threats"] = (self.predictor.next_pick(e_own, e_opp, d2.unavailable(), e_roles,
                                                    d2.teams[enemy_side], top=5) if e_roles else [])
        return res

    def _solo_recs(self, draft, side, us, my_role, solo, top, res, eng=None):
        """Solo queue: on your turn only your role (and your champions, if given); on a teammate's turn
        the other open roles; on the enemy's turn their best picks. Returns (role used, recs, ctx)."""
        eng = eng or self.engine
        mine_done = any(r == my_role for _, r in draft.picks[us])
        if side != us or mine_done:
            res["solo_turn"] = "enemy" if side != us else "teammate"
            recs, ctx = eng.recommend(draft, side, top=top)
            return None, recs, ctx
        slot = solo.get("slot")
        now = solo.get("now")   # from the League client: True = your pick is in progress, False = a teammate's
        if now is False or (now is None and slot and len(draft.picks[us]) != slot - 1):
            res["solo_turn"] = "teammate"
            allies = eng.assign(draft.picks[us], my_role)
            roles = [r for r in ROLES if r not in allies and r != my_role] or None
            recs, ctx = eng.recommend(draft, side, top=top, roles=roles)
            return None, recs, ctx
        res["solo_turn"] = "me"
        ranked, ctx = eng.recommend_ranked(draft, side, [my_role])
        pool = [c for c in (solo.get("pool") or []) if c]
        if solo.get("hover"):   # the champion you're hovering in the client: how it ranks
            res["hover"] = self._rank_of(solo["hover"], ranked, pool)
        if not pool:
            return my_role, ranked[:top], ctx
        have = {x["champ"] for x in ranked}
        gone = draft.unavailable()
        mine = [x for x in ranked if x["champ"] in pool]
        res["pool"] = {
            "champs": pool, "fallback": not mine,
            "taken": [c for c in pool if c in gone],
            "no_pro_data": [c for c in pool if c not in have and c not in gone],   # < 3 pro games (and too few solo games)
            "best_any": ranked[:3],
        }
        return my_role, (mine or ranked)[:top], ctx

    def rate_hovers(self, draft, side, hovers, eng=None):
        """Champions your teammates are hovering (or planning), each rated for their own role as if
        picked now: [{champ, role, slot, rank, of, win, best, taken}]. rank None: too few pro games
        in that role to rate it, or it's banned or taken (taken=True)."""
        eng, out, ranked, ctx = eng or self.engine, [], {}, None
        gone = draft.unavailable()
        for h in hovers[:5]:
            c, r = h.get("champ"), h.get("role")
            if not c or r not in ROLES:
                continue
            if r not in ranked:
                ctx = ctx or eng.context(draft, side)
                ranked[r] = eng.candidates(ctx, [r])
            x = self._rank_of(c, ranked[r])
            x.update(role=r, slot=h.get("slot"), taken=c in gone)
            out.append(x)
        return out

    @staticmethod
    def _rank_of(champ, ranked, pool=None):
        """Where `champ` stands among the ranked candidates (and among your champions)."""
        for i, x in enumerate(ranked):
            if x["champ"] == champ:
                mine = [y["champ"] for y in ranked if y["champ"] in pool] if pool else []
                return {"champ": champ, "rank": i + 1, "of": len(ranked), "rating": x.get("rating"),
                        "win": (x.get("components") or {}).get("win"), "best": ranked[0]["champ"],
                        "pool_rank": mine.index(champ) + 1 if champ in mine else None, "pool_of": len(mine)}
        return {"champ": champ, "rank": None}   # too few pro games in this role to rate it

    def matchups(self, draft, hovers=None):
        """Every counter matchup between the two teams, from pro games.

        lanes: for each role, the first-pick side's champion against the other side's: its record in
        that lane (LCK / LPL / internationals), how many other-region games add to the estimate, and the
        estimate itself (the lane's win rate, pulled toward what the two champions' overall strength
        predicts when there are few games). Bot lane also 2 v 2: each carry against the other support.
        pairs: all champion pairs whatever their roles, as the win model's "counters" see them (how a
        team does when the other team has that champion), and how much the counters move the win chance.
        hovers: {"B"/"R": {role: champ}} champions not locked yet (your team's hovers), marked as such."""
        st, eng = self.stats, self.engine
        teams = {s: dict(eng.assign(draft.picks[s])) for s in ("B", "R")}
        hovered = {"B": set(), "R": set()}
        taken = set(teams["B"].values()) | set(teams["R"].values())
        for s, hv in (hovers or {}).items():
            for r, c in (hv or {}).items():
                if s in teams and r in ROLES and r not in teams[s] and c and c not in taken:
                    teams[s][r] = c
                    hovered[s].add(c)
                    taken.add(c)
        if not teams["B"] or not teams["R"]:
            return None

        def lane(b, r, e):
            x = st.lane_wl(b, r, e)
            exp = min(0.65, max(0.35, 0.5 + st.champ_long_rate(b) - st.champ_long_rate(e)))
            return {"p": round(x.rate(prior=exp, k=8), 4), "record": x.record, "n": x.rg,
                    "other": st.lane_other.get((b, r, e), 0), "expected": round(exp, 4)}

        lanes = []
        for r in ROLES:
            b, e = teams["B"].get(r), teams["R"].get(r)
            row = {"role": r, "B": b, "R": e, "hover": {"B": b in hovered["B"], "R": e in hovered["R"]}}
            if b and e:
                row.update(lane(b, r, e))
            lanes.append(row)
        duo = []
        for r, er in (("BOT", "SUP"), ("SUP", "BOT")):
            b, e = teams["B"].get(r), teams["R"].get(er)
            if b and e:
                x = st.duo_wl(b, r, e, er)
                duo.append({"B": b, "role": r, "R": e, "rrole": er, "p": round(x.rate(k=10), 4),
                            "record": x.record, "n": x.rg})
        rows = [(r, teams["B"][r]) for r in ROLES if r in teams["B"]]
        cols = [(r, teams["R"][r]) for r in ROLES if r in teams["R"]]
        grid, flat = [], []
        for br, b in rows:
            line = []
            for rr, e in cols:
                x = st.vs_wl(b, e)
                cell = {"p": round(eng.vs_rate(b, e), 4), "record": x.record, "n": x.rg,
                        "other": st.vs_other.get((b, e), 0)}
                line.append(cell)
                flat.append((cell["p"], b, br, e, rr, cell))
            grid.append(line)
        # the counters' share of the win chance: their term in the win model, at even odds
        tb, tr = draft.teams["B"], draft.teams["R"]
        w = eng.weights(tb, tr)
        a, _ = eng.calibration(eng.model_key(tb, tr))
        f = sum(2.0 * (p - 0.5) / 5.0 for p, *_ in flat)
        effect = 1.0 / (1.0 + math.exp(-a * w.get("counter", 0.0) * f)) - 0.5
        flat.sort(key=lambda t: -t[0])
        pick = lambda items: [{"B": b, "brole": br, "R": e, "rrole": rr, **cell} for _, b, br, e, rr, cell in items]
        return {
            "lanes": lanes, "duo": duo,
            "rows": [{"role": r, "champ": c, "hover": c in hovered["B"]} for r, c in rows],
            "cols": [{"role": r, "champ": c, "hover": c in hovered["R"]} for r, c in cols],
            "grid": grid, "effect": round(effect, 4),
            "best": {"B": pick([t for t in flat if t[0] > 0.52][:3]), "R": pick([t for t in flat[::-1] if t[0] < 0.48][:3])},
            "complete": len(rows) == 5 and len(cols) == 5,
        }

    def champion_report(self, champ, role=None, vs=None):
        st = self.stats
        roles = st.roles(champ)
        role = role or (roles[0][0] if roles and roles[0][1] > 0 else None)
        if not role:
            return {"champ": champ, "error": "no pro games for this champion in the data"}
        wl = st.wr_long(champ, role)
        rec = st.recent(champ, role)
        lanes = []
        for (c, r, opp), x in st.lane.items():
            if c == champ and r == role and x.rg >= 3:
                exp = 0.5 + (st.champ_long_rate(c) - st.champ_long_rate(opp))
                lanes.append((x.rate(prior=exp, k=6) - exp, opp, x.record, x.rg))
        syn = []
        for (a, b), x in st.syn.items():
            if champ in (a, b) and x.rg >= 3:
                other = b if a == champ else a
                exp = st.champ_long_rate(champ) + st.champ_long_rate(other) - 0.5
                syn.append((x.rate(prior=exp, k=10) - exp, other, x.record, x.rg))
        lanes.sort(reverse=True)
        syn.sort(reverse=True)
        return {
            "champ": champ, "role": role, "roles": roles, "presence": st.presence(champ),
            "pick": st.pick_rate(champ), "ban": st.ban_rate(champ), "record": wl.record,
            "recent_record": rec.record, "recent_n": rec.rg,
            "wr": (wl.w / wl.g) if wl.g else None, "games": st.raw_games.get((champ, role), 0),
            "blind_share": st.blind_share(champ, role),
            "best_lanes": lanes[:4], "worst_lanes": lanes[::-1][:4],
            "best_synergy": syn[:4],
            "length": {k: (v.record, (v.w / v.g) if v.g else None) for k, v in st.length_rates(champ).items()},
            "build": self.builds.for_champ(champ, role, opp=vs),
            "summary": st.summary(),
        }

    # what the enemy team's make-up asks for, matched with the "vs ..." notes on situational items
    FIT_NEEDS = {"vs AP threats": "mostly magic damage", "vs AD threats": "mostly physical damage",
                 "vs healing": "healing", "vs tanks": "tanks"}

    def my_build(self, champ, role=None, vs=None, enemies=()):
        """The build for the champion you're playing: pro runes, summoner spells, items in buying order
        and skill order (against your lane opponent when known), your pro record in that lane, and the
        situational items that fit this enemy team."""
        st, dd = self.stats, self.dd["champions"]
        roles = st.roles(champ)
        role = role if role in ROLES else (roles[0][0] if roles and roles[0][1] > 0 else None)
        if not role:
            return {"champ": champ, "error": f"No pro games for {champ} in the data."}
        bd = self.builds.for_champ(champ, role, opp=vs)
        res = {"champ": champ, "role": role, "vs": vs, "build": bd}
        if bd is None:
            res["error"] = f"No pro games for {champ} as {role} yet."
            return res
        if vs:
            x = st.lane_wl(champ, role, vs)
            res["lane"] = {"record": x.record, "games": x.rg} if x.rg else None
        enemies = [e for e in enemies if e]
        if enemies:
            ap = damage_profile(enemies, dd)["AP"]
            healers = [e for e in enemies if profile(e, dd)["traits"]["hl"] >= 2]
            tanks = [e for e in enemies if profile(e, dd)["class"] == "tank" or profile(e, dd)["traits"]["fl"] >= 3]
            need = {"vs AP threats": ap >= 0.55, "vs AD threats": ap <= 0.3,
                    "vs healing": len(healers) >= 2, "vs tanks": len(tanks) >= 2}
            res["enemy"] = {"ap": ap, "healers": healers, "tanks": tanks, "n": len(enemies)}
            res["fits"] = [{"item": s["item"], "why": self.FIT_NEEDS[s["note"]]}
                           for s in bd.get("situational") or [] if need.get(s.get("note"))]
        return res

    def ingame_context(self, ev, plans):
        """Everything the live in-game calculator needs: the pre-game logit, the comp tempo,
        the lab's minute models and a what-if table (gold lead at 15 / 20 min)."""
        ig = self.model.get("ingame") or {}
        models = (ig.get("models") or {}).get("state + draft")
        if not models:
            return None
        if "B" in plans:
            tempo = plans["B"]["tags"]["tempo_score"]
        elif "R" in plans:
            tempo = -plans["R"]["tags"]["tempo_score"]
        else:
            tempo = 0.0
        prior = ev.get("raw_logit", 0.0)
        gold_models = (ig.get("models") or {}).get("gold + draft")
        variant = "gold + draft" if gold_models else "state + draft"
        whatif = {}
        for m in (10, 15, 20, 25):
            whatif[str(m)] = {str(g): round(self.engine.ingame_prob(m, {"gold": g}, prior, tempo, variant), 4)
                              for g in (-3, -1.5, 0, 1.5, 3)}
        return {"prior": prior, "tempo": tempo, "features": ig.get("features"), "minutes": ig.get("minutes"),
                "models": models, "gold_models": gold_models, "whatif": whatif}

    # ----------------------------------------------------------------
    @staticmethod
    def _calibration(p_blue, model_key="draft"):
        """How often the favourite actually won at this confidence level in the walk-forward lab."""
        import json
        from . import DATA
        path = DATA / "lab_report.json"
        if not path.exists():
            return None
        with open(path, encoding="utf-8") as f:
            cal = json.load(f).get("calibration", {})
        name = {"draft": "draft", "players": "draft + players", "team": "team + draft"}.get(model_key, "draft")
        fav = max(p_blue, 1 - p_blue)
        label = next(l for lim, l in ((0.55, "50-55%"), (0.60, "55-60%"), (0.65, "60-65%"), (0.70, "65-70%"), (1.01, "70%+"))
                     if fav < lim)
        b = (cal.get(name) or {}).get(label)
        return {"bucket": label, "won": b["won"], "games": b["games"]} if b and b["games"] else None

    def _state(self, draft):
        out = {}
        for side in "BR":
            roles = self.engine.assign(draft.picks[side], (getattr(draft, "reserve", {}) or {}).get(side))
            out[side] = {
                "picks": [{"champ": c, "role": r} for r, c in sorted(roles.items(), key=lambda kv: ROLES.index(kv[0]))],
                "bans": list(draft.bans[side]),
                "team": draft.teams[side],
            }
        out["fearless"] = list(draft.fearless)
        out["fp_side"] = getattr(draft, "fp_side", None)
        return out


def parse_side(text):
    t = (text or "").strip().lower()
    if t in ("b", "blue", "fp", "first"):
        return "B"
    if t in ("r", "red", "sp", "second"):
        return "R"
    raise ValueError(f"side must be blue or red, got '{text}'")


__all__ = ["Advisor", "Draft", "SIDE_NAME", "OTHER", "parse_side"]
