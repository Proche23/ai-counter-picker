"""Model fitting shared by learn.py (daily re-fit) and the analysis tools.

Win model: logistic regression on per-game feature differences (first-pick side
minus the other side), fitted on one time window and scored on a later one it
never saw (walk-forward), so the reported accuracy is honest.
"""
import math
from collections import defaultdict

WIN_FEATURES = ["strength", "counter", "synergy", "comfort"]

# Shrinkage (pseudo-games pulling small samples toward 50%). Shared by the lab and the
# live engine so both always compute identical features; tuned values live in model.json.
# k_vs / k_syn tuned walk-forward (chosen on 2025 games, confirmed on 2026): matchup records
# are noisy, so they need heavier shrinkage and a longer memory (matchup half-life 240 days).
PARAMS = {"k_vs": 30.0, "k_syn": 8.0, "k_comfort": 6.0, "k_long": 20.0}


def set_params(params):
    for k, v in (params or {}).items():
        if k in PARAMS:
            PARAMS[k] = float(v)


def win_features(st, me, them):
    """me/them: {role: player-row dict}. Must match Engine.logit_blue exactly."""
    v = defaultdict(float)
    for r, p in me.items():
        c = p["champion"]
        v["strength"] += (0.5 * (st.strength_rate(c, r) - 0.5)
                          + 0.5 * (st.wr_long(c, r).rate(k=PARAMS["k_long"]) - 0.5))
        for q in them.values():
            v["counter"] += (st.vs_wl(c, q["champion"]).rate(k=PARAMS["k_vs"]) - 0.5) / 5.0
        for r2, p2 in me.items():
            if r2 > r:
                v["synergy"] += (st.syn_wl(c, p2["champion"]).rate(k=PARAMS["k_syn"]) - 0.5) / 2.0
        link = p["player_link"] or p["player"]
        pw = st.player_pool[link].get(c)
        v["comfort"] += (pw.rate(k=PARAMS["k_comfort"]) - 0.5) if pw else 0.0
    return v


def win_dataset(con, stats, start, end):
    """(X, y, game_ids): feature differences for every complete game in [start, end)."""
    games = [dict(r) for r in con.execute(
        "SELECT * FROM games WHERE date_utc >= ? AND date_utc < ? ORDER BY date_utc", (start, end))]
    players = defaultdict(list)
    for r in con.execute("SELECT p.* FROM players p JOIN games g USING(game_id) WHERE g.date_utc >= ? AND g.date_utc < ?",
                         (start, end)):
        players[r["game_id"]].append(dict(r))
    X, y, ids = [], [], []
    for g in games:
        sr = {s: {p["role"]: p for p in players[g["game_id"]] if p["draft_side"] == s} for s in "BR"}
        if any(len(sr[s]) != 5 for s in "BR"):
            continue
        fb, fr = win_features(stats, sr["B"], sr["R"]), win_features(stats, sr["R"], sr["B"])
        X.append([fb[f] - fr[f] for f in WIN_FEATURES])
        y.append(1 if (g["winner_side"] == "blue") == (g["blue_team"] == g["fp_team"]) else 0)
        ids.append(g["game_id"])
    return X, y, ids


def fit_logistic(X, y, idx, l2=1.0, iters=3000, lr=0.5):
    """Standardised gradient descent; returns raw-scale weights for features idx and the bias."""
    n = len(X)
    sd = [max(1e-9, (sum(x[i] ** 2 for x in X) / n) ** 0.5) for i in idx]
    w = [0.0] * len(idx)
    b = 0.0
    for _ in range(iters):
        gw = [0.0] * len(idx)
        gb = 0.0
        for x, t in zip(X, y):
            z = b + sum(w[j] * x[i] / sd[j] for j, i in enumerate(idx))
            p = 1.0 / (1.0 + math.exp(-z))
            for j, i in enumerate(idx):
                gw[j] += (p - t) * x[i] / sd[j]
            gb += p - t
        w = [w[j] - lr * (gw[j] / n + l2 * w[j] / n) for j in range(len(idx))]
        b -= lr * gb / n
    return [w[j] / sd[j] for j in range(len(idx))], b


def _invert(m):
    """Gauss-Jordan inverse of a small square matrix (list of lists)."""
    n = len(m)
    a = [row[:] + [1.0 if i == j else 0.0 for j in range(n)] for i, row in enumerate(m)]
    for col in range(n):
        piv = max(range(col, n), key=lambda r: abs(a[r][col]))
        if abs(a[piv][col]) < 1e-12:
            raise ValueError("singular matrix")
        a[col], a[piv] = a[piv], a[col]
        pv = a[col][col]
        a[col] = [v / pv for v in a[col]]
        for r in range(n):
            if r != col and a[r][col] != 0.0:
                f = a[r][col]
                a[r] = [vr - f * vc for vr, vc in zip(a[r], a[col])]
    return [row[n:] for row in a]


def fit_newton(X, y, idx, l2=1.0, iters=12, init=None, sw=None):
    """Regularised logistic regression by Newton's method (IRLS).

    sw: optional per-row weights (e.g. recency), so recent games count more.
    Returns (weights for features idx, bias, covariance of [bias]+weights on the raw scale).
    The covariance gives confidence intervals for any prediction: var(z) = x' C x.
    """
    n, k = len(X), len(idx)
    if n == 0:
        return [0.0] * k, 0.0, [[0.0] * (k + 1) for _ in range(k + 1)]
    sd = [max(1e-9, (sum(x[i] ** 2 for x in X) / n) ** 0.5) for i in idx]
    rows = [[1.0] + [x[i] / sd[j] for j, i in enumerate(idx)] for x in X]
    sw = sw or [1.0] * n
    theta = [0.0] * (k + 1)
    if init:
        theta = [init[1]] + [init[0][j] * sd[j] for j in range(k)]
    cov_std = None
    rng = range(k + 1)
    for _ in range(iters):
        grad = [0.0] * (k + 1)
        hess = [[0.0] * (k + 1) for _ in range(k + 1)]
        for r, t, s in zip(rows, y, sw):
            z = sum(a * b for a, b in zip(theta, r))
            p = 1.0 / (1.0 + math.exp(-max(-30.0, min(30.0, z))))
            wgt = s * p * (1.0 - p)
            g = s * (t - p)
            for a in rng:
                ra = r[a]
                grad[a] += g * ra
                ra *= wgt
                ha = hess[a]
                for b in range(a, k + 1):
                    ha[b] += ra * r[b]
        for a in range(k + 1):
            for b in range(a):
                hess[a][b] = hess[b][a]
        for a in range(1, k + 1):  # ridge on weights, not on the bias
            grad[a] -= l2 * theta[a]
            hess[a][a] += l2
        cov_std = _invert(hess)
        step = [sum(cov_std[a][b] * grad[b] for b in range(k + 1)) for a in range(k + 1)]
        theta = [t + s for t, s in zip(theta, step)]
        if max(abs(s) for s in step) < 1e-7:
            break
    scale = [1.0] + sd
    cov = [[cov_std[a][b] / (scale[a] * scale[b]) for b in range(k + 1)] for a in range(k + 1)]
    return [theta[j + 1] / sd[j] for j in range(k)], theta[0], cov


def predict_ci(x, idx, w, b, cov, zcrit=1.645):
    """P(win) and its 90% interval from the parameter covariance (delta method)."""
    xt = [1.0] + [x[i] for i in idx]
    z = b + sum(w[j] * x[i] for j, i in enumerate(idx))
    var = sum(xt[a] * cov[a][c] * xt[c] for a in range(len(xt)) for c in range(len(xt)))
    sdz = math.sqrt(max(var, 0.0))
    sig = lambda v: 1.0 / (1.0 + math.exp(-v))
    return sig(z), sig(z - zcrit * sdz), sig(z + zcrit * sdz)


def score_logistic(X, y, idx, w, b):
    acc = ll = br = 0.0
    for x, t in zip(X, y):
        z = b + sum(w[j] * x[i] for j, i in enumerate(idx))
        p = min(max(1.0 / (1.0 + math.exp(-z)), 1e-6), 1 - 1e-6)
        acc += (p > 0.5) == (t == 1)
        ll += -(t * math.log(p) + (1 - t) * math.log(1 - p))
        br += (p - t) ** 2
    n = max(1, len(y))
    return {"accuracy": acc / n, "logloss": ll / n, "brier": br / n, "games": len(y)}
