"""Riot Data Dragon: champion names/classes/ultimate names, items and runes."""
import json
import os
import urllib.request

from . import DD_DIR

DD = "https://ddragon.leagueoflegends.com"
UA = "pro-draft-stats/0.1 (python-urllib)"  # generic client name


def _get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=120) as resp:
        return json.loads(resp.read().decode("utf-8"))


def ensure_latest(verbose=True):
    """Download (once per patch) a compact copy of the Data Dragon files we use."""
    os.makedirs(DD_DIR, exist_ok=True)
    try:
        version = _get_json(f"{DD}/api/versions.json")[0]
    except Exception as exc:  # offline: fall back to whatever is cached
        cached = latest_cached()
        if cached:
            if verbose:
                print(f"  Data Dragon unreachable ({exc}); using cached {cached}")
            return cached
        raise
    vdir = DD_DIR / version
    if (vdir / "champions.json").exists() and (vdir / "items.json").exists():
        if not (vdir / "spells.json").exists():
            _save_spells(version, vdir)
        if not (vdir / "item_ids.json").exists():  # caches from before item ids were kept
            _save_items(version, vdir)
        return version
    os.makedirs(vdir, exist_ok=True)
    if verbose:
        print(f"  Data Dragon {version}: downloading champions, items, runes")
    full = _get_json(f"{DD}/cdn/{version}/data/en_US/championFull.json")["data"]
    champs = {}
    for cid, c in full.items():
        spells = [s.get("name", "") for s in c.get("spells", [])]
        champs[c["name"]] = {
            "id": cid,
            "key": c.get("key"),
            "name": c["name"],
            "title": c.get("title", ""),
            "tags": c.get("tags", []),
            "info": c.get("info", {}),
            "partype": c.get("partype", ""),
            "range": (c.get("stats") or {}).get("attackrange", 0),
            "spells": spells,
            "passive": (c.get("passive") or {}).get("name", ""),
        }
    runes = _get_json(f"{DD}/cdn/{version}/data/en_US/runesReforged.json")
    with open(vdir / "champions.json", "w", encoding="utf-8") as f:
        json.dump(champs, f, ensure_ascii=False, indent=1)
    _save_items(version, vdir)
    with open(vdir / "runes.json", "w", encoding="utf-8") as f:
        json.dump(runes, f, ensure_ascii=False, indent=1)
    _save_spells(version, vdir)
    with open(DD_DIR / "latest.txt", "w", encoding="utf-8") as f:
        f.write(version)
    return version


def _save_items(version, vdir):
    """items.json: name -> the Summoner's Rift item. Game modes reuse names under other ids
    (Thornmail is 3075 on the Rift, 223075 in Arena, 323075 in another mode), so the lowest
    Rift id is the real one. item_ids.json: every id -> name, for naming purchases in timelines."""
    items_raw = _get_json(f"{DD}/cdn/{version}/data/en_US/item.json")["data"]
    items, ids = {}, {}
    for iid, it in sorted(items_raw.items(), key=lambda kv: int(kv[0]) if kv[0].isdigit() else 10 ** 9):
        name = it.get("name", "").strip()
        if not name:
            continue
        ids[iid] = name
        maps = it.get("maps", {})
        if maps and not maps.get("11", False):  # Summoner's Rift only
            continue
        if name in items:
            continue
        items[name] = {
            "id": iid,
            "gold": (it.get("gold") or {}).get("total", 0),
            "into": it.get("into", []),
            "from": it.get("from", []),
            "tags": it.get("tags", []),
            "depth": it.get("depth", 1),
            "consumed": bool(it.get("consumed")),
        }
    with open(vdir / "items.json", "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=1)
    with open(vdir / "item_ids.json", "w", encoding="utf-8") as f:
        json.dump(ids, f, ensure_ascii=False, indent=0)


def _save_spells(version, vdir):
    """Summoner spell name -> icon file, for the website."""
    try:
        raw = _get_json(f"{DD}/cdn/{version}/data/en_US/summoner.json")["data"]
    except Exception:
        return
    spells = {s["name"]: s["image"]["full"] for s in raw.values() if "CLASSIC" in s.get("modes", [])}
    with open(vdir / "spells.json", "w", encoding="utf-8") as f:
        json.dump(spells, f, ensure_ascii=False, indent=1)


def latest_cached():
    p = DD_DIR / "latest.txt"
    if p.exists():
        v = p.read_text(encoding="utf-8").strip()
        if (DD_DIR / v / "champions.json").exists():
            return v
    return None


def load(version=None):
    version = version or latest_cached()
    if not version:
        raise RuntimeError("No Data Dragon cache yet - run: py update.py")
    vdir = DD_DIR / version
    with open(vdir / "champions.json", encoding="utf-8") as f:
        champs = json.load(f)
    with open(vdir / "items.json", encoding="utf-8") as f:
        items = json.load(f)
    with open(vdir / "runes.json", encoding="utf-8") as f:
        runes = json.load(f)
    spells, item_ids = {}, {}
    if (vdir / "spells.json").exists():
        with open(vdir / "spells.json", encoding="utf-8") as f:
            spells = json.load(f)
    if (vdir / "item_ids.json").exists():
        with open(vdir / "item_ids.json", encoding="utf-8") as f:
            item_ids = json.load(f)
    return {"version": version, "champions": champs, "items": items, "runes": runes, "spells": spells,
            "item_ids": item_ids}
