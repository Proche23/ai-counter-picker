"""Champion knowledge base: what each champion *does* inside a pro composition.

Pro statistics say which champions win; this table says *why*, so the engine
can build a coherent comp and explain the game plan. Trait levels are 1-3.

  en engage      start fights on your terms        pk pick       catch one target
  po poke        long-range chip damage            pe peel       protect carries / disengage
  fl frontline   absorb damage, hold space         tf teamfight  multi-target AoE impact
  sk skirmish    2v2 / 3v3 / duel strength         sp splitpush  side-lane 1v1 + tower pressure
  wc waveclear   clear waves fast, stall sieges    dv dive       reach the backline
  hc hypercarry  late-game damage scaling          cc lockdown   reliable crowd control
  ro roam        early map pressure / TP-ult plays si siege      take towers, zone under turret
  hl sustain     heavy healing (anti-heal check)   mb mobility   dashes / escape
  bu burst       one-combo kill threat

curve = early, mid, late power on a 1-5 scale.
Champions missing here (e.g. released after this table) fall back to Data Dragon class tags.
Locke and Zaahen were added from their Data Dragon kit text plus their pro builds
(Locke: AP Electrocute assassin mid; Zaahen: AD Grasp/Conqueror bruiser top) - refine as they settle.
selftest.py lists any champion in the pro data that is still missing here.
"""

KB_TEXT = """
Aatrox        | AD  | M | fighter    | fl2 sk3 tf2 hl3 dv1 cc1        | 4,4,3
Ahri          | AP  | R | mage       | pk3 mb3 bu2 ro2 wc2 cc1 dv1    | 3,4,3
Akali         | AP  | M | assassin   | dv3 bu3 mb3 sk2 sp1            | 3,4,3
Akshan        | AD  | R | marksman   | sk2 ro2 pk1 mb2 sp1            | 3,4,3
Alistar       | AP  | M | tank       | en3 pe3 cc3 fl2 ro1            | 3,4,3
Ambessa       | AD  | M | fighter    | dv3 sk3 mb2 en2 sp2 fl1        | 4,4,3
Amumu         | AP  | M | tank       | en3 tf3 cc3 fl2                | 2,4,4
Anivia        | AP  | R | mage       | wc3 tf2 pe2 si2 cc2            | 2,3,5
Annie         | AP  | R | mage       | en2 bu3 tf2 cc2                | 3,4,3
Aphelios      | AD  | R | marksman   | tf2 hc3                        | 2,3,5
Ashe          | AD  | R | marksman   | pk2 en2 cc2 pe1 po1            | 3,3,4
Aurelion Sol  | AP  | R | mage       | tf3 wc2 hc3 po1                | 1,3,5
Aurora        | AP  | R | mage       | mb2 tf2 bu2 sk2 pk1 sp1        | 3,4,3
Azir          | AP  | R | mage       | si3 wc2 tf2 pe2 hc2 en1        | 2,4,5
Bard          | AP  | R | catcher    | pk2 ro3 pe2 cc2 en1            | 3,4,3
Bel'Veth      | AD  | M | fighter    | sk3 hc2 sp1                    | 2,4,4
Blitzcrank    | AP  | M | catcher    | pk3 cc2 en1                    | 3,3,2
Brand         | AP  | R | mage       | tf3 po2 bu1                    | 3,3,4
Braum         | AP  | M | tank       | pe3 fl2 cc2                    | 3,3,3
Briar         | AD  | M | fighter    | dv2 sk3 hl2 en2                | 4,4,2
Caitlyn       | AD  | R | marksman   | po2 si3                        | 4,3,4
Camille       | AD  | M | fighter    | dv3 sp3 pk2 sk2                | 3,4,4
Cassiopeia    | AP  | R | mage       | tf2 sk2 cc2 hc2                | 3,4,4
Cho'Gath      | AP  | M | tank       | fl3 cc2 hc1                    | 2,3,4
Corki         | MIX | R | marksman   | po3 si2 hc1                    | 2,4,4
Darius        | AD  | M | fighter    | sk3 fl2 tf2                    | 4,4,2
Diana         | AP  | M | assassin   | en2 dv3 tf2 bu2                | 3,4,3
Dr. Mundo     | AP  | M | tank       | fl3 hl2 sp1                    | 2,3,4
Draven        | AD  | R | marksman   | sk3 bu1                        | 5,4,3
Ekko          | AP  | M | assassin   | dv2 bu2 mb2 sk2 ro2            | 3,4,3
Elise         | AP  | R | assassin   | pk2 dv2 bu2 cc1                | 4,3,2
Evelynn       | AP  | M | assassin   | pk2 bu3 ro2                    | 2,4,3
Ezreal        | AD  | R | marksman   | po3 mb3                        | 3,3,4
Fiddlesticks  | AP  | R | mage       | en3 tf3 cc2                    | 2,4,3
Fiora         | AD  | M | fighter    | sp3 sk3 hc2                    | 3,4,4
Fizz          | AP  | M | assassin   | bu3 dv2 mb2                    | 3,4,3
Galio         | AP  | M | tank       | en2 pe2 tf2 ro3 fl2 cc2        | 3,4,3
Gangplank     | AD  | M | specialist | tf2 si2 sp2 hc2 po1            | 2,4,4
Garen         | AD  | M | fighter    | sk2 fl2 sp1                    | 3,3,3
Gnar          | AD  | R | fighter    | tf2 fl2 en2 cc2 sp1            | 3,4,3
Gragas        | AP  | M | tank       | en2 pe2 cc2 fl1 bu1            | 3,4,3
Graves        | AD  | R | marksman   | sk3 bu2                        | 4,4,3
Gwen          | AP  | M | fighter    | sp3 sk2 hc2 tf1                | 2,4,4
Hecarim       | AD  | M | fighter    | en3 dv3 tf1 mb2                | 3,4,3
Heimerdinger  | AP  | R | mage       | si2 po2 wc2                    | 4,3,2
Hwei          | AP  | R | mage       | po3 tf2 pk2 wc3                | 2,4,4
Illaoi        | AD  | M | fighter    | sp2 sk2 tf1 hl2                | 3,4,3
Irelia        | AD  | M | fighter    | sk3 dv2 sp2                    | 4,4,3
Ivern         | AP  | R | enchanter  | pe2 cc1                        | 3,3,3
Janna         | AP  | R | enchanter  | pe3 cc2                        | 2,3,3
Jarvan IV     | AD  | M | fighter    | en3 dv2 tf2 fl1 cc2            | 4,4,2
Jax           | AD  | M | fighter    | sp3 sk3 dv2                    | 3,4,4
Jayce         | AD  | R | fighter    | po3 si2 sk1                    | 4,4,2
Jhin          | AD  | R | marksman   | pk2 po1 cc1                    | 3,4,3
Jinx          | AD  | R | marksman   | hc3 tf2 wc2                    | 2,3,5
K'Sante       | AD  | M | tank       | fl3 pe2 dv1 sk2 cc2            | 3,4,4
Kai'Sa        | MIX | R | marksman   | dv2 hc2 bu1                    | 3,3,4
Kalista       | AD  | R | marksman   | sk2 en1                        | 4,4,2
Karma         | AP  | R | enchanter  | po2 pe2                        | 3,3,2
Karthus       | AP  | R | mage       | tf3 hc2                        | 2,4,4
Kassadin      | AP  | M | assassin   | hc3 mb3 bu2                    | 1,3,5
Katarina      | AP  | M | assassin   | tf2 bu3 mb2                    | 3,4,3
Kayle         | MIX | R | specialist | hc3 sp2                        | 1,3,5
Kayn          | AD  | M | fighter    | dv2 sk2                        | 2,4,3
Kennen        | AP  | R | mage       | en3 tf3 cc2                    | 3,4,3
Kha'Zix       | AD  | M | assassin   | pk3 bu3                        | 3,4,3
Kindred       | AD  | R | marksman   | sk2 pe1 hc2                    | 3,4,4
Kled          | AD  | M | fighter    | en2 sk3 dv2                    | 4,4,2
Kog'Maw       | MIX | R | marksman   | hc3                            | 2,3,5
LeBlanc       | AP  | R | assassin   | pk3 bu3 mb3                    | 3,4,2
Lee Sin       | AD  | M | fighter    | pk2 sk2 dv2 mb2 en1            | 4,3,2
Leona         | AP  | M | tank       | en3 cc3 fl2                    | 4,3,2
Lillia        | AP  | M | mage       | tf2 cc2 sk2 mb2                | 3,4,4
Lissandra     | AP  | R | mage       | en2 pe2 cc3 tf2                | 3,4,3
Locke         | AP  | M | assassin   | pk2 bu3 mb2 dv2 ro2 sk1        | 3,4,3
Lucian        | AD  | R | marksman   | sk3 bu2                        | 4,4,2
Lulu          | AP  | R | enchanter  | pe3                            | 3,3,4
Lux           | AP  | R | mage       | pk2 po2 bu2                    | 3,3,3
Malphite      | AP  | M | tank       | en3 tf3 fl2                    | 2,4,4
Malzahar      | AP  | R | mage       | pk2 wc3 cc2                    | 2,4,3
Maokai        | AP  | M | tank       | en2 pe2 cc2 fl3 tf2            | 3,4,3
Master Yi     | AD  | M | fighter    | hc3 sk2                        | 2,3,5
Mel           | AP  | R | mage       | po3 tf2 pe1 bu2                | 3,4,4
Milio         | AP  | R | enchanter  | pe3                            | 2,3,4
Miss Fortune  | AD  | R | marksman   | tf3 po1                        | 4,3,3
Mordekaiser   | AP  | M | fighter    | sk3 fl2                        | 3,4,4
Morgana       | AP  | R | catcher    | pk2 pe2 cc2                    | 3,3,3
Naafiri       | AD  | M | assassin   | bu3 ro2 pk2                    | 4,4,2
Nami          | AP  | R | enchanter  | pe2 cc2 en1                    | 3,3,3
Nasus         | AD  | M | fighter    | sp3 fl2                        | 1,3,5
Nautilus      | AP  | M | tank       | en3 pk2 cc3 fl2                | 4,3,3
Neeko         | AP  | R | mage       | en2 tf2 pk1 cc2                | 3,4,3
Nidalee       | AP  | R | assassin   | po2 pk2 sk2                    | 4,3,2
Nilah         | AD  | M | marksman   | tf2 sk2 hc2                    | 3,4,4
Nocturne      | AD  | M | assassin   | dv3 pk2 en2                    | 3,4,3
Nunu & Willump| AP  | M | tank       | en2 pk2 cc2 fl2                | 3,4,3
Olaf          | AD  | M | fighter    | dv2 sk3 fl1                    | 4,4,2
Orianna       | AP  | R | mage       | tf3 pe2 wc3 en1 cc2            | 2,4,4
Ornn          | MIX | M | tank       | en3 fl3 tf2 cc2                | 2,4,5
Pantheon      | AD  | M | fighter    | en2 dv2 ro3 bu2                | 5,3,2
Poppy         | AD  | M | tank       | pe3 fl2 cc2                    | 3,3,3
Pyke          | AD  | M | catcher    | pk3 ro3 bu2                    | 3,4,2
Qiyana        | AD  | M | assassin   | en2 tf2 bu3                    | 3,4,3
Quinn         | AD  | R | marksman   | sk2 ro3 sp2                    | 4,3,2
Rakan         | AP  | R | catcher    | en3 pe2 cc2 mb3                | 3,4,3
Rammus        | AP  | M | tank       | en2 fl2 cc2                    | 2,3,3
Rek'Sai       | AD  | M | fighter    | pk2 dv2 sk2 en1                | 4,3,2
Rell          | AP  | M | tank       | en3 cc3 fl2 tf2                | 3,4,3
Renata Glasc  | AP  | R | enchanter  | pe3 tf2                        | 3,3,4
Renekton      | AD  | M | fighter    | dv2 sk3 fl2                    | 5,3,2
Rengar        | AD  | M | assassin   | pk3 bu3                        | 3,4,3
Riven         | AD  | M | fighter    | sk3 dv2 sp2                    | 3,4,3
Rumble        | AP  | M | fighter    | tf3 sk2 fl1                    | 4,4,3
Ryze          | AP  | R | mage       | sk2 wc2 hc2                    | 2,4,4
Samira        | AD  | R | marksman   | tf2 dv2 bu2                    | 3,4,3
Sejuani       | AP  | M | tank       | en3 fl3 cc3 tf2                | 3,4,3
Senna         | AD  | R | enchanter  | po2 pe1 hc2                    | 2,3,4
Seraphine     | AP  | R | enchanter  | tf2 pe2 po1 cc1                | 2,3,4
Sett          | AD  | M | fighter    | sk3 fl2 en1                    | 4,4,2
Shaco         | AD  | M | assassin   | pk2 bu2                        | 4,3,2
Shen          | MIX | M | tank       | pe2 en2 fl2 sp2 ro3            | 3,3,3
Shyvana       | MIX | M | fighter    | tf2 sk2                        | 2,4,4
Singed        | AP  | M | tank       | sp2 fl2                        | 2,3,4
Sion          | AD  | M | tank       | en2 fl3 sp2                    | 2,3,4
Sivir         | AD  | R | marksman   | wc3 en1 tf2                    | 2,3,4
Skarner       | AD  | M | tank       | en3 pk2 cc3 fl2                | 3,4,3
Smolder       | AD  | R | marksman   | hc3 po1 wc2                    | 2,3,5
Sona          | AP  | R | enchanter  | pe2 tf2                        | 2,3,4
Soraka        | AP  | R | enchanter  | pe2 hl3                        | 2,3,3
Swain         | AP  | R | mage       | tf2 fl1 cc2 hl2                | 3,4,3
Sylas         | AP  | M | assassin   | sk2 dv2 tf2 hl2                | 3,4,3
Syndra        | AP  | R | mage       | bu3 pk2 pe1 wc2                | 3,4,3
Tahm Kench    | AP  | M | tank       | pe3 fl2                        | 3,3,3
Taliyah       | AP  | R | mage       | ro3 wc2 tf1 pk2                | 3,4,3
Talon         | AD  | M | assassin   | ro3 bu3 mb2                    | 4,4,2
Taric         | AP  | M | enchanter  | pe2 tf2 fl1 cc1                | 2,3,4
Teemo         | AP  | R | specialist | sp1 sk1                        | 3,3,3
Thresh        | AP  | R | catcher    | pk3 pe2 cc2 en2                | 3,3,3
Tristana      | AD  | R | marksman   | si2 dv1 bu1 hc2                | 3,3,4
Trundle       | AD  | M | fighter    | sp2 sk2 fl1                    | 3,4,3
Tryndamere    | AD  | M | fighter    | sp3 sk2 hc2                    | 2,4,4
Twisted Fate  | AP  | R | mage       | ro3 pk2 sp1 wc2                | 2,4,3
Twitch        | AD  | R | marksman   | hc2 tf2                        | 2,3,4
Udyr          | MIX | M | fighter    | sk2 fl1                        | 3,4,3
Urgot         | AD  | R | fighter    | sk2 fl2 sp1                    | 3,4,3
Varus         | AD  | R | marksman   | po3 pk2 cc2                    | 3,3,3
Vayne         | AD  | R | marksman   | hc3 sk2 sp1                    | 2,3,5
Veigar        | AP  | R | mage       | hc2 cc2 bu2                    | 1,3,5
Vel'Koz       | AP  | R | mage       | po3 bu1                        | 2,3,4
Vex           | AP  | R | mage       | en1 pe2 bu2 pk1                | 3,4,3
Vi            | AD  | M | fighter    | en2 pk3 dv3 cc2                | 3,4,3
Viego         | AD  | M | fighter    | sk3 tf1                        | 3,4,3
Viktor        | AP  | R | mage       | wc3 tf2 hc2 po1                | 2,4,4
Vladimir      | AP  | R | mage       | tf2 hl3 hc2                    | 2,3,5
Volibear      | MIX | M | fighter    | dv2 fl2 sk2                    | 4,4,2
Warwick       | AD  | M | fighter    | sk2 pk1 hl2 dv1                | 4,3,2
Wukong        | AD  | M | fighter    | en3 tf3 fl1 dv2                | 3,4,3
Xayah         | AD  | R | marksman   | pe1 tf1 hc2                    | 2,3,4
Xerath        | AP  | R | mage       | po3 si2 pk1                    | 2,3,4
Xin Zhao      | AD  | M | fighter    | en2 sk3 dv2                    | 4,4,2
Yasuo         | AD  | M | fighter    | tf2 sk2 hc1                    | 3,3,4
Yone          | AD  | M | fighter    | en2 tf2 sk2 hc2                | 2,4,4
Yorick        | AD  | M | fighter    | sp3 si2                        | 3,3,4
Yuumi         | AP  | R | enchanter  | pe2 hl2                        | 1,3,4
Yunara        | AD  | R | marksman   | hc3                            | 2,3,5
Zaahen        | AD  | M | fighter    | sk3 fl2 hl2 dv2 cc1 en1 sp1    | 3,4,3
Zac           | AP  | M | tank       | en3 fl3 tf2 cc2                | 3,4,3
Zed           | AD  | M | assassin   | bu3 sp2 pk2 mb2                | 3,4,3
Zeri          | AD  | R | marksman   | hc2 mb2                        | 2,3,4
Ziggs         | AP  | R | mage       | po3 si3 wc3                    | 3,3,4
Zilean        | AP  | R | enchanter  | pe3                            | 2,3,4
Zoe           | AP  | R | mage       | po2 pk3 bu3                    | 3,4,3
Zyra          | AP  | R | mage       | tf2 po2 cc2                    | 3,4,3
"""

TRAITS = ["en", "pk", "po", "pe", "fl", "tf", "sk", "sp", "wc", "dv", "hc", "cc", "ro", "si", "hl", "mb", "bu"]

# How much of a team's damage profile a champion of this class represents.
DAMAGE_WEIGHT = {"tank": 0.3, "enchanter": 0.3, "catcher": 0.4, "fighter": 0.8,
                 "specialist": 0.9, "assassin": 1.0, "mage": 1.0, "marksman": 1.0}

# Archetypes a composition can be built around. Weights over traits.
ARCHETYPES = {
    "engage":    {"en": 1.0, "dv": 0.6, "cc": 0.3, "tf": 0.3},
    "teamfight": {"tf": 1.0, "fl": 0.6, "cc": 0.3, "pe": 0.3, "hc": 0.3},
    "pick":      {"pk": 1.0, "bu": 0.4, "mb": 0.3, "ro": 0.3, "cc": 0.2},
    "poke":      {"po": 1.0, "si": 0.7, "wc": 0.4, "pe": 0.3},
    "split":     {"sp": 1.0, "sk": 0.3, "wc": 0.2},
    "protect":   {},   # special: sqrt(hypercarry * peel)
    "skirmish":  {"sk": 0.8, "ro": 0.4, "dv": 0.3},
}

ARCHETYPE_LABEL = {
    "engage": "Hard engage / dive",
    "teamfight": "Front-to-back teamfight",
    "pick": "Pick / catch",
    "poke": "Poke & siege",
    "split": "Split push (1-3-1 / 1-4)",
    "protect": "Protect the carry",
    "skirmish": "Early skirmish & snowball",
}

_FALLBACK_BY_TAG = {
    "Tank": ("AP", "M", "tank", {"fl": 3, "en": 2, "cc": 2}, (3, 3, 3)),
    "Fighter": ("AD", "M", "fighter", {"sk": 2, "fl": 1, "dv": 1}, (3, 4, 3)),
    "Assassin": ("AD", "M", "assassin", {"bu": 3, "pk": 2, "mb": 2}, (3, 4, 3)),
    "Mage": ("AP", "R", "mage", {"tf": 2, "wc": 2, "po": 1}, (3, 3, 4)),
    "Marksman": ("AD", "R", "marksman", {"hc": 2}, (3, 3, 4)),
    "Support": ("AP", "R", "enchanter", {"pe": 2, "cc": 1}, (3, 3, 3)),
}


def _parse():
    table = {}
    for line in KB_TEXT.strip().splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        name, dmg, rng, cls, traits, curve = [p.strip() for p in line.split("|")]
        tr = {t: 0 for t in TRAITS}
        for tok in traits.split():
            tr[tok[:2]] = int(tok[2:])
        table[name] = {
            "name": name, "dmg": dmg, "range": rng, "class": cls, "traits": tr,
            "curve": tuple(int(x) for x in curve.split(",")), "curated": True,
        }
    return table


KB = _parse()


def profile(name, ddragon_champs=None):
    """Knowledge-base entry for a champion, with a Data Dragon fallback."""
    if name in KB:
        return KB[name]
    rec = (ddragon_champs or {}).get(name, {})
    tags = rec.get("tags") or ["Fighter"]
    dmg, rng, cls, traits, curve = _FALLBACK_BY_TAG.get(tags[0], _FALLBACK_BY_TAG["Fighter"])
    info = rec.get("info") or {}
    if info:
        dmg = "AP" if info.get("magic", 0) > info.get("attack", 0) else "AD"
    if rec.get("range"):
        rng = "R" if rec["range"] > 250 else "M"
    tr = {t: 0 for t in TRAITS}
    tr.update(traits)
    entry = {"name": name, "dmg": dmg, "range": rng, "class": cls, "traits": tr,
             "curve": curve, "curated": False}
    KB[name] = entry
    return entry


def archetype_scores(champs, ddragon_champs=None):
    """Raw archetype scores for a list of champion names."""
    profs = [profile(c, ddragon_champs) for c in champs]
    sums = {t: sum(p["traits"][t] for p in profs) for t in TRAITS}
    scores = {}
    for arch, weights in ARCHETYPES.items():
        if arch == "protect":
            hc = max((p["traits"]["hc"] for p in profs), default=0)
            scores[arch] = (hc * (sums["pe"] + 0.5 * sums["fl"])) ** 0.5
        elif arch == "split":
            best = max((p["traits"]["sp"] for p in profs), default=0)
            scores[arch] = best * 1.4 + 0.3 * (sums["sp"] - best) + 0.3 * sums["sk"] + 0.2 * sums["wc"]
        else:
            scores[arch] = sum(w * sums[t] for t, w in weights.items())
    return scores


def damage_profile(champs, ddragon_champs=None):
    """Share of AD / AP damage, weighted by how much each class actually deals."""
    ad = ap = 0.0
    for c in champs:
        p = profile(c, ddragon_champs)
        w = DAMAGE_WEIGHT.get(p["class"], 0.8)
        if p["dmg"] == "AD":
            ad += w
        elif p["dmg"] == "AP":
            ap += w
        else:
            ad += w / 2
            ap += w / 2
    total = ad + ap or 1.0
    return {"AD": ad / total, "AP": ap / total, "weight": ad + ap}


def curve_sum(champs, ddragon_champs=None):
    profs = [profile(c, ddragon_champs) for c in champs]
    return tuple(sum(p["curve"][i] for p in profs) for i in range(3))
