"""Draft engine: for any draft state, rank picks/bans from pro evidence.

Core = a win model fitted on real 2026 pro games (logistic regression,
validated on later games it never saw - see learn.py / data/model.json):

  logit(first-pick side wins) = bias
      + w_strength * sum(champion pro win-rate edge)          (per side, B minus R)
      + w_counter  * sum over every B-vs-R champion pair of their head-to-head record
      + w_synergy  * sum over ally pairs of their record together
      + w_comfort  * sum(each player's own pro record on the champion)   (when teams are known)

A candidate pick is scored by how much it raises your win probability under
that model. Enemy slots that aren't picked yet are filled with the enemy's
*predicted* picks (EnemyPredictor) so counters account for what they will
likely take. Smaller draft-logic terms (pro priority, role fit, comp fit,
blind-pick safety, flex, denial) break ties the way pro drafters would.
"""
import copy
import itertools
import json
import math

from . import DATA, ROLES
from .db import DRAFT_SEQUENCE
from .kb import ARCHETYPE_LABEL, damage_profile, profile
from .learning import PARAMS, set_params

OTHER = {"B": "R", "R": "B"}
SIDE_NAME = {"B": "Blue", "R": "Red"}

# Weights fitted on 1,135 2026 pro games (two time windows, each tested on the other).
DEFAULT_MODEL = {
    "draft": {"bias": -0.044, "strength": 0.159, "counter": 0.871, "synergy": 0.724, "comfort": 0.0},
    "players": {"bias": -0.079, "strength": 0.0, "counter": 0.888, "synergy": 0.581, "comfort": 1.215},
    "info": {"games": 1135, "oos_accuracy": {"draft": 0.554, "players": 0.582}, "fitted": "2026-11-19"},
}

# Traits that answer each enemy comp identity.
COUNTER_TRAITS = {
    "engage": {"pe": 1.0, "fl": 0.4, "cc": 0.3, "po": 0.2},
    "teamfight": {"pk": 0.6, "sp": 0.5, "po": 0.4, "en": 0.2},
    "pick": {"pe": 0.6, "fl": 0.4, "en": 0.4, "cc": 0.2},
    "poke": {"en": 0.8, "dv": 0.6, "hl": 0.3, "mb": 0.2},
    "split": {"sp": 0.6, "wc": 0.5, "pk": 0.4, "en": 0.3},
    "protect": {"dv": 0.7, "pk": 0.5, "po": 0.4},
    "skirmish": {"pe": 0.5, "wc": 0.4, "fl": 0.3, "sk": 0.4},
}

DEFAULT_ROLES = {  # role prior for champions with no pro games
    "marksman": {"BOT": 0.85, "MID": 0.1, "TOP": 0.05},
    "enchanter": {"SUP": 0.9, "MID": 0.1},
    "catcher": {"SUP": 0.9, "JNG": 0.1},
    "tank": {"TOP": 0.35, "JNG": 0.35, "SUP": 0.3},
    "mage": {"MID": 0.7, "SUP": 0.2, "BOT": 0.1},
    "assassin": {"MID": 0.55, "JNG": 0.4, "TOP": 0.05},
    "fighter": {"TOP": 0.55, "JNG": 0.4, "MID": 0.05},
    "specialist": {"TOP": 0.6, "MID": 0.3, "BOT": 0.1},
}


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def sigmoid(z):
    return 1.0 / (1.0 + math.exp(-z))


def load_model():
    path = DATA / "model.json"
    if path.exists():
        try:
            with open(path, encoding="utf-8") as f:
                m = json.load(f)
            if "draft" in m and "players" in m:
                return m
        except (OSError, ValueError):
            pass
    return DEFAULT_MODEL


class Draft:
    def __init__(self, blue=(), red=(), blue_bans=(), red_bans=(), fearless=(),
                 blue_team=None, red_team=None, skip_bans=False, fp_side=None, reserve=None):
        self.reserve = dict(reserve or {})   # {side: role} kept free for a solo-queue player who hasn't picked yet
        self.picks = {"B": list(blue), "R": list(red)}   # [(champ, role or None)]
        self.bans = {"B": list(blue_bans), "R": list(red_bans)}
        self.fearless = list(fearless)
        self.teams = {"B": blue_team, "R": red_team}
        self.skip_bans = skip_bans
        self.fp_side = fp_side  # map side of the first-pick team: "blue", "red" or None

    def copy_with_pick(self, side, champ, role):
        d = copy.deepcopy(self)
        d.picks[side].append((champ, role))
        return d

    def unavailable(self):
        s = set(self.fearless)
        for side in "BR":
            s |= {c for c, _ in self.picks[side]}
            s |= set(self.bans[side])
        return s

    def next_action(self):
        counts = {s: {"ban": len(self.bans[s]), "pick": len(self.picks[s])} for s in "BR"}
        steps = list(enumerate(DRAFT_SEQUENCE, 1))
        done = [counts[side][act] >= n for _, (side, act, n) in steps]
        # picks entered but no bans at all -> the user is skipping bans
        skip = self.skip_bans or (not any(self.bans.values()) and any(self.picks.values()))
        for i, (_, (side, act, n)) in enumerate(steps):
            if act == "ban" and not done[i]:
                later_pick = any(done[j] and steps[j][1][1] == "pick" for j in range(i + 1, len(steps)))
                if skip or later_pick:
                    done[i] = True  # bans not entered: don't block on them
        for i, (seq, (side, act, n)) in enumerate(steps):
            if not done[i]:
                nxt = steps[i + 1][1] if i + 1 < len(steps) else None
                double = bool(nxt and act == "pick" and nxt[0] == side and nxt[1] == "pick" and not done[i + 1])
                return {"seq": seq, "side": side, "action": act, "n": n, "double": double}
        return None


class Engine:
    def __init__(self, stats, builds, dd_champs, model=None, predictor=None):
        self.s = stats
        self.b = builds
        self.dd = dd_champs
        self.model = model or load_model()
        set_params(self.model.get("params"))  # tuned shrinkage from the lab, if any
        self.predictor = predictor
        self._cache = {}

    # -------------------------------------------------------------- roles
    def role_prob(self, c, r):
        if sum(self.s.role_long.get((c, rr), 0.0) for rr in ROLES) > 0:
            return max(self.s.role_share(c, r), 0.003)
        cls = profile(c, self.dd)["class"]
        return max(DEFAULT_ROLES.get(cls, {}).get(r, 0.02), 0.003)

    def assign(self, picks, reserve=None):
        """[(champ, role|None)] -> {role: champ}, most likely assignment given pro role data.
        reserve: a role the champions without a role shouldn't take (solo queue: yours, before you pick)."""
        fixed, free = {}, []
        for c, r in picks:
            if r and r not in fixed:
                fixed[r] = c
            else:
                free.append(c)
        open_roles = [r for r in ROLES if r not in fixed]
        if len(free) > len(open_roles):
            raise ValueError("more than five champions on one team")
        if reserve in open_roles and len(free) < len(open_roles):
            open_roles.remove(reserve)
        best, best_score = {}, -1e18
        for perm in itertools.permutations(open_roles, len(free)):
            sc = sum(math.log(self.role_prob(c, r)) for c, r in zip(free, perm))
            if sc > best_score:
                best_score, best = sc, dict(zip(perm, free))
        out = dict(fixed)
        out.update(best)
        return out

    # ------------------------------------------------------- win model
    def elo_rating(self, team):
        return ((self.model.get("elo") or {}).get("ratings") or {}).get(team) if team else None

    def elo_feature(self, team_b, team_r):
        rb, rr = self.elo_rating(team_b), self.elo_rating(team_r)
        if rb is None or rr is None:
            return 0.0
        return (rb - rr) / 400.0 * math.log(10)

    def model_key(self, team_b, team_r):
        if (team_b and team_r and "team" in self.model
                and self.elo_rating(team_b) is not None and self.elo_rating(team_r) is not None):
            return "team"
        return "players" if (team_b or team_r) else "draft"

    def weights(self, team_b, team_r):
        return self.model[self.model_key(team_b, team_r)]

    def calibration(self, key):
        """(a, c): calibrated logit = c + a * raw logit, fitted by the lab on unseen games."""
        cal = (self.model.get("calibration") or {}).get(key)
        return (cal[0], cal[1]) if cal else (1.0, 0.0)

    def side_feature(self, fp_side):
        """+1 if the first-pick team plays on blue side, -1 on red; unknown = recent pro average."""
        if fp_side == "blue":
            return 1.0
        if fp_side == "red":
            return -1.0
        return float(self.model.get("side_default", 0.0))

    def feature_vector(self, blue, red, team_b=None, team_r=None, side=0.0):
        """The win model's features (first-pick side minus the other), as learning.win_features."""
        f = {"strength": 0.0, "counter": 0.0, "synergy": 0.0, "comfort": 0.0}
        for mine, team, sign in ((blue, team_b, 1.0), (red, team_r, -1.0)):
            items = list(mine.items())
            for r, c in items:
                f["strength"] += sign * self.strength(c, r)
                f["comfort"] += sign * self.comfort(team, r, c)
            for i in range(len(items)):
                for j in range(i + 1, len(items)):
                    f["synergy"] += sign * (self.syn_rate(items[i][1], items[j][1]) - 0.5) / 2.0
        f["counter"] = sum(2.0 * (self.vs_rate(c, e) - 0.5) / 5.0 for c in blue.values() for e in red.values())
        f["elo"] = self.elo_feature(team_b, team_r)
        f["side"] = side
        return f

    def strength(self, c, r):
        key = ("st", c, r)
        if key not in self._cache:
            self._cache[key] = (0.5 * (self.s.strength_rate(c, r) - 0.5)
                                + 0.5 * (self.s.wr_long(c, r).rate(k=PARAMS["k_long"]) - 0.5))
        return self._cache[key]

    def vs_rate(self, c, e):
        return self.s.vs_wl(c, e).rate(k=PARAMS["k_vs"])

    def syn_rate(self, a, b):
        return self.s.syn_wl(a, b).rate(k=PARAMS["k_syn"])

    def comfort(self, team, r, c):
        if not team:
            return 0.0
        link = self.s.roster(team).get(r)
        if not link:
            return 0.0
        pw = self.s.player_pool[link].get(c)
        return (pw.rate(k=PARAMS["k_comfort"]) - 0.5) if pw else 0.0

    def expected_vs(self, c, opp_open, expect):
        """Sum over the opponent's unpicked slots of c's expected head-to-head edge.
        Uses predicted picks for those slots when available, else c's average matchup."""
        if not opp_open:
            return 0.0
        if expect:
            total = 0.0
            for role in opp_open:
                dist = expect.get(role)
                if dist:
                    total += sum(p * (self.vs_rate(c, e) - 0.5) for e, p in dist if e != c)
                else:
                    total += 0.5 * (self.s.champ_long_rate(c) - 0.5)
            return total
        return len(opp_open) * 0.5 * (self.s.champ_long_rate(c) - 0.5)

    def logit_blue(self, blue, red, team_b=None, team_r=None, expect=None, side=0.0):
        """Win-model logit for the first-pick side. blue/red: {role: champ}.
        expect: optional {"B": {role: [(champ, p)]}, "R": {...}} predicted picks for empty slots."""
        w = self.weights(team_b, team_r)
        z = w["bias"] + w.get("elo", 0.0) * self.elo_feature(team_b, team_r) + w.get("side", 0.0) * side
        expect = expect or {}
        for mine, theirs, team, sign, opp_side in ((blue, red, team_b, 1.0, "R"), (red, blue, team_r, -1.0, "B")):
            champs = list(mine.items())
            for r, c in champs:
                z += sign * w["strength"] * self.strength(c, r)
                if team and w["comfort"]:
                    z += sign * w["comfort"] * self.comfort(team, r, c)
            for i in range(len(champs)):
                for j in range(i + 1, len(champs)):
                    z += sign * w["synergy"] * (self.syn_rate(champs[i][1], champs[j][1]) - 0.5) / 2.0
            opp_open = [r for r in ROLES if r not in theirs]
            for r, c in champs:
                z += sign * w["counter"] * 2.0 * self.expected_vs(c, opp_open, expect.get(opp_side)) / 5.0
        for c in blue.values():
            for e in red.values():
                z += w["counter"] * 2.0 * (self.vs_rate(c, e) - 0.5) / 5.0
        a, c0 = self.calibration(self.model_key(team_b, team_r))
        return c0 + a * z

    def win_prob(self, side, allies, enemies, team, enemy_team, expect=None, map_side=0.0):
        """P(side wins) under the win model. map_side: the side feature of the first-pick team."""
        if side == "B":
            return sigmoid(self.logit_blue(allies, enemies, team, enemy_team, expect, map_side))
        return 1.0 - sigmoid(self.logit_blue(enemies, allies, enemy_team, team, expect, map_side))

    # ------------------------------------------------------------ context
    def context(self, draft, side, with_enemy=True, lookahead=True):
        res = getattr(draft, "reserve", {}) or {}
        allies = self.assign(draft.picks[side], res.get(side))
        enemies = self.assign(draft.picks[OTHER[side]], res.get(OTHER[side]))
        ctx = {
            "side": side, "allies": allies, "enemies": enemies,
            "open": [r for r in ROLES if r not in allies],
            "enemy_open": [r for r in ROLES if r not in enemies],
            "unavail": draft.unavailable(),
            "team": draft.teams[side], "enemy_team": draft.teams[OTHER[side]],
            "enemy_picks_left": 5 - len(enemies),
            "z_allies": self.s.arch_z(list(allies.values())),
            "z_enemies": self.s.arch_z(list(enemies.values())),
            "w": self.weights(draft.teams[side], draft.teams[OTHER[side]]),
            "expect": None,
            "map_side": self.side_feature(getattr(draft, "fp_side", None)),
        }
        if lookahead and self.predictor is not None and ctx["enemy_open"]:
            pred = self.predictor.predict(draft, OTHER[side], roles=ctx["enemy_open"])
            ctx["expect"] = {OTHER[side]: pred}
            ctx["enemy_pred"] = pred
        ctx["p_now"] = self.win_prob(side, allies, enemies, ctx["team"], ctx["enemy_team"], ctx["expect"], ctx["map_side"])
        if with_enemy:
            ctx["enemy_ctx"] = self.context(draft, OTHER[side], with_enemy=False, lookahead=False)
        return ctx

    # ------------------------------------------------------------- scoring
    def score(self, c, r, ctx, with_denial=True, phase_bonus=True):
        s = self.s
        comp, ev = {}, {}
        side, w = ctx["side"], ctx["w"]
        after = dict(ctx["allies"])
        after[r] = c
        p1 = self.win_prob(side, after, ctx["enemies"], ctx["team"], ctx["enemy_team"], ctx["expect"], ctx["map_side"])
        comp["win"] = (p1 - ctx["p_now"]) * 100
        ev["win_before"], ev["win_after"] = ctx["p_now"], p1

        # what drives the win-model change, in rough percentage points
        exp_opp = (ctx["expect"] or {}).get(OTHER[side])
        enemy_open = ctx["enemy_open"]
        ev["drivers"] = {
            "champion": 25 * w["strength"] * self.strength(c, r),
            "vs_their_picks": 25 * w["counter"] * 2 * sum(self.vs_rate(c, e) - 0.5 for e in ctx["enemies"].values()) / 5,
            "vs_their_likely_picks": 25 * w["counter"] * 2 * self.expected_vs(c, enemy_open, exp_opp) / 5,
            "with_your_picks": 25 * w["synergy"] * sum(self.syn_rate(c, a) - 0.5 for a in ctx["allies"].values()) / 2,
            "player_comfort": 25 * w["comfort"] * self.comfort(ctx["team"], r, c),
        }

        pres = s.presence(c)
        comp["meta"] = 1.5 * (pres - 0.15)
        share = s.role_share(c, r)
        comp["role"] = -(0.2 - share) * 15 if share < 0.2 else 0.0
        rec = s.recent(c, r)
        allwl = s.wr_long(c, r)
        ev.update(presence=pres, pick=s.pick_rate(c), ban=s.ban_rate(c),
                  recent_wr=(rec.rw / rec.rg) if rec.rg else None, recent_record=rec.record, recent_n=rec.rg,
                  games=s.raw_games.get((c, r), 0), record=allwl.record, role_share=share)

        opp = ctx["enemies"].get(r)
        if opp:
            lw = s.lane_wl(c, r, opp)
            ev["lane"] = {"opp": opp, "record": lw.record, "n": lw.rg}
        if r in ("BOT", "SUP"):
            er = "SUP" if r == "BOT" else "BOT"
            e2 = ctx["enemies"].get(er)
            if e2:
                dw = s.duo_wl(c, r, e2, er)
                ev["duo"] = {"opp": e2, "record": dw.record, "n": dw.rg}
        counters = []
        for er, e in ctx["enemies"].items():
            vw = s.vs_wl(c, e)
            counters.append((self.vs_rate(c, e) - 0.5, e, vw.record, vw.rg))
        syn = []
        for ar, a in ctx["allies"].items():
            sw = s.syn_wl(c, a)
            syn.append((self.syn_rate(c, a) - 0.5, a, sw.record, sw.rg))

        fit, notes = self.comp_fit(c, r, ctx)
        comp["comp"] = 0.5 * fit

        comp["blind"] = 0.0
        if phase_bonus and opp is None and ctx["enemy_picks_left"] > 0:
            bs = s.blind_share(c, r)
            comp["blind"] = (bs - 0.5) * 2
            ev["blind_share"] = bs
        flex_roles = [rr for rr, sh in s.roles(c) if sh >= 0.2 and rr in ctx["open"]]
        comp["flex"] = 0.5 if (phase_bonus and len(flex_roles) >= 2 and len(ctx["allies"]) <= 2) else 0.0

        if ctx.get("team"):
            pname, g, crec = s.comfort(ctx["team"], r, c)
            if pname:
                ev["comfort"] = {"player": pname, "games": g, "record": crec}

        comp["denial"] = 0.0
        if with_denial and ctx["enemy_picks_left"] > 0 and "enemy_ctx" in ctx:
            ectx = ctx["enemy_ctx"]
            vals = [self.score(c, er, ectx, with_denial=False)["components"]["win"]
                    for er in ectx["open"] if s.role_share(c, er) >= 0.15]
            if vals and max(vals) > 0:
                comp["denial"] = 0.3 * max(vals)
                ev["enemy_value"] = max(vals)

        total = sum(comp.values())
        return {"champ": c, "role": r, "total": total, "rating": round(50 + total, 1),
                "components": comp, "evidence": ev, "fit_notes": notes,
                "synergy": sorted(syn, key=lambda x: -x[0]), "counters": sorted(counters, key=lambda x: -x[0]),
                "flex_roles": flex_roles}

    def comp_fit(self, c, r, ctx):
        prof = profile(c, self.dd)
        tr = prof["traits"]
        allies = list(ctx["allies"].values())
        team = allies + [c]
        open_after = len(ctx["open"]) - 1
        pp, notes = 0.0, []
        need = min(1.0, len(allies) / 2.0)  # comp needs only matter once a comp exists
        if allies:
            before = damage_profile(allies, self.dd)
            after = damage_profile(team, self.dd)
            if len(team) >= 3:
                major = "AD" if after["AD"] >= after["AP"] else "AP"
                if after[major] > 0.8 and prof["dmg"] == major:
                    pp -= (after[major] - 0.8) / 0.2 * (2.5 if open_after <= 1 else 1.2)
                    notes.append(f"makes the comp {int(after[major] * 100)}% {major}")
            dealer = prof["class"] not in ("tank", "enchanter", "catcher")
            if dealer and prof["dmg"] in ("AP", "MIX") and before["AD"] >= 0.75:
                pp += 1.5
                notes.append("adds the magic damage you lack")
            if dealer and prof["dmg"] in ("AD", "MIX") and before["AP"] >= 0.75:
                pp += 1.5
                notes.append("adds the physical damage you lack")
        front_allies = sum(1 for a in allies if profile(a, self.dd)["traits"]["fl"] >= 2)
        if tr["fl"] >= 2 and front_allies == 0 and allies:
            pp += 1.2 * need
            notes.append("gives you a frontline")
        elif tr["fl"] < 2 and front_allies == 0 and open_after <= 1:
            pp -= 2.0 if open_after == 1 else 3.0
            notes.append("leaves you with no frontline")
        eng_allies = max((profile(a, self.dd)["traits"]["en"] for a in allies), default=0)
        if tr["en"] >= 2 and eng_allies < 2 and allies:
            pp += 1.2 * need
            notes.append("adds hard engage")
        if allies:
            z_b = ctx["z_allies"]
            z_a = self.s.arch_z(team)
            top_arch = max(z_a, key=z_a.get)
            coh = clamp((z_a[top_arch] - max(z_b.values())) * 0.8, -1.5, 2.0)
            pp += coh
            if coh >= 0.6:
                notes.append(f"doubles down on your {ARCHETYPE_LABEL[top_arch].lower()} plan")
        if len(ctx["enemies"]) >= 2:
            ze = ctx["z_enemies"]
            eid = max(ze, key=ze.get)
            if ze[eid] > 0.3:
                aff = sum(w * tr[t] for t, w in COUNTER_TRAITS[eid].items()) / 3.0
                bonus = clamp(aff * ze[eid] * 0.8, 0.0, 2.0)
                if bonus >= 0.5:
                    notes.append(f"answers their {ARCHETYPE_LABEL[eid].lower()}")
                pp += bonus
        return clamp(pp, -4.0, 4.0), notes

    # ----------------------------------------------------- recommendations
    def candidates(self, ctx, roles, min_games=3, **kw):
        best = {}
        for r in roles:
            for c in self.s.champions_in_role(r, min_games=min_games):
                if c in ctx["unavail"]:
                    continue
                x = self.score(c, r, ctx, **kw)
                if c not in best or x["total"] > best[c]["total"]:
                    best[c] = x
        return sorted(best.values(), key=lambda x: -x["total"])

    def recommend(self, draft, side, role=None, top=5, roles=None):
        ctx = self.context(draft, side)
        roles = [role] if role else (roles or ctx["open"])
        ranked = self.candidates(ctx, roles)
        return ranked[:top], ctx

    def recommend_ranked(self, draft, side, roles):
        """Every candidate for these roles, best first (solo queue filters them by the player's champions)."""
        ctx = self.context(draft, side)
        return self.candidates(ctx, roles), ctx

    def best_pair(self, draft, side, firsts):
        best = None
        for x in firsts[:6]:
            d2 = draft.copy_with_pick(side, x["champ"], x["role"])
            ctx2 = self.context(d2, side, with_enemy=False)
            if not ctx2["open"]:
                continue
            second = self.candidates(ctx2, ctx2["open"], with_denial=False)
            if second:
                tot = x["total"] + second[0]["total"]
                if best is None or tot > best["total"]:
                    best = {"total": tot, "first": x, "second": second[0]}
        return best

    def bans(self, draft, side, top=5):
        """Ban by expected damage: how likely the enemy is to pick it x how much it would help them.

        Validated against real pro bans: ranking by likelihood x (1 + value/2) matched pros' actual
        bans far more often than value alone (chosen on LCK 2026 playoffs, confirmed on Worlds 2026).
        """
        enemy = OTHER[side]
        ectx = self.context(draft, enemy, with_enemy=False)
        ranked = self.candidates(ectx, ectx["open"], with_denial=False)
        if self.predictor is None or not ectx["open"]:
            return ranked[:top]
        dist = self.predictor.predict(draft, enemy, roles=ectx["open"], top=25)
        p_any = {}
        for lst in dist.values():
            for c, p in lst:
                p_any[c] = p_any.get(c, 0.0) + p
        for x in ranked:
            x["likely"] = min(1.0, p_any.get(x["champ"], 0.0))
            x["threat"] = x["likely"] * (1.0 + max(0.0, x["total"]) / 2.0)
        ranked.sort(key=lambda x: -x["threat"])
        return ranked[:top]

    def team_fit(self, allies, enemies):
        """Knowledge-base comp fit of a whole team, in pp (used for the written plan, not the verdict)."""
        champs = list(allies.values())
        if len(champs) < 4:
            return 0.0
        profs = [profile(c, self.dd) for c in champs]
        pp = 0.0
        dp = damage_profile(champs, self.dd)
        major = max(dp["AD"], dp["AP"])
        if major > 0.8:
            pp -= (major - 0.8) / 0.2 * 3.0
        if not any(p["traits"]["fl"] >= 2 for p in profs):
            pp -= 2.0
        if max(p["traits"]["en"] for p in profs) < 2:
            pp -= 1.0
        z = self.s.arch_z(champs)
        pp += clamp(max(z.values()) * 0.8, -1.0, 2.0)
        if len(enemies) >= 2:
            ze = self.s.arch_z(list(enemies.values()))
            eid = max(ze, key=ze.get)
            if ze[eid] > 0.3:
                aff = sum(w * p["traits"][t] for p in profs for t, w in COUNTER_TRAITS[eid].items()) / (3.0 * len(profs))
                pp += clamp(aff * ze[eid] * 2.0, 0.0, 2.0)
        return pp

    def evaluate(self, draft):
        """Win-model verdict: P(first-pick side wins), its 90% range, and what drives it."""
        blue = self.assign(draft.picks["B"])
        red = self.assign(draft.picks["R"])
        tb, tr = draft.teams["B"], draft.teams["R"]
        key = self.model_key(tb, tr)
        w = self.weights(tb, tr)
        side = self.side_feature(getattr(draft, "fp_side", None))
        z_cal = self.logit_blue(blue, red, tb, tr, side=side)
        p_blue = sigmoid(z_cal)
        a, c0 = self.calibration(key)
        ci = None
        cov = (self.model.get("cov") or {}).get(key)
        if cov:
            fv = self.feature_vector(blue, red, tb, tr, side)
            xt = [1.0] + [fv[f] for f in cov["features"]]
            m = cov["matrix"]
            sd = math.sqrt(max(0.0, sum(xt[i] * m[i][j] * xt[j] for i in range(len(xt)) for j in range(len(xt)))))
            ci = [sigmoid(z_cal - 1.645 * a * sd), sigmoid(z_cal + 1.645 * a * sd)]
        team_only = None
        if key == "team":
            team_only = sigmoid(c0 + a * (w.get("elo", 0.0) * self.elo_feature(tb, tr) + w.get("side", 0.0) * side + w["bias"]))
        drivers = {}
        for side, mine, theirs, team in (("B", blue, red, tb), ("R", red, blue, tr)):
            parts = []
            for r, c in mine.items():
                v = (w["strength"] * self.strength(c, r)
                     + w["counter"] * 2 * sum(self.vs_rate(c, e) - 0.5 for e in theirs.values()) / 5
                     + w["synergy"] * sum(self.syn_rate(c, a) - 0.5 for a in mine.values() if a != c) / 2
                     + w["comfort"] * self.comfort(team, r, c))
                parts.append((r, c, round(25 * v, 2)))
            drivers[side] = sorted(parts, key=lambda x: -x[2])
        return {"p_blue": p_blue, "ci": ci, "drivers": drivers, "model": key, "team_only": team_only,
                "map_side": getattr(draft, "fp_side", None), "side_weight": w.get("side", 0.0),
                "elo": {"B": self.elo_rating(tb), "R": self.elo_rating(tr)} if key == "team" else None,
                "raw_logit": (z_cal - c0) / (a or 1.0)}

    # ------------------------------------------------------------ in game
    def ingame_prob(self, minute, state, prior_logit=0.0, tempo=0.0, variant="state + draft"):
        """P(first-pick side wins) at `minute` from the score so far.

        state: {feature: first-pick side minus the other} with gold in thousands and
        soul / elder / baron as +1 (theirs: -1) while active. prior_logit: the pre-game
        win-model logit before calibration. Minutes between the lab's models are interpolated."""
        ig = self.model.get("ingame") or {}
        models = (ig.get("models") or {}).get(variant) or {}
        feats = ig.get("features") or []
        mins = sorted(int(m) for m in models)
        if not mins or not feats:
            return None
        t = max(mins[0], min(mins[-1], float(minute)))
        lo = max(m for m in mins if m <= t)
        hi = min(m for m in mins if m >= t)
        n_state = len(feats) - 3
        gold = float(state.get("gold", 0.0))
        if variant == "gold + draft":
            x = [gold, prior_logit, tempo, gold * tempo]
        else:
            x = [float(state.get(f, 0.0)) for f in feats[:n_state]] + [prior_logit, tempo, gold * tempo]

        def z(m):
            mm = models[str(m)]
            return mm["b"] + sum(w * v for w, v in zip(mm["w"], x))
        zz = z(lo) if lo == hi else (1 - (t - lo) / (hi - lo)) * z(lo) + (t - lo) / (hi - lo) * z(hi)
        return sigmoid(zz)
