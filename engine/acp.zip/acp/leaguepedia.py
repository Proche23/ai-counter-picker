"""Leaguepedia (lol.fandom.com) Cargo API client.

Anonymous access is rate limited, so every request is paced and a
'ratelimited' answer triggers an exponential back-off instead of failing.
"""
import json
import time
import urllib.error
import urllib.parse
import urllib.request

API = "https://lol.fandom.com/api.php"
USER_AGENT = "pro-draft-stats/0.1 (python-urllib)"  # generic client name


class Cargo:
    def __init__(self, min_interval=2.5, max_retries=10, verbose=True):
        self.min_interval = float(min_interval)
        self._floor = float(min_interval)
        self.max_retries = max_retries
        self.verbose = verbose
        self._last = 0.0
        self.requests = 0

    def _log(self, msg):
        if self.verbose:
            print(msg, flush=True)

    def _get(self, params):
        url = API + "?" + urllib.parse.urlencode(params)
        backoff = 15.0
        for _ in range(self.max_retries):
            wait = self.min_interval - (time.time() - self._last)
            if wait > 0:
                time.sleep(wait)
            self._last = time.time()
            self.requests += 1
            try:
                req = urllib.request.Request(
                    url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"}
                )
                with urllib.request.urlopen(req, timeout=90) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, ConnectionError) as exc:
                self._log(f"    ! network error ({exc}); retry in {backoff:.0f}s")
                time.sleep(backoff)
                backoff = min(backoff * 2, 300)
                continue
            err = data.get("error") if isinstance(data, dict) else None
            if err:
                if err.get("code") == "ratelimited":
                    # slow the steady pace too, so we stop tripping the limiter
                    self.min_interval = min(self.min_interval * 1.5, 20.0)
                    self._log(f"    .. rate limited by Leaguepedia; waiting {backoff:.0f}s "
                              f"(pace now {self.min_interval:.1f}s/request)")
                    time.sleep(backoff)
                    backoff = min(backoff * 2, 300)
                    continue
                raise RuntimeError(f"Leaguepedia Cargo error: {err.get('code')}: {err.get('info')}")
            self.min_interval = max(self._floor, self.min_interval * 0.97)
            return data
        raise RuntimeError("Leaguepedia API: gave up after repeated rate limits / network errors")

    def query(self, tables, fields, where="", join_on="", order_by="", limit=500, offset=0):
        params = {
            "action": "cargoquery",
            "format": "json",
            "tables": tables,
            "fields": fields,
            "limit": str(limit),
            "offset": str(offset),
        }
        if where:
            params["where"] = where
        if join_on:
            params["join_on"] = join_on
        if order_by:
            params["order_by"] = order_by
        data = self._get(params)
        return [row["title"] for row in data.get("cargoquery", [])]

    def query_all(self, tables, fields, where="", join_on="", order_by="", page=500):
        rows, offset = [], 0
        while True:
            batch = self.query(tables, fields, where, join_on, order_by, limit=page, offset=offset)
            rows.extend(batch)
            if len(batch) < page:
                return rows
            offset += page


def esc(value):
    """Escape a value for a Cargo WHERE string literal."""
    return str(value).replace("\\", "\\\\").replace("'", "\\'")


# ---- the three tables we pull per tournament -------------------------------

GAME_FIELDS = [
    "GameId", "MatchId", "OverviewPage", "Tournament", "DateTime_UTC", "Patch", "N_GameInMatch",
    "Team1", "Team2", "Winner", "Gamelength_Number",
    "Team1Dragons", "Team2Dragons", "Team1Barons", "Team2Barons", "Team1Towers", "Team2Towers",
    "Team1Gold", "Team2Gold", "Team1Kills", "Team2Kills", "Team1RiftHeralds", "Team2RiftHeralds",
    "Team1VoidGrubs", "Team2VoidGrubs", "Team1Inhibitors", "Team2Inhibitors",
    "Team1Picks", "Team2Picks", "Team1Bans", "Team2Bans",
]

PB_FIELDS = ["GameId", "MatchId", "Team1", "Team2", "Winner", "N_GameInMatch"] + [
    f"Team{t}{kind}{i}" for t in (1, 2) for kind in ("Ban", "Pick", "Role") for i in range(1, 6)
]

PLAYER_FIELDS = [
    "GameId", "Name", "Link", "Team", "Champion", "Role", "Side", "PlayerWin",
    "Kills", "Deaths", "Assists", "Gold", "CS", "DamageToChampions",
    "Items", "Trinket", "SummonerSpells", "KeystoneRune", "PrimaryTree", "SecondaryTree", "Runes",
]


def _aliased(prefix, fields):
    # alias every field so the JSON keys are clean (Cargo otherwise turns _ into spaces)
    return ",".join(f"{prefix}.{f}={f.replace('_', '')}" for f in fields)


def list_tournaments(cargo, years, leagues):
    year_list = ",".join(f"'{int(y)}'" for y in years)
    league_list = ",".join(f"'{esc(l)}'" for l in leagues)
    # Worlds/MSI Play-Ins are part of the event proper even when flagged as qualifiers
    where = (
        f"T.Year IN ({year_list}) AND T.League IN ({league_list}) AND T.TournamentLevel='Primary' "
        f"AND (T.IsQualifier='0' OR T.IsQualifier IS NULL OR "
        f"(T.League IN ('World Championship','Mid-Season Invitational') AND T.Name LIKE '%Play-In%'))"
    )
    fields = "T.Name=Name,T.OverviewPage=OverviewPage,T.League=League,T.Region=Region,T.Year=Year,T.DateStart=DateStart,T.Date=DateEnd"
    return cargo.query_all("Tournaments=T", fields, where=where, order_by="T.DateStart")


def fetch_tournament(cargo, overview_page):
    where_sg = f"SG.OverviewPage='{esc(overview_page)}'"
    games = cargo.query_all("ScoreboardGames=SG", _aliased("SG", GAME_FIELDS), where=where_sg, order_by="SG.GameId")
    picks_bans = cargo.query_all(
        "PicksAndBansS7=PB", _aliased("PB", PB_FIELDS),
        where=f"PB.OverviewPage='{esc(overview_page)}'", order_by="PB.GameId",
    )
    players = cargo.query_all(
        "ScoreboardPlayers=SP", _aliased("SP", PLAYER_FIELDS),
        where=f"SP.OverviewPage='{esc(overview_page)}'", order_by="SP.GameId,SP.Side,SP.Role",
    )
    return {"games": games, "picks_bans": picks_bans, "players": players}


def fetch_batch(cargo, overview_pages):
    """fetch_tournament for several events at once (one set of paged queries instead of one per event,
    about 3x fewer requests for leagues with many small events). Returns {overview_page: data}."""
    pages = list(overview_pages)
    out = {p: {"games": [], "picks_bans": [], "players": []} for p in pages}
    if not pages:
        return out
    inlist = ",".join(f"'{esc(p)}'" for p in pages)
    for key, table, alias, fields, order in (
            ("games", "ScoreboardGames", "SG", GAME_FIELDS, "SG.GameId"),
            ("picks_bans", "PicksAndBansS7", "PB", PB_FIELDS + ["OverviewPage"], "PB.GameId"),
            ("players", "ScoreboardPlayers", "SP", PLAYER_FIELDS + ["OverviewPage"], "SP.GameId,SP.Side,SP.Role")):
        rows = cargo.query_all(f"{table}={alias}", _aliased(alias, fields),
                               where=f"{alias}.OverviewPage IN ({inlist})", order_by=order)
        for r in rows:
            page = r.pop("OverviewPage", None) if key != "games" else r.get("OverviewPage")
            if page in out:
                out[page][key].append(r)
    return out
