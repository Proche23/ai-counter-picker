"""EnemyPredictor: what will this team most likely pick next, given the draft so far?

A conditional-logit (softmax) model over every available champion x open role,
trained on real pro pick decisions (learn.py fits the weights). Features:

  presence   log pro presence (pick+ban priority)
  role       log share of the champion's pro games in that role
  copick     sum of log co-pick lifts with the team's own picks (comp patterns:
             "teams that took Vi also tend to take Orianna")
  vspick     sum of log lifts vs the opponent's picks (counter-pick habits)
  blind      log blind-pick rate if the lane opponent is unknown, else log counter-pick rate
  pool       log(1 + the team's recent pro games on it in that role)

The per-role distributions feed the engine's lookahead: your candidate is
scored against what the enemy will probably add, not just what is locked in.
"""
import math
from collections import defaultdict

from . import ROLES

FEATURES = ["presence", "role", "copick", "vspick", "blind", "pool"]
DEFAULT_WEIGHTS = {"presence": 1.0, "role": 1.0, "copick": 0.5, "vspick": 0.3, "blind": 0.5, "pool": 0.4}


class EnemyPredictor:
    def __init__(self, stats, weights=None, engine=None):
        self.s = stats
        self.w = dict(DEFAULT_WEIGHTS)
        if weights:
            self.w.update({k: v for k, v in weights.items() if k in FEATURES})
        self.engine = engine  # for role assignment of partial drafts
        # pick patterns use the 120-day 'pools' weighting (validated: better than 45 or 240 days)
        self.n_team = max(2.0 * stats.total_wp, 1e-9)

    # ----------------------------------------------------------- features
    def _lift(self, pair_g, a, b):
        na, nb = self.s.pick_wp.get(a, 0.0), self.s.pick_wp.get(b, 0.0)
        if na <= 0 or nb <= 0:
            return 0.0
        expected = na * nb / self.n_team
        return math.log((pair_g + 0.5) / (expected + 0.5))

    def features(self, c, r, own, opp, team):
        s = self.s
        f = {
            "presence": math.log(s.presence(c) + 0.01),
            "role": math.log(s.role_share(c, r) + 0.01),
            "copick": sum(self._lift(s.syn_meta.get(tuple(sorted((c, a))), 0.0), c, a) for a in own.values()),
            "vspick": sum(self._lift(s.vs_meta.get((c, e), 0.0), c, e) for e in opp.values()) / 2.0,
            "pool": 0.0,
        }
        bs = s.blind_share(c, r)
        f["blind"] = math.log(bs) if r not in opp else math.log(1.0 - bs)
        if team:
            f["pool"] = math.log1p(s.team_role_pool.get(team, {}).get((r, c), 0.0))
        return f

    def _score(self, f):
        return sum(self.w[k] * f[k] for k in FEATURES)

    def candidates(self, own, opp, unavailable, roles):
        out = []
        for r in roles:
            for c in self.s.champions_in_role(r, min_games=1):
                if c not in unavailable and self.s.role_share(c, r) >= 0.03:
                    out.append((c, r))
        return out

    # ------------------------------------------------------------- predict
    def next_pick(self, own, opp, unavailable, roles, team=None, top=10):
        """Distribution over the team's very next pick: [(champ, role, p)]."""
        cands = self.candidates(own, opp, unavailable, roles)
        if not cands:
            return []
        scores = [self._score(self.features(c, r, own, opp, team)) for c, r in cands]
        m = max(scores)
        ex = [math.exp(x - m) for x in scores]
        z = sum(ex)
        total = defaultdict(float)
        role_p = {}
        for (c, r), e in zip(cands, ex):
            p = e / z
            total[c] += p
            if p > role_p.get(c, (None, -1.0))[1]:
                role_p[c] = (r, p)  # most likely role for this champion
        ranked = sorted(total.items(), key=lambda kv: -kv[1])[:top]
        return [(c, role_p[c][0], p) for c, p in ranked]

    def predict(self, draft, side, roles=None, top=8):
        """Per open role: [(champ, p)] for what this side will put there."""
        eng = self.engine
        res = getattr(draft, "reserve", {}) or {}
        other = "R" if side == "B" else "B"
        own = eng.assign(draft.picks[side], res.get(side)) if eng else {}
        opp = eng.assign(draft.picks[other], res.get(other)) if eng else {}
        roles = roles or [r for r in ROLES if r not in own]
        unavailable = draft.unavailable()
        team = draft.teams[side]
        out = {}
        for r in roles:
            cands = [(c, rr) for c, rr in self.candidates(own, opp, unavailable, [r])]
            if not cands:
                continue
            scores = [self._score(self.features(c, rr, own, opp, team)) for c, rr in cands]
            m = max(scores)
            ex = [math.exp(x - m) for x in scores]
            z = sum(ex)
            ranked = sorted(((c, e / z) for (c, _), e in zip(cands, ex)), key=lambda kv: -kv[1])[:top]
            mass = sum(p for _, p in ranked) or 1.0
            out[r] = [(c, p / mass) for c, p in ranked]
        return out

    # --------------------------------------------------------------- train
    def fit(self, decisions, epochs=60, lr=0.15, l2=0.01, verbose=False):
        """decisions: list of (own, opp, unavailable, roles, team, actual_champ, actual_role)."""
        rows = []
        for own, opp, unav, roles, team, champ, role in decisions:
            cands = self.candidates(own, opp, unav - {champ}, roles)
            if (champ, role) not in cands:
                cands.append((champ, role))
            feats = [self.features(c, r, own, opp, team) for c, r in cands]
            target = cands.index((champ, role))
            rows.append(([[f[k] for k in FEATURES] for f in feats], target))
        w = [self.w[k] for k in FEATURES]
        for ep in range(epochs):
            grad = [0.0] * len(w)
            ll = 0.0
            for X, t in rows:
                sc = [sum(wi * xi for wi, xi in zip(w, x)) for x in X]
                m = max(sc)
                ex = [math.exp(v - m) for v in sc]
                z = sum(ex)
                ll += math.log(ex[t] / z)
                for j in range(len(w)):
                    grad[j] += X[t][j] - sum(e * x[j] for e, x in zip(ex, X)) / z
            w = [wi + lr * (g / len(rows) - l2 * wi) for wi, g in zip(w, grad)]
            if verbose and (ep % 10 == 0 or ep == epochs - 1):
                print(f"    epoch {ep:>3}: mean log-likelihood {ll / len(rows):.3f}")
        self.w = dict(zip(FEATURES, w))
        return self.w

    def evaluate(self, decisions, ks=(1, 3, 5, 10)):
        hits = defaultdict(int)
        base = defaultdict(int)
        for own, opp, unav, roles, team, champ, role in decisions:
            pred = [c for c, _, _ in self.next_pick(own, opp, unav, roles, team, top=max(ks))]
            pool = {c for c, r in self.candidates(own, opp, unav, roles)}
            pres = sorted(pool, key=lambda c: -self.s.presence(c))
            for k in ks:
                hits[k] += champ in pred[:k]
                base[k] += champ in pres[:k]
        n = max(1, len(decisions))
        return {k: hits[k] / n for k in ks}, {k: base[k] / n for k in ks}


def pick_decisions(con, stats, start, end, engine):
    """Every real pro pick decision in [start, end) as training/eval rows."""
    from .stats import _parse_dt
    games = [dict(r) for r in con.execute(
        "SELECT * FROM games WHERE date_utc >= ? AND date_utc < ? AND has_draft=1 ORDER BY date_utc",
        (start, end))]
    out = []
    by_match = defaultdict(list)
    for g in games:
        by_match[g["match_id"]].append(g)
    for gl in by_match.values():
        gl.sort(key=lambda g: g["game_in_match"] or 0)
        game_picks = [{r[0] for r in con.execute("SELECT champion FROM players WHERE game_id=?", (g["game_id"],))}
                      for g in gl]
        fearless = len(gl) >= 2 and all(not (game_picks[i] & game_picks[j])
                                        for i in range(len(gl)) for j in range(i))
        locked = set()
        for g in gl:
            players = [dict(r) for r in con.execute("SELECT * FROM players WHERE game_id=?", (g["game_id"],))]
            role_of = {(p["draft_side"], p["champion"]): p["role"] for p in players}
            team_of = {"B": g["fp_team"], "R": g["sp_team"]}
            picks = {"B": {}, "R": {}}
            bans = set()
            for a in con.execute("SELECT * FROM draft_actions WHERE game_id=? ORDER BY seq", (g["game_id"],)):
                a = dict(a)
                if not a["champion"]:
                    continue
                if a["action"] == "ban":
                    bans.add(a["champion"])
                    continue
                side = a["side"]
                role = role_of.get((side, a["champion"]), a["role"])
                if not role:
                    continue
                own, opp = picks[side], picks["R" if side == "B" else "B"]
                roles = [r for r in ROLES if r not in own]
                unav = bans | locked | set(own.values()) | set(opp.values())
                out.append((dict(own), dict(opp), unav, roles, team_of[side], a["champion"], role))
                own[role] = a["champion"]
            if fearless:
                locked |= set(picks["B"].values()) | set(picks["R"].values())
    return out
