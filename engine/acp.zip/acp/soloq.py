"""Solo queue: a database of its own (data/soloq.db), kept apart from the pro data.

Nothing here touches pro.db or regions.db, and the pro statistics never read it. It is filled from
Riot's match-v5 API with your own Riot key (the same key as the Players page): the best ranked solo
queue players on a server (Challenger, Grandmaster, Master, optionally Diamond / Emerald), their
recent ranked games, every one of them. A development key allows 100 requests every 2 minutes, so
about 3,000 games an hour; the download runs in the background, can be stopped, and picks up where
it left off.

What it's for:
  * the Solo queue page (web/soloq.html): every champion in every role, its win / pick / ban rate,
    every lane matchup, best teammates and the common build, all from solo queue;
  * solo queue mode on the draft board: a champion with few pro games in a role (or none) borrows
    solo queue evidence (SoloBlend), so it can be rated; champions with enough pro games are judged
    on pro games only, and pro records shown anywhere stay pro records.

Stored per game: the server, start time, length, patch, the seed player's tier, and per player only
the champion, role, result and end-of-game numbers (no names, no account ids). The download's own
bookkeeping (which ladder players it used) is in data/soloq_crawl.json, kept out of share zips.
"""
import json
import math
import os
import threading
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone

from . import DATA, ROLES

SOLO_DB = DATA / "soloq.db"
CRAWL = DATA / "soloq_crawl.json"
ROLE = {"TOP": "TOP", "JUNGLE": "JNG", "MIDDLE": "MID", "BOTTOM": "BOT", "UTILITY": "SUP"}
TIERS = {"master": ["CHALLENGER", "GRANDMASTER", "MASTER"],
         "diamond": ["CHALLENGER", "GRANDMASTER", "MASTER", "DIAMOND"],
         "emerald": ["CHALLENGER", "GRANDMASTER", "MASTER", "DIAMOND", "EMERALD"]}
TIER_LABEL = {"master": "Master+", "diamond": "Diamond+", "emerald": "Emerald+"}
APEX = ("CHALLENGER", "GRANDMASTER", "MASTER")
MAX_TARGET = 20000
SCHEMA = """
CREATE TABLE IF NOT EXISTS matches (match_id TEXT PRIMARY KEY, platform TEXT, start_ms INTEGER,
  duration_s INTEGER, patch TEXT, tier TEXT, blue_win INTEGER);
CREATE TABLE IF NOT EXISTS players (match_id TEXT, team INTEGER, role TEXT, champ TEXT, win INTEGER,
  k INTEGER, d INTEGER, a INTEGER, gold INTEGER, dmg INTEGER, cs INTEGER, vision INTEGER,
  items TEXT, keystone INTEGER, spells TEXT, PRIMARY KEY (match_id, team, role));
CREATE TABLE IF NOT EXISTS bans (match_id TEXT, team INTEGER, champ TEXT, turn INTEGER);
CREATE INDEX IF NOT EXISTS players_champ ON players (champ, role);
CREATE INDEX IF NOT EXISTS bans_match ON bans (match_id);
"""


def available(path=None):
    return os.path.exists(path or SOLO_DB)


def connect(path=None):
    import sqlite3   # (here, not at the top: the in-browser engine reads a snapshot, not a database)
    con = sqlite3.connect(str(path or SOLO_DB), timeout=30, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    return con


def _now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _read_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, separators=(",", ":"))
    os.replace(tmp, path)


# ------------------------------------------------------------------ one Riot match -> rows
class ChampMap:
    """Riot's championName / championId -> the Data Dragon champion name used everywhere here."""

    def __init__(self, champions):
        self.by_id = {str(c.get("id", "")).lower(): name for name, c in (champions or {}).items()}
        self.by_key = {str(c.get("key")): name for name, c in (champions or {}).items() if c.get("key")}

    def __call__(self, name=None, key=None):
        if key is not None and str(key) in self.by_key:
            return self.by_key[str(key)]
        return self.by_id.get(str(name or "").lower())


def match_rows(m, champ, platform, tier):
    """match-v5 JSON -> (match row, player rows, ban rows), or None for a game the stats shouldn't use
    (a remake, an early surrender, roles Riot couldn't tell, an unknown champion)."""
    info = (m or {}).get("info") or {}
    mid = ((m or {}).get("metadata") or {}).get("matchId")
    parts = info.get("participants") or []
    if not mid or len(parts) != 10 or info.get("queueId") not in (420, None):
        return None
    dur = float(info.get("gameDuration") or 0)
    if dur > 20000:   # milliseconds in very old records
        dur /= 1000.0
    if dur < 600 or any(p.get("gameEndedInEarlySurrender") for p in parts):
        return None
    players, roles = [], defaultdict(set)
    for p in parts:
        team = p.get("teamId")
        role = ROLE.get(p.get("teamPosition") or "") or ROLE.get(p.get("individualPosition") or "")
        c = champ(p.get("championName"), p.get("championId"))
        if team not in (100, 200) or not role or not c or role in roles[team]:
            return None
        roles[team].add(role)
        perks = ((p.get("perks") or {}).get("styles") or [{}])
        keystone = ((perks[0].get("selections") or [{}])[0]).get("perk") if perks else None
        players.append((mid, team, role, c, 1 if p.get("win") else 0, p.get("kills") or 0, p.get("deaths") or 0,
                        p.get("assists") or 0, p.get("goldEarned") or 0, p.get("totalDamageDealtToChampions") or 0,
                        (p.get("totalMinionsKilled") or 0) + (p.get("neutralMinionsKilled") or 0), p.get("visionScore") or 0,
                        json.dumps([p.get(f"item{i}") or 0 for i in range(6)]), keystone,
                        json.dumps([p.get("summoner1Id") or 0, p.get("summoner2Id") or 0])))
    bans = []
    for t in info.get("teams") or []:
        for b in t.get("bans") or []:
            c = champ(None, b.get("championId")) if (b.get("championId") or -1) > 0 else None
            if c:
                bans.append((mid, t.get("teamId"), c, b.get("pickTurn") or 0))
    blue_win = next((1 if p.get("win") else 0 for p in parts if p.get("teamId") == 100), 0)
    ver = str(info.get("gameVersion") or "")
    patch = ".".join(ver.split(".")[:2]) if ver.count(".") >= 1 else ""
    start = info.get("gameStartTimestamp") or info.get("gameCreation") or 0
    return (mid, platform, int(start), int(dur), patch, tier, blue_win), players, bans


def save_rows(con, rows):
    match, players, bans = rows
    con.execute("INSERT OR REPLACE INTO matches VALUES (?,?,?,?,?,?,?)", match)
    con.execute("DELETE FROM players WHERE match_id=?", (match[0],))
    con.execute("DELETE FROM bans WHERE match_id=?", (match[0],))
    con.executemany("INSERT INTO players VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", players)
    con.executemany("INSERT INTO bans VALUES (?,?,?,?)", bans)


# ------------------------------------------------------------------ the download
class Crawl:
    """The solo queue download, in a background thread (one at a time). state() is what the page shows."""

    def __init__(self):
        self.lock = threading.Lock()
        self.thread = None
        self.stop_ev = threading.Event()
        self._state = {"running": False}

    def state(self):
        with self.lock:
            return dict(self._state)

    def _set(self, **kw):
        with self.lock:
            self._state.update(kw)

    def running(self):
        return bool(self.thread and self.thread.is_alive())

    def start(self, cfg, champions, target=3000, platform="na1", tier="master", days=21):
        from . import riotapi
        if self.running():
            raise riotapi.RiotError("The solo queue download is already running.")
        key = riotapi.api_key(cfg)
        if not key:
            raise riotapi.RiotError("Solo queue games come from Riot's API, so this needs your Riot key: paste it "
                                    "on the Players page first (developer.riotgames.com).")
        platform = str(platform or "na1").lower()
        if platform not in riotapi.PLATFORMS:
            raise riotapi.RiotError(f"Unknown server '{platform}'.")
        tier = tier if tier in TIERS else "master"
        try:
            target = max(50, min(int(target), MAX_TARGET))
            days = max(1, min(int(days), 60))
        except (TypeError, ValueError):
            raise riotapi.RiotError("Games and days must be numbers.") from None
        self.stop_ev = threading.Event()
        self._state = {"running": True, "phase": "starting", "target": target, "platform": platform, "tier": tier,
                       "tier_label": TIER_LABEL[tier], "days": days, "added": 0, "found": 0, "requests": 0,
                       "started": _now_iso(), "error": None, "eta_s": None}
        self.thread = threading.Thread(target=self._run, name="soloq-download", daemon=True,
                                       args=(key, champions, target, platform, tier, days, cfg))
        self.thread.start()
        return self.state()

    def stop(self):
        self.stop_ev.set()

    # -- the job itself
    def _run(self, key, champions, target, platform, tier, days, cfg):
        from . import riotapi
        api = riotapi.RiotAPI(key, limiter=riotapi.RateLimiter(), stop=self.stop_ev)
        try:
            added = self._crawl(api, ChampMap(champions), target, platform, tier, days)
            self._set(running=False, phase="done" if added or not self.stop_ev.is_set() else "stopped",
                      finished=_now_iso(), eta_s=0)
        except riotapi.Stopped:
            self._set(running=False, phase="stopped", finished=_now_iso(), eta_s=None)
        except riotapi.KeyRejected as exc:
            riotapi._mark(key, False, str(exc))
            self._set(running=False, phase="error", error=str(exc) + " The games downloaded so far are kept.",
                      key_rejected=True, finished=_now_iso())
        except riotapi.RiotError as exc:
            self._set(running=False, phase="error", error=str(exc), finished=_now_iso())
        except Exception as exc:  # noqa: BLE001 - the page shows what went wrong
            self._set(running=False, phase="error", error=f"{type(exc).__name__}: {exc}", finished=_now_iso())
        finally:
            self._set(requests=api.requests)

    def _crawl(self, api, champ, target, platform, tier, days):
        from . import riotapi
        route = riotapi.PLATFORMS[platform]
        con = connect()
        book = _read_json(CRAWL)
        mine = book.setdefault(platform, {})
        # 1. the ladder: who to follow (kept 12 hours, so a restart doesn't ask again)
        seeds = mine.get("seeds") or []
        fresh = mine.get("tier") == tier and seeds and time.time() - float(mine.get("seeds_at") or 0) < 12 * 3600
        if not fresh:
            self._set(phase="ladder")
            seeds = []
            for t in TIERS[tier]:
                if t in APEX:
                    entries = (api.apex_league(platform, t) or {}).get("entries") or []
                else:
                    entries = []
                    for page in (1, 2):
                        entries += api.league_page(platform, t, "I", page) or []
                for e in sorted(entries, key=lambda e: -(e.get("leaguePoints") or 0)):
                    if e.get("puuid") or e.get("summonerId"):
                        seeds.append({"puuid": e.get("puuid"), "sid": e.get("summonerId"), "tier": t})
                self._set(seeds=len(seeds), requests=api.requests)
            mine.update(seeds=seeds, seeds_at=time.time(), tier=tier, used={})
            _write_json(CRAWL, book)
        if not seeds:
            raise riotapi.RiotError("Riot returned no ranked players for that server and tier.")
        have = {r[0] for r in con.execute("SELECT match_id FROM matches")}
        pending = {k: v for k, v in (mine.get("pending") or {}).items() if k not in have}
        used = mine.setdefault("used", {})
        start_time = int(time.time()) - days * 86400
        per = 100 if target >= 2000 else 50
        t0, done0 = time.monotonic(), api.requests

        def eta(left):
            rate = (api.requests - done0) / max(1.0, time.monotonic() - t0)   # requests per second so far
            return int(left / rate) if rate > 0.05 else int(left * 1.25)

        # 2. their recent ranked games (ids), best players first, until there are enough new ones
        self._set(phase="players")
        for i, s in enumerate(seeds):
            if len(pending) >= target:
                break
            if self.stop_ev.is_set():
                raise riotapi.Stopped()
            puuid = s.get("puuid")
            if not puuid and s.get("sid"):
                try:
                    puuid = s["puuid"] = (api.summoner_by_id(platform, s["sid"]) or {}).get("puuid")
                except riotapi.NotFound:
                    puuid = None
            if not puuid or float(used.get(puuid, 0)) > time.time() - 6 * 3600:
                continue
            try:
                ids = api.match_ids(puuid, route, count=per, queue=420, start_time=start_time, kind="ranked") or []
            except riotapi.NotFound:
                ids = []
            used[puuid] = time.time()
            for mid in ids:
                if mid not in have and mid not in pending:
                    pending[mid] = s.get("tier")
            left = target + max(0, target - len(pending)) // max(1, per // 2)   # (rough: game details + more id lists)
            self._set(found=len(pending), players_used=i + 1, requests=api.requests, eta_s=eta(left))
            if i % 10 == 9:
                mine["pending"] = pending
                _write_json(CRAWL, book)
        mine["pending"] = pending
        _write_json(CRAWL, book)
        # 3. every game, newest first (match ids sort by game number)
        self._set(phase="games")
        order = sorted(pending, key=lambda k: int(k.split("_")[-1]) if k.split("_")[-1].isdigit() else 0, reverse=True)[:target]
        added = 0
        for n, mid in enumerate(order):
            if self.stop_ev.is_set():
                break
            try:
                m = api.match(mid, route)
            except riotapi.NotFound:
                m = None
            rows = match_rows(m, champ, platform, pending.get(mid)) if m else None
            if rows:
                save_rows(con, rows)
                added += 1
            pending.pop(mid, None)
            if n % 10 == 9 or n == len(order) - 1:
                con.commit()
                mine["pending"] = pending
                _write_json(CRAWL, book)
            self._set(added=added, checked=n + 1, requests=api.requests, eta_s=eta(len(order) - n - 1))
        con.commit()
        mine["pending"] = pending
        mine["last_run"] = _now_iso()
        _write_json(CRAWL, book)
        try:
            con.execute("PRAGMA wal_checkpoint(TRUNCATE)")   # everything into soloq.db itself (share zips copy that file)
        except Exception:  # noqa: BLE001 - (sqlite3.Error) only a tidy-up
            pass
        con.close()
        if self.stop_ev.is_set():
            raise riotapi.Stopped()
        return added


CRAWLER = Crawl()


# ------------------------------------------------------------------ the statistics
def _wilson(w, n, z=1.96):
    if not n:
        return None, None
    p = w / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (c - h) / d, (c + h) / d


def _shrink(w, n, prior=0.5, k=100.0):
    return (w + prior * k) / (n + k)


class _N:
    """Games and wins (and sums of end-of-game numbers) for one champion in one role."""
    __slots__ = ("n", "w", "k", "d", "a", "gold", "dmg", "cs", "vis", "mins")

    def __init__(self):
        self.n = self.w = self.k = self.d = self.a = 0
        self.gold = self.dmg = self.cs = self.vis = 0
        self.mins = 0.0


class SoloBook:
    """Everything the Solo queue page shows, from data/soloq.db (optionally one patch only)."""

    def __init__(self, dd, path=None, patch=None):
        path = path or SOLO_DB
        self.dd = dd
        self.patch = patch
        self.items = dd.get("items") or {}
        self.item_name = {str(v["id"]): k for k, v in self.items.items()}
        self.cr = defaultdict(_N)            # (champ, role)
        self.lane = defaultdict(lambda: [0, 0])     # (champ, role, enemy in that role) -> [games, wins]
        self.vs = defaultdict(lambda: [0, 0])       # (champ, enemy) any roles
        self.syn = defaultdict(lambda: [0, 0])      # (a, b) sorted, same team
        self.mate = defaultdict(lambda: [0, 0])     # (champ, role, ally, ally role)
        self.duo = defaultdict(lambda: [0, 0])      # (bot-lane champ, role, enemy bot-lane champ, role)
        self.bans = Counter()
        self.build = defaultdict(lambda: defaultdict(lambda: [0, 0]))   # (champ, role) -> item id -> [n, w]
        self.keystone = defaultdict(lambda: defaultdict(lambda: [0, 0]))
        self.spells = defaultdict(lambda: defaultdict(lambda: [0, 0]))
        self.champ_n = Counter()
        self.champ_w = Counter()
        self.matches = 0
        self.all_patches, self.patch_counts = [], {}
        self.patches, self.tiers, self.platforms = Counter(), Counter(), Counter()
        self.newest = self.oldest = None
        if not os.path.exists(path):
            return
        con = connect(path)
        try:
            allp = Counter(r[0] for r in con.execute("SELECT patch FROM matches"))
            self.all_patches = sorted(allp, key=_patch_key, reverse=True)
            self.patch_counts = dict(allp)
            where, args = ("WHERE patch=?", (patch,)) if patch else ("", ())
            mrows = {r["match_id"]: r for r in con.execute(f"SELECT * FROM matches {where}", args)}
            prow = con.execute(f"SELECT p.* FROM players p JOIN matches m USING (match_id) {where.replace('patch', 'm.patch')}", args).fetchall()
            brow = con.execute(f"SELECT b.* FROM bans b JOIN matches m USING (match_id) {where.replace('patch', 'm.patch')}", args).fetchall()
        finally:
            con.close()
        self.matches = len(mrows)
        for r in mrows.values():
            self.patches[r["patch"]] += 1
            self.tiers[r["tier"] or "?"] += 1
            self.platforms[r["platform"]] += 1
            st = r["start_ms"] or 0
            self.newest = max(self.newest or st, st)
            self.oldest = min(self.oldest or st, st)
        teams = defaultdict(dict)   # (match, team) -> {role: row}
        for p in prow:
            teams[(p["match_id"], p["team"])][p["role"]] = p
        for (mid, team), mates in teams.items():
            mins = max(1.0, (mrows[mid]["duration_s"] or 0) / 60.0) if mid in mrows else 30.0
            foes = teams.get((mid, 300 - team), {})
            for role, p in mates.items():
                c, win = p["champ"], p["win"]
                x = self.cr[(c, role)]
                x.n += 1
                x.w += win
                x.k += p["k"]
                x.d += p["d"]
                x.a += p["a"]
                x.gold += p["gold"]
                x.dmg += p["dmg"]
                x.cs += p["cs"]
                x.vis += p["vision"]
                x.mins += mins
                self.champ_n[c] += 1
                self.champ_w[c] += win
                opp = foes.get(role)
                if opp:
                    self._add(self.lane, (c, role, opp["champ"]), win)
                for fr, f in foes.items():
                    self._add(self.vs, (c, f["champ"]), win)
                for ar, a in mates.items():
                    if ar != role:
                        self._add(self.mate, (c, role, a["champ"], ar), win)
                        if role < ar:
                            self._add(self.syn, tuple(sorted((c, a["champ"]))), win)
                if role in ("BOT", "SUP"):
                    other = foes.get("SUP" if role == "BOT" else "BOT")
                    if other:
                        self._add(self.duo, (c, role, other["champ"], "SUP" if role == "BOT" else "BOT"), win)
                try:
                    items = json.loads(p["items"] or "[]")
                except ValueError:
                    items = []
                for iid in {i for i in items if i}:
                    self._add(self.build[(c, role)], int(iid), win)
                if p["keystone"]:
                    self._add(self.keystone[(c, role)], int(p["keystone"]), win)
                try:
                    sp = tuple(sorted(json.loads(p["spells"] or "[]")))
                except (ValueError, TypeError):
                    sp = ()
                if sp:
                    self._add(self.spells[(c, role)], sp, win)
        seen = set()
        for b in brow:
            key = (b["match_id"], b["champ"])
            if key not in seen:   # banned by both teams = once per game
                seen.add(key)
                self.bans[b["champ"]] += 1

    @staticmethod
    def _add(store, key, win):
        v = store[key]
        v[0] += 1
        v[1] += win

    # -- the page
    def summary(self):
        return {"games": self.matches, "patches": [{"patch": p, "games": self.patch_counts.get(p, 0)} for p in getattr(self, "all_patches", [])],
                "patch": self.patch, "tiers": dict(self.tiers), "platforms": dict(self.platforms),
                "newest": _day(self.newest), "oldest": _day(self.oldest)}

    def role_share(self, c, r):
        tot = self.champ_n.get(c, 0)
        return self.cr[(c, r)].n / tot if tot and (c, r) in self.cr else 0.0

    def rate(self, c, r):
        x = self.cr.get((c, r))
        return _shrink(x.w, x.n) if x and x.n else 0.5

    def tier_of(self, c, r):
        x = self.cr.get((c, r))
        if not x or not x.n or not self.matches:
            return None
        s = _shrink(x.w, x.n)
        pick = x.n / self.matches
        if pick < 0.005 or x.n < 40:
            return None   # too few games to say
        return "S" if s >= 0.525 else "A" if s >= 0.512 else "B" if s >= 0.498 else "C" if s >= 0.485 else "D"

    def role_rows(self, role, pro=None, min_games=1):
        """Every champion played in `role`: games, win / pick / ban rate, tier, per-minute numbers, and
        how many pro games it has in that role (pro: the pro ProStats, for the comparison column)."""
        out = []
        total_role = sum(x.n for (c, r), x in self.cr.items() if r == role) or 1
        for (c, r), x in self.cr.items():
            if r != role or x.n < min_games:
                continue
            lo, hi = _wilson(x.w, x.n)
            pro_n = pro.raw_games.get((c, r), 0) if pro is not None else None
            pro_wl = pro.wr_long(c, r) if pro is not None and pro_n else None
            out.append({
                "champ": c, "games": x.n, "wins": x.w, "wr": x.w / x.n, "lo": lo, "hi": hi, "score": _shrink(x.w, x.n),
                "pick": x.n / self.matches if self.matches else 0, "ban": self.bans.get(c, 0) / self.matches if self.matches else 0,
                "share": x.n / total_role, "role_share": self.role_share(c, r), "tier": self.tier_of(c, r),
                "kda": (x.k + x.a) / max(1, x.d), "cspm": x.cs / x.mins, "gpm": x.gold / x.mins, "dpm": x.dmg / x.mins,
                "pro_games": pro_n, "pro_record": pro_wl.record if pro_wl else None,
            })
        out.sort(key=lambda d: (-(d["tier"] is not None), -d["score"], -d["games"]))
        return out

    def _pairs(self, store, keyf, base, min_n=1, prior_k=20.0):
        rows = []
        for key, (n, w) in store.items():
            other = keyf(key)
            if other is None or n < min_n:
                continue
            rows.append({"champ": other[0], "role": other[1], "games": n, "wins": w, "wr": w / n,
                         "score": _shrink(w, n, prior=base, k=prior_k), "edge": _shrink(w, n, prior=base, k=prior_k) - base})
        return rows

    def champ_report(self, c, r, pro=None):
        """One champion in one role: its numbers, every lane matchup, other enemies, best teammates,
        and the common build."""
        x = self.cr.get((c, r))
        if not x or not x.n:
            return {"champ": c, "role": r, "games": 0, "roles": self._roles(c)}
        base = _shrink(x.w, x.n)
        lanes = self._pairs(self.lane, lambda k: (k[2], r) if k[0] == c and k[1] == r else None, base)
        lanes.sort(key=lambda d: -d["score"])
        enough = [d for d in lanes if d["games"] >= 8]
        enemies = self._pairs(self.vs, lambda k: (k[1], None) if k[0] == c else None, base, min_n=15)
        enemies.sort(key=lambda d: d["score"])
        mates = self._pairs(self.mate, lambda k: (k[2], k[3]) if k[0] == c and k[1] == r else None, base, min_n=8)
        mates.sort(key=lambda d: -d["score"])
        duo = []
        if r in ("BOT", "SUP"):
            duo = self._pairs(self.duo, lambda k: (k[2], k[3]) if k[0] == c and k[1] == r else None, base, min_n=8)
            duo.sort(key=lambda d: d["score"])
        lo, hi = _wilson(x.w, x.n)
        out = {
            "champ": c, "role": r, "games": x.n, "wins": x.w, "wr": x.w / x.n, "lo": lo, "hi": hi, "score": base,
            "tier": self.tier_of(c, r), "pick": x.n / self.matches if self.matches else 0,
            "ban": self.bans.get(c, 0) / self.matches if self.matches else 0, "roles": self._roles(c),
            "kda": (x.k + x.a) / max(1, x.d), "k": x.k / x.n, "d": x.d / x.n, "a": x.a / x.n,
            "cspm": x.cs / x.mins, "gpm": x.gold / x.mins, "dpm": x.dmg / x.mins, "vspm": x.vis / x.mins,
            "lanes": lanes, "best": enough[:6], "worst": list(reversed(enough[-6:])) if len(enough) > 6 else list(reversed(enough[len(enough) // 2:])),
            "threats": enemies[:6], "mates": mates[:8], "duo_threats": duo[:6],
            "build": self._build(c, r, x.n),
        }
        if pro is not None:
            n = pro.raw_games.get((c, r), 0)
            wl = pro.wr_long(c, r)
            out["pro"] = {"games": n, "record": wl.record if n else None, "presence": pro.presence(c)}
        return out

    def _roles(self, c):
        tot = self.champ_n.get(c, 0)
        return [{"role": r, "games": self.cr[(c, r)].n, "share": self.cr[(c, r)].n / tot}
                for r in ROLES if tot and (c, r) in self.cr and self.cr[(c, r)].n]

    def _build(self, c, r, n):
        def name(iid):
            return self.item_name.get(str(iid))

        finished, boots = [], []
        for iid, (k, w) in self.build[(c, r)].items():
            nm = name(iid)
            it = self.items.get(nm) if nm else None
            if not it or it.get("consumed"):
                continue
            row = {"item": nm, "id": str(iid), "games": k, "share": k / n, "wr": w / k}
            if "Boots" in (it.get("tags") or []) and (it.get("depth") or 1) >= 2:
                boots.append(row)
            elif not it.get("into") and (it.get("gold") or 0) >= 1600:
                finished.append(row)
        finished.sort(key=lambda d: -d["games"])
        boots.sort(key=lambda d: -d["games"])
        runes = {}
        for tree in self.dd.get("runes") or []:
            for slot in tree.get("slots") or []:
                for ru in slot.get("runes") or []:
                    runes[ru.get("id")] = ru.get("name")
        keys = sorted(({"rune": runes.get(k, str(k)), "games": g, "share": g / n, "wr": w / g}
                       for k, (g, w) in self.keystone[(c, r)].items()), key=lambda d: -d["games"])
        spell_name = SPELL_NAMES
        spells = sorted(({"spells": [spell_name.get(s, str(s)) for s in sp], "games": g, "share": g / n, "wr": w / g}
                         for sp, (g, w) in self.spells[(c, r)].items()), key=lambda d: -d["games"])
        return {"items": finished[:8], "boots": boots[:3], "keystones": keys[:3], "spells": spells[:2]}


SPELL_NAMES = {1: "Cleanse", 3: "Exhaust", 4: "Flash", 6: "Ghost", 7: "Heal", 11: "Smite", 12: "Teleport",
               13: "Clarity", 14: "Ignite", 21: "Barrier", 32: "Mark"}


def _patch_key(p):
    try:
        return tuple(int(x) for x in str(p).split("."))
    except ValueError:
        return (0,)


def _day(ms):
    return time.strftime("%Y-%m-%d", time.gmtime(ms / 1000)) if ms else None


# ------------------------------------------------------------------ solo queue mode on the board
class SoloBlend:
    """The pro statistics as they are, plus solo queue evidence ONLY for champions with few pro games.

    A champion with FULL or more pro games in a role is judged on pro games alone. Below that, solo
    queue win rates are added as extra evidence (like another region's games: the rate moves, the
    record shown stays the pro record), weighing at most WEIGHT pro games for a champion with none,
    less the more pro games it has and the fewer solo games there are. Used only by solo queue mode
    on the draft board; nothing here changes the pro statistics themselves."""

    FULL = 30          # pro games in a role from which solo queue isn't used for a champion at all
    WEIGHT = 20.0      # the most solo queue evidence counts for (in pro games)
    SOLO_MIN = 40      # solo games in a role before a champion with no pro games can be suggested

    def __init__(self, pro, book):
        self._pro = pro
        self._book = book

    def __getattr__(self, name):   # everything not below: the pro statistics, untouched
        return getattr(self._pro, name)

    # -- how much solo queue evidence a champion gets
    def thin(self, c, r=None):
        if r:
            n = self._pro.raw_games.get((c, r), 0)
        else:
            n = sum(self._pro.raw_games.get((c, rr), 0) for rr in ROLES)
        return max(0.0, 1.0 - n / float(self.FULL))

    def _mix(self, wl, n, w, thin):
        from .stats import WL
        if thin <= 0 or n <= 0:
            return wl
        g = self.WEIGHT * thin * (n / (n + 100.0))
        rate = (w + 0.5 * 30.0) / (n + 30.0)
        out = WL()
        out.w, out.g, out.rw, out.rg = wl.w + g * rate, wl.g + g, wl.rw, wl.rg
        return out

    def solo_record(self, c, r):
        x = self._book.cr.get((c, r))
        return (x.n, x.w) if x else (0, 0)

    # -- the queries the engine uses
    def wr(self, c, r):
        n, w = self.solo_record(c, r)
        return self._mix(self._pro.wr(c, r), n, w, self.thin(c, r))

    def wr_long(self, c, r):
        n, w = self.solo_record(c, r)
        return self._mix(self._pro.wr_long(c, r), n, w, self.thin(c, r))

    def strength_rate(self, c, r):
        prior = self.wr_long(c, r).rate(k=20)
        return self.wr(c, r).rate(prior=prior, k=25)

    def champ_long_rate(self, c):
        from .stats import EMPTY
        n, w = self._book.champ_n.get(c, 0), self._book.champ_w.get(c, 0)
        return self._mix(self._pro.champ_long.get(c, EMPTY), n, w, self.thin(c)).rate(k=20)

    def lane_wl(self, c, r, opp):
        n, w = self._book.lane.get((c, r, opp), (0, 0))
        return self._mix(self._pro.lane_wl(c, r, opp), n, w, max(self.thin(c, r), self.thin(opp, r)))

    def duo_wl(self, c, r, e, er):
        n, w = self._book.duo.get((c, r, e, er), (0, 0))
        return self._mix(self._pro.duo_wl(c, r, e, er), n, w, max(self.thin(c, r), self.thin(e, er)))

    def vs_wl(self, c, e):
        n, w = self._book.vs.get((c, e), (0, 0))
        return self._mix(self._pro.vs_wl(c, e), n, w, max(self.thin(c), self.thin(e)))

    def syn_wl(self, a, b):
        n, w = self._book.syn.get(tuple(sorted((a, b))), (0, 0))
        return self._mix(self._pro.syn_wl(a, b), n, w, max(self.thin(a), self.thin(b)))

    def role_share(self, c, r):
        pro = self._pro.role_share(c, r)
        t = self.thin(c)
        n = self._book.champ_n.get(c, 0)
        if t <= 0 or not n:
            return pro
        mix = t * (n / (n + 50.0))
        return (1 - mix) * pro + mix * self._book.role_share(c, r)

    def roles(self, c):
        return sorted(((r, self.role_share(c, r)) for r in ROLES), key=lambda x: -x[1])

    def champions_in_role(self, r, min_games=3):
        out = list(self._pro.champions_in_role(r, min_games=min_games))
        have = set(out)
        for (c, rr), x in self._book.cr.items():
            if rr == r and c not in have and x.n >= self.SOLO_MIN:
                out.append(c)
        return out


def solo_engine(adv, book):
    """An Engine over SoloBlend for solo queue mode (shares the Advisor's builds, model and predictor)."""
    from .engine import Engine

    class SoloEngine(Engine):
        def role_prob(self, c, r):
            if self.s.thin(c) > 0 and self.s._book.champ_n.get(c, 0) >= 20:
                return max(self.s.role_share(c, r), 0.003)
            return super().role_prob(c, r)

        def score(self, c, r, ctx, **kw):
            x = super().score(c, r, ctx, **kw)
            t = self.s.thin(c, r)
            n, w = self.s.solo_record(c, r)
            if t > 0 and n:
                x["evidence"]["solo"] = {"games": n, "wr": w / n, "weight": round(t, 2)}
            return x

    blend = SoloBlend(adv.stats, book)
    eng = SoloEngine(blend, adv.builds, adv.dd["champions"], model=adv.model, predictor=adv.engine.predictor)
    return eng
