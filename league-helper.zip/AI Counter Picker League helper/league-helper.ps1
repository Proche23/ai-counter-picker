<#
AI Counter Picker - League helper

Lets the AI Counter Picker website follow your League client by itself: the queue, champ select (bans,
picks, your team's hovers, the timer) and then the live game. A website can't see programs on your PC,
so this small helper passes along what the client shows.

  * Read-only: it only reads, through the client's own local connection (the same way tools like
    Porofessor and Blitz read champ select). It never clicks, picks, bans or changes anything.
  * Only the AI Counter Picker website can read what it shares, and only from this PC: it answers on
    127.0.0.1 (this computer) and refuses every other website.
  * Your League password is never seen: the client gives local programs a one-time key for this.

In game it follows the live score (Riot's official live-game data). If you switch on "Quiet during
games" on the website, it reads nothing while your game runs instead (it only checks Windows' list of
running programs, what Task Manager shows, to see when the game closes) and picks up again afterwards.

It also serves the website itself at http://127.0.0.1:8799 (the same pages, passed through from the
site): if a browser won't let the website reach this helper, open that address instead.

Close this window to stop it.
#>
param(
    [int]$Port = 8799,
    [string]$Lockfile = "",
    [string]$LiveUrl = "https://127.0.0.1:2999",
    [string[]]$AllowOrigin = @("https://proche23.github.io"),
    [string]$Site = "https://proche23.github.io/ai-counter-picker",
    [string]$GameProcess = "League of Legends"
)

$ErrorActionPreference = "Stop"
$Version = "1.5"
# Anything that stops it is written in the window (which then waits for a key) instead of the window vanishing.
trap {
    Write-Host ""
    Write-Host "  The League helper couldn't keep running: $_" -ForegroundColor Red
    Write-Host "  (Antivirus or a work/school PC can block PowerShell helpers like this one.)" -ForegroundColor DarkGray
    exit 1
}
try { $Host.UI.RawUI.WindowTitle = "AI Counter Picker - League helper" } catch { }

# A click inside a console window starts Windows' "select text" mode, which pauses the program the next
# time it writes a line (until a key is pressed): the website would stop following. Switched off here.
try {
    Add-Type -Namespace AcpHelper -Name Console -MemberDefinition @"
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern System.IntPtr GetStdHandle(int which);
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern bool GetConsoleMode(System.IntPtr handle, out uint mode);
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern bool SetConsoleMode(System.IntPtr handle, uint mode);
"@
    $stdin = [AcpHelper.Console]::GetStdHandle(-10)
    $mode = [uint32]0
    if ([AcpHelper.Console]::GetConsoleMode($stdin, [ref]$mode)) {
        $null = [AcpHelper.Console]::SetConsoleMode($stdin, [uint32](($mode -bor 0x80) -band (-bnot 0x40)))   # (extended flags on, quick edit off)
    }
} catch { }

# The client and the game use Riot's own certificate on 127.0.0.1: accepted there, and nowhere else.
Add-Type -TypeDefinition @"
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
public static class AcpLocalTls {
    public static bool Check(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors errors) {
        HttpWebRequest req = sender as HttpWebRequest;
        if (req == null) return errors == SslPolicyErrors.None;
        string h = req.RequestUri.Host;
        return h == "127.0.0.1" || h == "localhost" || errors == SslPolicyErrors.None;
    }
    public static readonly RemoteCertificateValidationCallback Callback = Check;
}
"@
try {
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12 -bor [System.Net.SecurityProtocolType]::Tls11 -bor [System.Net.SecurityProtocolType]::Tls
} catch { }
# (Windows allows 2 open connections to each address by default: one that went wrong mustn't block the rest)
try { [System.Net.ServicePointManager]::DefaultConnectionLimit = 16 } catch { }

function Say([string]$text, [string]$color = "Gray") {
    Write-Host ("[{0:HH:mm:ss}] {1}" -f (Get-Date), $text) -ForegroundColor $color
}

# ------------------------------------------------------------------ finding the client
function Read-Lock([string]$path) {
    # "LeagueClient:<pid>:<port>:<password>:<protocol>" (opened shared: the client keeps it open)
    try {
        $fs = [System.IO.File]::Open($path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $sr = New-Object System.IO.StreamReader($fs)
        $text = $sr.ReadToEnd()
        $sr.Close()
    } catch { return $null }
    $parts = $text.Trim().Split(":")
    if ($parts.Count -lt 5) { return $null }
    $p = 0
    if (-not [int]::TryParse($parts[2], [ref]$p)) { return $null }
    $proto = $parts[4]
    if (-not $proto) { $proto = "https" }
    return @{ Port = $p; Password = $parts[3]; Protocol = $proto }
}

function Find-Client {
    if ($Lockfile) { if (Test-Path -LiteralPath $Lockfile) { return Read-Lock $Lockfile } else { return $null } }
    # the running client's own command line: works wherever League is installed
    try {
        $proc = Get-CimInstance Win32_Process -Filter "Name='LeagueClientUx.exe'" -ErrorAction Stop | Select-Object -First 1
        if ($proc -and $proc.CommandLine) {
            $port = [regex]::Match($proc.CommandLine, '--app-port=(\d+)').Groups[1].Value
            $token = [regex]::Match($proc.CommandLine, '--remoting-auth-token=([\w-]+)').Groups[1].Value
            if ($port -and $token) { return @{ Port = [int]$port; Password = $token; Protocol = "https" } }
        }
    } catch { }
    # the usual install folders
    $dirs = @("C:\Riot Games\League of Legends", "$env:ProgramFiles\Riot Games\League of Legends", "D:\Riot Games\League of Legends")
    foreach ($d in $dirs) {
        $lf = Join-Path $d "lockfile"
        if (Test-Path -LiteralPath $lf) { $c = Read-Lock $lf; if ($c) { return $c } }
    }
    return $null
}

# ------------------------------------------------------------------ reading it
function Get-Text([string]$url, [string]$auth) {
    # The JSON text at url; $null when there's nothing there (e.g. no champ select right now).
    # Throws when the client is gone or refuses the key (then it's looked for again).
    $req = [System.Net.HttpWebRequest]::Create($url)
    $req.Method = "GET"
    $req.Timeout = 2500
    $req.ReadWriteTimeout = 2500
    $req.Accept = "application/json"
    $req.ServerCertificateValidationCallback = [AcpLocalTls]::Callback
    if ($auth) { $req.Headers["Authorization"] = $auth }
    # Every connection is given back however the read ends (one left open by a slow or broken answer
    # would block every later read of the game).
    $resp = $null; $text = $null
    try {
        try {
            $resp = $req.GetResponse()
        } catch [System.Net.WebException] {
            $r = $_.Exception.Response
            if ($r -ne $null) {
                $code = [int]$r.StatusCode
                $r.Close()
                if ($code -eq 401 -or $code -eq 403) { throw "the client refused the key" }
                return $null
            }
            throw
        }
        $sr = New-Object System.IO.StreamReader($resp.GetResponseStream(), [System.Text.Encoding]::UTF8)
        $text = $sr.ReadToEnd()
        $sr.Close()
    } catch {
        try { $req.Abort() } catch { }
        throw
    } finally {
        if ($resp -ne $null) { try { $resp.Close() } catch { } }
    }
    if (-not $text) { return $null }
    return $text
}

$script:Lcu = $null          # @{ Base; Auth } while connected
$script:NextFind = [DateTime]::MinValue
$script:Phase = $null
$script:Queue = $null        # small JSON: the queue of the current lobby / game
$script:Me = $null           # small JSON: your Riot ID
$script:Said = ""
$script:Paused = $false      # your game is on and nothing is being read (quiet in game)
$InGame = @("GameStart", "InProgress", "Reconnect")
function Js($x) { if ($x) { $x } else { "null" } }

function Note([string]$key, [string]$text, [string]$color = "Gray") {
    if ($script:Said -ne $key) { $script:Said = $key; Say $text $color }
}

function Read-State([bool]$Quiet = $false) {
    # Everything the website needs right now, as one JSON text. Quiet: while the game runs, read nothing.
    if (-not $script:Lcu) {
        if ([DateTime]::Now -lt $script:NextFind) { return '{"helper":"' + $Version + '","client":false}' }
        $script:NextFind = [DateTime]::Now.AddSeconds(3)
        $c = Find-Client
        if (-not $c) {
            Note "off" "Waiting for the League client... (open League; this connects by itself)" "DarkYellow"
            return '{"helper":"' + $Version + '","client":false}'
        }
        $auth = "Basic " + [Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes("riot:" + $c.Password))
        $script:Lcu = @{ Base = ("{0}://127.0.0.1:{1}" -f $c.Protocol, $c.Port); Auth = $auth }
        $script:Phase = $null; $script:Queue = $null; $script:Me = $null
    }
    if ($Quiet -and ($script:Paused -or ($InGame -contains $script:Phase))) {
        if (Get-Process -Name $GameProcess -ErrorAction SilentlyContinue) {   # (Windows' list of programs, not the game)
            if (-not $script:Paused) { $script:Paused = $true; Say "Your game is on: reading nothing from League until it ends." "Cyan" }
            return '{"helper":"' + $Version + '","client":true,"paused":true,"phase":"InProgress","summoner":' + (Js $script:Me) + '}'
        }
        if ($script:Paused) { $script:Paused = $false; $script:Phase = $null; Say "Your game ended: following the client again." "Cyan" }
    }
    $base = $script:Lcu.Base; $auth = $script:Lcu.Auth
    try {
        $phaseJson = Get-Text "$base/lol-gameflow/v1/gameflow-phase" $auth
        if (-not $phaseJson) { $phaseJson = '"None"' }
        $phase = $phaseJson.Trim('"')
        if (-not $script:Me) {
            $s = Get-Text "$base/lol-summoner/v1/current-summoner" $auth
            if ($s) {
                $o = $s | ConvertFrom-Json
                if ($o.gameName -or $o.displayName) {
                    $script:Me = (@{ gameName = $o.gameName; tagLine = $o.tagLine; displayName = $o.displayName } | ConvertTo-Json -Compress)
                    $who = if ($o.gameName) { "$($o.gameName)#$($o.tagLine)" } else { $o.displayName }
                    Say "Connected to the League client ($who). The website follows it now." "Green"
                    $script:Said = "on"
                }
            }
        }
        if ($phase -ne $script:Phase) {
            $script:Phase = $phase
            $script:Queue = $null
            if ($phase -ne "None") {
                $g = Get-Text "$base/lol-gameflow/v1/session" $auth
                if ($g) {
                    $q = ($g | ConvertFrom-Json).gameData.queue
                    if ($q) { $script:Queue = (@{ id = $q.id; description = $q.description; shortName = $q.shortName; isRanked = $q.isRanked } | ConvertTo-Json -Compress) }
                }
            }
            $words = @{ "None" = "In the client"; "Lobby" = "In a lobby"; "Matchmaking" = "In queue"; "ReadyCheck" = "Match found";
                        "ChampSelect" = "Champ select: the website follows every pick"; "InProgress" = "In game: the website follows the live score";
                        "EndOfGame" = "Game over" }
            if ($words.ContainsKey($phase)) { Say $words[$phase] "Cyan" }
        }
        $search = $null; $cs = $null; $live = $null
        if ($phase -eq "Matchmaking" -or $phase -eq "ReadyCheck") { $search = Get-Text "$base/lol-matchmaking/v1/search" $auth }
        if ($phase -eq "ChampSelect") { $cs = Get-Text "$base/lol-champ-select/v1/session" $auth }
        if ((-not $Quiet) -and ($InGame -contains $phase)) {
            try { $live = Get-Text "$LiveUrl/liveclientdata/allgamedata" "" } catch { $live = $null }   # (the game is still loading)
        }
    } catch {
        $script:Lcu = $null
        Note "lost" "The League client closed (or restarted): looking for it again..." "DarkYellow"
        return '{"helper":"' + $Version + '","client":false}'
    }
    $n = { param($x) if ($x) { $x } else { "null" } }
    return '{"helper":"' + $Version + '","client":true,"phase":' + $phaseJson + ',"summoner":' + (& $n $script:Me) +
           ',"queue":' + (& $n $script:Queue) + ',"search":' + (& $n $search) + ',"champ_select":' + (& $n $cs) +
           ',"live":' + (& $n $live) + '}'
}

# ------------------------------------------------------------------ the website itself, passed through
$script:Files = @{}   # path -> @{ Code; Type; Body } (the site's files don't change while this runs)
function Get-SiteFile([string]$path) {
    if (-not $Site -or $Site.StartsWith("__")) { return @{ Code = 404; Type = "text/plain"; Body = [System.Text.Encoding]::UTF8.GetBytes("This helper doesn't know the website's address.") } }
    if ($path -eq "/" -or $path -eq "") { $path = "/index.html" }
    $cacheable = -not ($path -match '^/[^/?]*\.html') -and -not ($path -match '^/build-info\.json')
    if ($cacheable -and $script:Files.ContainsKey($path)) { return $script:Files[$path] }
    $req = [System.Net.HttpWebRequest]::Create($Site.TrimEnd("/") + $path)
    $req.Timeout = 30000
    $req.ReadWriteTimeout = 60000
    $req.UserAgent = "ai-counter-picker-league-helper/$Version"
    try {
        $resp = $req.GetResponse()
    } catch [System.Net.WebException] {
        $r = $_.Exception.Response
        $code = 502
        if ($r -ne $null) { $code = [int]$r.StatusCode; $r.Close() }
        return @{ Code = $code; Type = "text/plain"; Body = [System.Text.Encoding]::UTF8.GetBytes("Couldn't get $path from the website ($code).") }
    }
    try {
        $ms = New-Object System.IO.MemoryStream
        $resp.GetResponseStream().CopyTo($ms)
        $item = @{ Code = 200; Type = $resp.ContentType; Body = $ms.ToArray() }
    } catch {
        return @{ Code = 502; Type = "text/plain"; Body = [System.Text.Encoding]::UTF8.GetBytes("Couldn't get $path from the website.") }
    } finally {
        $resp.Close()
    }
    if ($cacheable) { $script:Files[$path] = $item }
    return $item
}

# ------------------------------------------------------------------ answering the website
function Test-Origin([string]$origin) {
    if (-not $origin) { return $false }
    foreach ($a in $AllowOrigin) { if ($a -and $a -ne "__SITE_ORIGIN__" -and $origin -eq $a) { return $true } }
    return ($origin -match '^http://(127\.0\.0\.1|localhost)(:\d+)?$')   # (a copy of the website on this PC)
}

function Send([System.Net.Sockets.NetworkStream]$ns, [int]$code, [string]$body, [string]$origin, [bool]$allowed) {
    Send-Bytes $ns $code ([System.Text.Encoding]::UTF8.GetBytes($body)) "application/json; charset=utf-8" $origin $allowed
}

function Send-Bytes([System.Net.Sockets.NetworkStream]$ns, [int]$code, [byte[]]$bytes, [string]$type, [string]$origin, [bool]$allowed) {
    $reason = @{ 200 = "OK"; 204 = "No Content"; 403 = "Forbidden"; 404 = "Not Found"; 400 = "Bad Request"; 502 = "Bad Gateway" }[$code]
    if (-not $reason) { $reason = "OK" }
    if ($bytes -eq $null) { $bytes = [byte[]]@() }
    $head = "HTTP/1.1 $code $reason`r`nContent-Type: $type`r`nContent-Length: $($bytes.Length)`r`n" +
            "Cache-Control: no-store`r`nConnection: close`r`n"
    if ($allowed) {
        $head += "Access-Control-Allow-Origin: $origin`r`nVary: Origin`r`nAccess-Control-Allow-Methods: GET, OPTIONS`r`n" +
                 "Access-Control-Allow-Headers: *`r`nAccess-Control-Allow-Private-Network: true`r`nAccess-Control-Max-Age: 600`r`n"
    }
    $hb = [System.Text.Encoding]::ASCII.GetBytes($head + "`r`n")
    $ns.Write($hb, 0, $hb.Length)
    if ($bytes.Length) { $ns.Write($bytes, 0, $bytes.Length) }
    $ns.Flush()
}

function Answer([System.Net.Sockets.TcpClient]$client) {
    $client.ReceiveTimeout = 1000
    $client.SendTimeout = 3000
    $ns = $client.GetStream()
    $sr = New-Object System.IO.StreamReader($ns, [System.Text.Encoding]::ASCII, $false, 4096, $true)
    $first = $sr.ReadLine()
    if (-not $first) { return }
    $headers = @{}
    for ($i = 0; $i -lt 60; $i++) {
        $line = $sr.ReadLine()
        if ($line -eq $null -or $line -eq "") { break }
        $k = $line.IndexOf(":")
        if ($k -gt 0) { $headers[$line.Substring(0, $k).Trim().ToLower()] = $line.Substring($k + 1).Trim() }
    }
    $bits = $first.Split(" ")
    $method = $bits[0]; $path = if ($bits.Count -gt 1) { $bits[1] } else { "/" }
    $path = $path.Split("?")[0]
    $origin = $headers["origin"]
    $allowed = Test-Origin $origin
    $sameSite = ($headers["sec-fetch-site"] -eq "same-origin") -and (-not $origin)   # (the website opened through this helper)
    $hostName = ("" + $headers["host"]).ToLower()
    if ($hostName -notmatch '^(127\.0\.0\.1|localhost)(:\d+)?$') { Send $ns 403 '{"error":"wrong host"}' $origin $false; return }
    if ($method -eq "OPTIONS") {
        if ($allowed) { Send $ns 204 "" $origin $true } else { Send $ns 403 "" $origin $false }
        return
    }
    if ($path -eq "/ping") {
        Send $ns 200 ('{"helper":"' + $Version + '","app":"ai-counter-picker"}') $origin $allowed
        return
    }
    if ($path -eq "/state") {
        if (-not ($allowed -or $sameSite)) { Send $ns 403 '{"error":"only the AI Counter Picker website can read this"}' $origin $false; return }
        $quiet = ($bits[1] -match '[?&]quiet=1(&|$)')   # (the website's "Quiet during games" switch; off unless it says so)
        Send $ns 200 (Read-State $quiet) $origin $allowed
        return
    }
    if ($method -ne "GET") { Send $ns 404 '{"error":"not found"}' $origin $allowed; return }
    $full = $bits[1]
    if ($full -match '\.\.' ) { Send $ns 404 '{"error":"not found"}' $origin $false; return }
    if (-not $script:SaidSite) { $script:SaidSite = $true; Say "The website is open through this helper (http://127.0.0.1:$Port)." "Green" }
    $f = Get-SiteFile $full
    Send-Bytes $ns $f.Code $f.Body $f.Type $origin $false
}

# ------------------------------------------------------------------ the loop
$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)
try {
    $listener.Start()
} catch {
    Say "Port $Port is already in use: the League helper is probably running already (look for its window)." "Red"
    exit 1
}
Write-Host ""
Write-Host "  AI Counter Picker - League helper $Version" -ForegroundColor Yellow
Write-Host "  Keep this window open while you play; the website follows your League client through it." -ForegroundColor Gray
Write-Host "  It only reads (never clicks or changes anything) and only the website can see it. Close it to stop." -ForegroundColor DarkGray
if ($Site -and -not $Site.StartsWith("__")) {
    Write-Host "  If your browser won't connect the website to this helper, open it here instead: http://127.0.0.1:$Port" -ForegroundColor Gray
}
Write-Host ""
$null = Read-State
try {
    while ($true) {
        if (-not $listener.Pending()) { Start-Sleep -Milliseconds 15; continue }
        $client = $listener.AcceptTcpClient()
        try { Answer $client } catch { } finally { $client.Close() }
    }
} finally {
    $listener.Stop()
}
