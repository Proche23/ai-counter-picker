AI Counter Picker - League helper
================================

Lets the AI Counter Picker website follow your League client by itself: the queue, champ select (bans,
picks, your team's hovers, the timer) and then the live game.

0. So Windows won't ask about it: right-click the zip > Properties > tick "Unblock" at the bottom > OK.
   Then extract it (right-click > Extract All). Started from inside the zip, it can't run.
1. Double-click "Start League Helper.cmd". If Windows still asks (it does for any new program from the
   internet that isn't signed: "Windows protected your PC" or "SmartScreen can't be reached"), click
   Run, or More info > Run anyway. (Already extracted? Right-click the .cmd > Properties > Unblock.)
2. Keep the small window it opens running while you play.
3. Open the website: the League button at the top turns teal. Queue up and the board fills itself in.
   The My Stats tab reads your recent games through it too (no Riot key needed).

It only reads from your client (the same local connection tools like Porofessor and Blitz use) and never
clicks, picks or changes anything. It answers only on this PC (127.0.0.1), only to the website.
Your browser may ask once whether the site may connect to apps on this device: choose Allow.
If your browser won't connect the site to the helper at all, open the site through the helper instead:
http://127.0.0.1:8799 (the same website, and it always connects).
Windows only (PowerShell, built into Windows 10 and 11). Close the window to stop it.
