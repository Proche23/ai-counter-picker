AI Counter Picker - League helper
================================

Lets the AI Counter Picker website follow your League client by itself: the queue, champ select (bans,
picks, your team's hovers, the timer) and then the live game.

1. Double-click "Start League Helper.cmd". (If Windows says it protected your PC: More info > Run anyway.
   If it asks about running a downloaded file: Run.)
2. Keep the small window it opens running while you play.
3. Open the website: the League button at the top turns teal. Queue up and the board fills itself in.

It only reads from your client (the same local connection tools like Porofessor and Blitz use) and never
clicks, picks or changes anything. It answers only on this PC (127.0.0.1), only to the website.
Your browser may ask once whether the site may connect to apps on this device: choose Allow.
Windows only (PowerShell, built into Windows 10 and 11). Close the window to stop it.
