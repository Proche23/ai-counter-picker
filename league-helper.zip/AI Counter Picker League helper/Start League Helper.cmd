@echo off
rem AI Counter Picker - League helper: lets the website follow your League client (read-only).
rem Keep this window open while you play. Close it to stop.
title AI Counter Picker - League helper
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0league-helper.ps1" %*
if errorlevel 1 pause
