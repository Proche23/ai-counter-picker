@echo off
rem AI Counter Picker - League helper: lets the website follow your League client (read-only).
rem Keep this window open while you play. Close it to stop.
title AI Counter Picker - League helper
cd /d "%~dp0"
echo Starting the AI Counter Picker League helper...
if not exist "%~dp0league-helper.ps1" goto notextracted
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0league-helper.ps1" %*
if not "%errorlevel%"=="0" goto failed
goto :eof

:notextracted
echo.
echo   This was started from inside the zip, so Windows didn't unpack the rest of the helper.
echo.
echo   1. Close this window.
echo   2. Right-click league-helper.zip and choose "Extract All...", then "Extract".
echo   3. In the folder that opens, double-click "Start League Helper.cmd" again.
echo.
pause
goto :eof

:failed
echo.
echo   The League helper stopped (the reason is written above).
echo   If it says the port is in use, the helper is already running: look for its other window.
echo.
pause
